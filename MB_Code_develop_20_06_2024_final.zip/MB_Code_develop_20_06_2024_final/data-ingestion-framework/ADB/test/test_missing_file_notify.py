from unittest.mock import MagicMock, patch
from ADB.common.missing_file_notify_utils import read_delta_table,get_current_date,get_current_datetime,get_active_identifiers,filter_watermark,join_watermark_and_metadata,convert_utc_to_est,check_cron_schedule,is_trigger_eligible,filter_metadata_by_domain,filter_eligible_files,apply_eligibility_check,process_dataframe_schema
from datetime import datetime,date
from pyspark.sql.functions import col


@patch('pyspark.sql.SparkSession.read')
def test_read_delta_table(mock_read_spark):
    mock_read_spark.table.return_value='123'
    output = read_delta_table("test123","testa123")
    assert output=='123'

def test_get_current_date():
    result = get_current_date()

    assert isinstance(result, date)

def test_get_current_datetime():
    result = get_current_datetime()

    assert isinstance(result, datetime)

def test_get_active_identifiers(spark):
        data = [("file1", 1), ("file2", 2), ("file3", 1), ("file4", 3), ("file5", 1)]
        columns = ["test_col", "id_src_file"]
        metadata_df = spark.createDataFrame(data, columns)

        active_ids = get_active_identifiers(metadata_df)

        expected_result = [1, 2, 3]

        assert active_ids == expected_result

def test_filter_watermark(spark):
        data = [("2024-03-14", 1), ("2024-03-14", 2), ("2024-03-13", 3), ("2024-03-15", 4)]
        columns = ["run_dte", "test_col"]
        watermark_df = spark.createDataFrame(data, columns)

        current_date = "2024-03-14"

        filtered_df = filter_watermark(watermark_df, current_date)

        expected_result = watermark_df.where(col("run_dte") == current_date)
        assert filtered_df.collect() == expected_result.collect()

def test_join_watermark_and_metadata(spark):
        metadata_data = [("file1", 1), ("file2", 2), ("file3", 3), ("file4", 4)]
        watermark_data = [(1,), (2,), (5,)]
        metadata_columns = ["id_src_file", "test_column"]
        watermark_columns = ["id_proc"]

        metadata_df = spark.createDataFrame(metadata_data, metadata_columns)
        watermark_df = spark.createDataFrame(watermark_data, watermark_columns)

        result_df = join_watermark_and_metadata(metadata_df, watermark_df)

        expected_result = metadata_df.join(watermark_df, metadata_df["id_src_file"] == watermark_df["id_proc"], how="left_anti")
        assert result_df.collect() == expected_result.collect()



def test_convert_utc_to_est():
        trigger_time_utc = "2024-03-14T12:00:00Z"

        trigger_time_est = convert_utc_to_est(trigger_time_utc)

        expected_est_time = datetime(2024, 3, 14, 8, 0)

        assert trigger_time_est.replace(tzinfo=None) == expected_est_time

def test_is_trigger_eligible_true():
        cron_expression = {"start_cron": "30 8 * * *", "end_cron": "0 18 * * *"}

        trigger_time = datetime(2024, 3, 14, 8, 30)

        result = is_trigger_eligible(cron_expression, trigger_time)

        assert result == True

def test_is_trigger_eligible_false():
        cron_expression = {"start_cron": "30 8 * * *", "end_cron": "0 18 * * *"}

        trigger_time = datetime(2024, 3, 13, 10, 30)

        result = is_trigger_eligible(cron_expression, trigger_time)

        assert result == False

def test_check_cron_schedule():
        # Test case 1: trigger time matches start cron
        cron_expression = {"start_cron": "0 8 * * *", "end_cron": "0 18 * * *"}
        trigger_time = datetime(2024, 3, 14, 8, 0, 0)
        assert check_cron_schedule(cron_expression, trigger_time) == True

        # Test case 2: trigger time matches end cron
        cron_expression = {"start_cron": "0 8 * * *", "end_cron": "0 18 * * *"}
        trigger_time = datetime(2024, 3, 12, 18, 0, 0)
        assert check_cron_schedule(cron_expression, trigger_time) == True

        # Test case 3: trigger time does not match start or end cron
        cron_expression = {"start_cron": "0 8 * * *", "end_cron": "0 18 * * *"}
        trigger_time = datetime(2024, 3, 12, 10, 0, 0)
        assert check_cron_schedule(cron_expression, trigger_time) == False

def test_filter_metadata_by_domain(spark):
        data = [("domain1", "delimited", 1), ("domain1", "zip", 2), ("domain2", "delimited", 3)]
        columns = ["domn_area", "file_typ", "test"]
        metadata_df = spark.createDataFrame(data, columns)

        domain = "domain1"

        filtered_df = filter_metadata_by_domain(metadata_df, domain)

        expected_result = metadata_df.filter((col("domn_area") == domain) & (col("file_typ") == "delimited"))
        assert filtered_df.collect() == expected_result.collect()

def test_filter_eligible_files(spark):
        data = [("file1", "true"), ("file2", "false"), ("file3", "true")]
        columns = ["id_src_file", "is_eligible"]
        metadata_df = spark.createDataFrame(data, columns)

        filtered_df = filter_eligible_files(metadata_df)

        expected_result = metadata_df.filter(col("is_eligible") == "true").select(col("id_src_file"))
        assert filtered_df.collect() == expected_result.collect()

@patch('ADB.common.missing_file_notify_utils.is_trigger_eligible')
def test_apply_eligibility_check(mock_is_trigger_eligible):
        trigger_time_est = "2024-03-14 08:00:00"

        mock_row = {'addnl_info': {"start_cron": "0 8 * * *", "end_cron": "0 18 * * *"}}

        apply_eligibility_check(mock_row, trigger_time_est)

        mock_is_trigger_eligible.assert_called_once_with(mock_row['addnl_info'], trigger_time_est)

def test_process_dataframe(spark):
        data = [("file1", {"start_cron": "0 8 * * *", "end_cron": "0 18 * * *"}),
                ("file2", {"start_cron": "0 7 * * *", "end_cron": "0 17 * * *"})]
        columns = ["id_src_file", "addnl_info"]
        metadata_df = spark.createDataFrame(data, columns)

        trigger_time_est = datetime(2024, 3, 14, 8, 0, 0)

        processed_df = process_dataframe_schema(spark, metadata_df, trigger_time_est)

        expected_columns = ['id_src_file', 'addnl_info', 'is_eligible']
        assert processed_df.columns == expected_columns