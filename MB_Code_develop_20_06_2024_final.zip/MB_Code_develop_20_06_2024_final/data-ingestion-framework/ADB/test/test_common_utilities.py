from ADB.common.common_utilities import read_delta_table,merge_status,merge_dataframe_into_delta, custom_merge_data_into_delta
from pyspark.sql.types import StructType, StructField, StringType,IntegerType
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession, DataFrame

@patch('delta.tables.DeltaTable')
def test_custom_merge_data_into_delta_test1(mock_delta_tbl,spark):
    catlg_nam = 'abc'
    lm_filter_row:dict ={}
    audit_columns:list=[]

    schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
    ])

    # Mock DataFrame to be returned by read_table_with_condition
    input_data_mock = [{"id": 1, "name": "Souvik"}]
    mock_df = spark.createDataFrame(input_data_mock, schema=schema)

    mock_merge_stats = {'operationMetrics': {'merge_status': True}} 
    
    mock_delta_tbl.merge.return_value = mock_df
    mock_delta_tbl.history.return_value.select.return_value.collect.return_value = [mock_merge_stats]

    error, merge_stats, df_update_target = custom_merge_data_into_delta(catlg_nam, mock_df, lm_filter_row, audit_columns)

    assert error is not None and merge_stats['merge_status'] is False and df_update_target == None

@patch('pyspark.sql.SparkSession')
def test_custom_merge_data_into_delta_test2(mock_get_spark):
    # Mocking SparkSession and DeltaTable
    mock_spark = MagicMock(spec=SparkSession)
    mock_delta_table = MagicMock()

    mock_spark.return_value = mock_spark
    mock_spark.sql.return_value = mock_delta_table

    # Sample data
    source_df = mock_spark.createDataFrame([(1, 'A'), (2, 'B')], ['id', 'value'])
    lm_filter_row = {
        'tgt_nam': 'target_table',
        'addnl_info': {
            'merge_joining_cols': 'id'
        }
    }

    # Testing the function
    _, merge_stats, df_update_target = custom_merge_data_into_delta(
        catlg_nam='catalog_name',
        source_dataframe=source_df,
        lm_filter_row=lm_filter_row
    )

    # Assertions
    mock_spark.createDataFrame.assert_called_once_with([(1, 'A'), (2, 'B')], ['id', 'value'])
    assert merge_stats['merge_status'] is False
    assert isinstance(df_update_target, DataFrame) == False

@patch('pyspark.sql.SparkSession.read')
def test_read_delta_table(mock_read_spark):
    mock_read_spark.table.return_value='123'
    output = read_delta_table("test123","testa123")

    assert output=='123'

def test_read_delta_table_exception():
    output = read_delta_table("test123","testa123")
    assert output==None

@patch('delta.tables.DeltaTable')
def test_merge_dataframe_into_delta_test_case_1(mock_delta_tbl, spark):
    # Define the mocked return value for history().select().collect()
    mock_merge_stats = {'operationMetrics': {'merge_status': True}} 

    # Create a MagicMock instance for the DataFrame
    df_mock = MagicMock()

    # Mock the behavior of DeltaTable.forName() and DeltaTable.history().select().collect()
    mock_delta_tbl.forName.return_value = mock_delta_tbl.Mock()
    mock_delta_tbl.history.return_value.select.return_value.collect.return_value = [mock_merge_stats]

    # Call the function being tested
    _, merge_stats = merge_dataframe_into_delta(df_mock, "tgt_tbl", ["id"])

    # Assertions
    assert merge_stats['merge_status'] is not True

@patch('pyspark.sql.SparkSession')
def test_merge_dataframe_into_delta_test_case_2(mock_spark_session):
    # Mocking SparkSession and DeltaTable
    mock_spark = MagicMock(spec=SparkSession)
    mock_delta_table = MagicMock()

    mock_spark_session.return_value = mock_spark
    mock_spark.sql.return_value = mock_delta_table

    # Sample data
    input_df = mock_spark.createDataFrame([(1, 'A'), (2, 'B')], ['id', 'value'])
    target_delta_table = 'target_table'
    merge_columns = ['id']

    # Testing the function
    _, merge_stats = merge_dataframe_into_delta(
        input_dataframe=input_df,
        target_delta_table=target_delta_table,
        merge_columns=merge_columns
    )

    # Assertions
    mock_spark.createDataFrame.assert_called_once_with([(1, 'A'), (2, 'B')], ['id', 'value'])
    assert merge_stats['merge_status'] is False

@patch('pyspark.sql.SparkSession.sql')
def test_merge_status(mock_sql):
    # Define the mocked return value for the SQL query
    mock_operation_metrics = {'operationMetrics': {'merge_status': True}}
    mock_sql.return_value = MagicMock(**mock_operation_metrics)
 
    # Call the function being tested
    _ = merge_status("target_delta_table")
 
    # Assertions
    mock_sql.assert_called_once_with("describe history target_delta_table limit 1")



