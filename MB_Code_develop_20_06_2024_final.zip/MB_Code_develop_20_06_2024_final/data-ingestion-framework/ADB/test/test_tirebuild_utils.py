from ADB.common.custom_json_handling_functions.tirebuild_utils import explode_with_null,explode_without_null,column_mapping
from pyspark.sql import functions as F
from pyspark.sql import SparkSession
spark=SparkSession.builder.appName("test").getOrCreate()



def test_explode_without_null(spark):
    data = [("WDCTG4GB7JJ417581", ["Dakota", "Cincinati"]),("WDCTG4GB7JJ417582", ["Alabama", "Texas", "Virginia"])]
    sample_df = spark.createDataFrame(data, ["VIN", "Factory_Location"])
    result_df = explode_without_null(sample_df, "Factory_Location") 
    expected_data = [("WDCTG4GB7JJ417581","Dakota"), ("WDCTG4GB7JJ417581","Cincinati"), ("WDCTG4GB7JJ417582", "Alabama"),("WDCTG4GB7JJ417582","Texas"),("WDCTG4GB7JJ417582","Virginia")]
    expected_df = spark.createDataFrame(expected_data, ["VIN", "Factory_Location"])
    assert result_df.collect() == expected_df.collect()


def test_explode_with_null(spark):
    data = [("WDCTG4GB7JJ417581", ["Dakota", "Cincinati"]),("WDCTG4GB7JJ417582", ["Alabama", "Texas", "Virginia"]),("WDCTG4GB7JJ417583", [])]
    sample_df = spark.createDataFrame(data,["VIN", "Factory_Location"])
    result_df = explode_with_null(sample_df, "Factory_Location") 
    expected_data = [("WDCTG4GB7JJ417581","Dakota"), ("WDCTG4GB7JJ417581","Cincinati"), ("WDCTG4GB7JJ417582", "Alabama"),("WDCTG4GB7JJ417582","Texas"),("WDCTG4GB7JJ417582","Virginia"),("WDCTG4GB7JJ417583",None)]
    expected_df = spark.createDataFrame(expected_data,  ["VIN", "Factory_Location"])
    assert result_df.collect() == expected_df.collect()


def test_column_mapping(spark):    
    data = [("WDDSJ4EB6JN582736", 4, "New York"), ("WDDZF4JB5JA439712", 4, "Los Angeles"), ("WDDWK4JB7JF656079", 4, "Chicago")]
    sample_df = spark.createDataFrame(data, ["results_VIN", "results_Number_of_Tyres", "results_Factory_Location"])
    column_mapping_dict = {
    "VIN": "results_VIN",
    "Number_of_Tyres": "results_Number_of_Tyres",
    "Factory_Location": "results_Factory_Location"
    }
    result_df = column_mapping(sample_df, column_mapping_dict)
    expected_columns = list(column_mapping_dict.keys())
    assert result_df.columns == expected_columns