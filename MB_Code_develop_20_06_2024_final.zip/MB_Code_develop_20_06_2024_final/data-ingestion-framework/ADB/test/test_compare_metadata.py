from ADB.common.compare_zip_metadata import compare_last_updated_ts_with_watermark
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType,MapType
import unittest
import pytest
import json
from pyspark.sql import SparkSession,DataFrame
from unittest.mock import MagicMock, Mock, patch
 
@patch("ADB.common.watermark_utils.watermark_operations")
def test_compare_last_updated_ts_with_watermark(mock_watermark_operations):
    # Mock the return value of watermark_operations
    mock_watermark_operations.return_value = MagicMock()
    mock_watermark_operations.return_value.select.return_value.collect.return_value = [(datetime(2024, 2, 12, 2, 47, 13),)]

    # Define sample input data
    last_updated_ts_zip = "2024-01-01T00:00:00+00:00"
    zip_file_id = "some_zip_file_id"
    zip_file_name = "some_zip_file_name"
    catlg_nam = "catelog"
    wm_tabl_nam = "watermark_table"

    # Call the function
    compare_status = False  # Default value
    try:
        compare_status = compare_last_updated_ts_with_watermark(last_updated_ts_zip, zip_file_id, zip_file_name, catlg_nam, wm_tabl_nam)
    except Exception as e:
        print("An error occurred:", str(e))

    # Assertions
    assert compare_status is False