from ADB.common.metadata_operations import get_upload_extra_missing_cols,custom_json_handling,remove_zipfile,get_dbutils_widgets,final_col_enrich, get_enrich_col, get_inf_schm_dict,drop_columns_inf_sch,get_good_dup_records,get_bad_dup_records,filter_dataframe,insert_audit_columns,column_rename,column_casting,watermark_read,get_master_details_with_filter,latest_bronze_data_using_watermark,get_silver_schema_records,rename_columns_using_mapping_table,get_col_enrich_list,volume_path_extractor,current_folder_extractor,upload_csv_into_volume,final_upload_csv_to_volume,get_extra_missing_cols_between_landing_and_bronze,move_temp_file,schema_check_and_modify
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,lit
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,IntegerType,MapType, BooleanType
import pytest
from pyspark.sql import SparkSession
from unittest.mock import MagicMock, Mock, patch
from pyspark.sql.utils import AnalysisException

def test_get_inf_schm_dict(spark):
    data = [("table1", "schema1", "col1", "INT"), ("table1", "schema1", "col2", "STRING")]
    columns = ["table_name", "table_schema", "column_name", "data_type"]
    df_information_schema = spark.createDataFrame(data, columns)

    table_name = "table1"
    schema_name = "schema1"
    result = get_inf_schm_dict(table_name, schema_name, df_information_schema)

    expected_result = {"col1": "INT", "col2": "STRING"}
    assert result == expected_result 

def test_schema_check_and_modify(spark):

    schema_name = "`schema1`"
    result = schema_check_and_modify(schema_name)

    expected_result = "schema1"

    assert result == expected_result 
 
def test_drop_columns_inf_sch(spark):
    bronze_data = [("col1", 1, "data1"), ("col2", 2, "data2")]
    bronze_columns = ["col1", "col2", "col3"]
    df_bronze = spark.createDataFrame(bronze_data, bronze_columns)

    info_schema_data = [("table1", "schema1", "col1", "INT"), ("table1", "schema1", "col2", "STRING")]
    info_schema_columns = ["table_name", "table_schema", "column_name", "data_type"]
    df_information_schema = spark.createDataFrame(info_schema_data, info_schema_columns)

    table_name = "table1"
    schema_name = "schema1"
    result = drop_columns_inf_sch(table_name, schema_name, df_information_schema, df_bronze)

    expected_columns = ["col1", "col2"]
    assert set(result.columns) == set(expected_columns)

    for col_name in expected_columns:
        assert col_name in result.columns    

# Define a fixture to create a SparkSession
@pytest.fixture
def spark():
    return SparkSession.builder.appName("pytest_spark").getOrCreate()   

def test_get_good_dup_records(spark):
    # Test case 1: additional_info_lyr_mstr is None
    df_main = spark.createDataFrame([(1, "A", 100), (2, "B", 200)], ["ID", "Name", "Value"])
    additional_info_lyr_mstr = None
    result_df,_,_ = get_good_dup_records(df_main, additional_info_lyr_mstr)
    assert result_df.count()==df_main.count()
    
    # Test case 2: additional_info_lyr_mstr has merge_joining_cols
    additional_info_lyr_mstr = {"merge_joining_cols": "ID"}
    result_df,_,_ = get_good_dup_records(df_main, additional_info_lyr_mstr)
    assert result_df.count() != 1  # Only one unique row based on 'ID'

def test_get_bad_dup_records(spark):
    # Test case 1: Matching dataframes, expecting empty result
    df_main = spark.createDataFrame([(1, "A", 100), (2, "B", 200)], ["ID", "Name", "Value"])
    df_good_records = df_main
    result_df = get_bad_dup_records(df_main, df_good_records)
    assert result_df.count() == 0

    # Test case 2: Non-matching dataframes, expecting same as df_main
    df_good_records = spark.createDataFrame([(1, "A", 100)], ["ID", "Name", "Value"])
    result_df = get_bad_dup_records(df_main, df_good_records)
    assert result_df.count() != df_main.count()

    # Test case 3: Additional columns added to bad records
    df_good_records = spark.createDataFrame([(1, "A", 100, "ExtraData")], ["ID", "Name", "Value", "AdditionalCol"])
    df_main = df_main.withColumn("AdditionalCol", lit("ExtraData"))
    result_df = get_bad_dup_records(df_main, df_good_records)
    assert "AdditionalCol" in result_df.columns

def test_filter_dataframe_equals_operator(spark):
    data = [(1, "A", 100), (2, "B", 200), (3, "C", 300)]
    columns = ["ID", "Name", "Value"]
    sample_data= spark.createDataFrame(data, columns)
    filter_dict = {"ID": {"operator": "==", "ref_value": 2}}
    result_df = filter_dataframe(sample_data, filter_dict)
    assert result_df.count() == 1
    assert result_df.first()["ID"] == 2
    
def test_filter_dataframe_greater_than_operator(spark):
    data = [(1, "A", 100), (2, "B", 200), (3, "C", 300)]
    columns = ["ID", "Name", "Value"]
    sample_data= spark.createDataFrame(data, columns)
    filter_dict = {"Value": {"operator": ">", "ref_value": 200}}
    result_df = filter_dataframe(sample_data, filter_dict)
    assert result_df.count() == 1
    assert result_df.first()["Value"] == 300

def test_filter_dataframe_combined_conditions(spark):
    data = [(1, "A", 100), (2, "B", 200), (3, "C", 300)]
    columns = ["ID", "Name", "Value"]
    sample_data= spark.createDataFrame(data, columns)
    filter_dict = {"ID": {"operator": "==", "ref_value": 2}, "Value": {"operator": ">=", "ref_value": 200}}
    result_df = filter_dataframe(sample_data, filter_dict)
    assert result_df.count() == 1
    assert result_df.first()["ID"] == 2
    assert result_df.first()["Value"] == 200

def test_filter_dataframe_no_conditions(spark):
    data = [(1, "A", 100), (2, "B", 200), (3, "C", 300)]
    columns = ["ID", "Name", "Value"]
    sample_data= spark.createDataFrame(data, columns)
    filter_dict = {}
    result_df = filter_dataframe(sample_data, filter_dict)
    assert result_df.count() == 3  # Should return the original DataFrame

@patch("pyspark.sql.SparkSession.read")
def test_insert_audit_columns(mock_read):
    # Mocking the read method
    spark = SparkSession.builder.appName("test_merge").getOrCreate()

    # Define schema explicitly
    schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("createddt", StringType(), True),
        StructField("rundate", StringType(), True),
        StructField("created_timestamp", StringType(), True),
    ])

    # Mock DataFrame to be passed to the function
    input_data_mock = [{"id": 1, "name": "Souvik", "rundate": "2024-01-16", "created_timestamp": "2024-01-16T17:34:22.648907Z"}]
    mock_df = spark.createDataFrame(input_data_mock, schema=schema)
    mock_read.table.return_value = mock_df

    # Test case with additional_info provided
    catlg_nam = "dummy"
    silver_table_name = "dummy"
    additional_info = {"merge_joining_cols": 'id'}
    audit_columns = ["rundate", "created_timestamp"]

    # Mock DataFrame to be passed to the function
    input_data = [{"id": 1, "name": "Souvik", "rundate": "2024-01-16", "created_timestamp": "2024-01-16T17:34:22.648907Z"}]
    df = spark.createDataFrame(input_data, ["id", "name", "rundate", "created_timestamp"])
    # Call the function with the patched SparkSession.read
    result_df = insert_audit_columns(catlg_nam, silver_table_name, additional_info, df, audit_columns)

    # Add assertions based on your specific requirements
    assert result_df.count() == 1
    assert "rundate" in result_df.columns
    assert "created_timestamp" in result_df.columns
    assert "updated_timestamp" in result_df.columns

def test_column_rename(spark):
    meta_data = [
    (2001, "order_Channel", "string", 4, "orderChannel", "string", "de_test", "2024-01-15T08:43:35.741331Z", "de_test", "2024-01-15T08:43:35.741328Z"),
    (2001, "order_Quantity", "string", 6, "orderQuantity", "int", "de_test", "2024-01-15T08:43:35.741328Z", "de_test", "2024-01-15T08:43:35.741328Z")
    ]
    meta_columns = ["id_mapping", "src_col", "src_col_typ", "fld_pos", "tgt_col", "tgt_col_typ", "created_by", "created_ts", "modified_by", "modified_ts"]
    df_meta = spark.createDataFrame(meta_data, meta_columns)

    target_data = [
    ("SOuvik", 22, 200, "Online", 200, "28-12-2023", "shoes", 1
    , "2023-12-27T07:49:44.077007Z", "28-12-2023", "2023-12-27T07:49:44.077007Z"),
    ("Kamlesh", 31, 500, "Online", 500, "27-12-2023", "shoes", 1, "2023-12-27T07:49:44.077007Z", "28-12-2023", "2023-12-27T07:49:44.077007Z")
    ]


    target_columns = ["name", "age", "orderAmount", "order_Channel", "order_Revenue", "orderDate", "item_name", "order_Quantity", "order_placed_ts", "rundate", "created_timestamp"]
    df_target = spark.createDataFrame(target_data, target_columns)

    col_rename = column_rename(df_meta,df_target,'2001')
    df_final = col_rename.column_rename_final()

    column_names = df_target.columns

    # Create a new DataFrame with a column "src_col" containing the extracted column names
    new_data = [(col,) for col in column_names]
    new_columns = ["df_src_col"]

    new_df = spark.createDataFrame(new_data, new_columns)

    new_df = new_df.join(df_meta,col('df_src_col')==col('src_col'),'full')
    new_df = new_df.withColumn('col_final', when(col('src_col').isNull(),col('df_src_col')).otherwise(col('tgt_col')))
    final_list = [row['col_final'] for row in new_df.select('col_final').collect()]

    assert final_list.sort() == df_final.columns.sort()

# def test_column_casting_date(spark):
#     data = [("John", "1990-01-01", "2022-01-01T12:00:00"), ("Alice", "1985-05-15", "2022-01-01T14:30:00")]
#     schema = StructType([
#         StructField("Name", StringType(), True),
#         StructField("Birthdate", StringType(), True),
#         StructField("EventTimestamp", StringType(), True)
#     ])
#     sample_data=spark.createDataFrame(data, schema)
#     typecast_dict = {"Birthdate": "DATE"}
#     result_df,_,_ = column_casting(sample_data, typecast_dict)
#     assert result_df.schema["Birthdate"].dataType == DateType()

def test_column_casting_timestamp(spark):
    data = [("John", "1990-01-01", "2022-01-01T12:00:00"), ("Alice", "1985-05-15", "2022-01-01T14:30:00")]
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data=spark.createDataFrame(data, schema) 
    typecast_dict = {"EventTimestamp": "TIMESTAMP"}
    result_df,_,_= column_casting(sample_data, typecast_dict)
    assert result_df.schema["EventTimestamp"].dataType == TimestampType()

def test_column_casting_numeric(spark):
    data = [("John", "1990-01-01", "2022-01-01T12:00:00"), ("Alice", "1985-05-15", "2022-01-01T14:30:00")]
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data=spark.createDataFrame(data, schema)
    typecast_dict = {"Name": "STRING"}
    result_df,_,_ = column_casting(sample_data, typecast_dict)
    assert result_df.schema["Name"].dataType == StringType()  # Should remain StringType

def test_column_casting_default_date_format(spark):
    data = [("John", "1990-01-01", "2022-01-01T12:00:00"), ("Alice", "1985-05-15", "2022-01-01T14:30:00")]
    
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data=spark.createDataFrame(data, schema)
    typecast_dict = {"Birthdate": "DATE"}
    result_df,_,_ = column_casting(sample_data, typecast_dict)
    assert result_df.schema["Birthdate"].dataType == DateType()

@patch("pyspark.sql.SparkSession.read")
def test_get_master_details_with_filter(mock_read):
    # Mocking the read method
    spark = SparkSession.builder.appName("test_get_master").getOrCreate()
 
    # Define schema explicitly
    schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        ])
 
    # Mock DataFrame to be returned by read_table_with_condition
    input_data_mock = [{"id": 1, "name": "Souvik"}]
    mock_df = spark.createDataFrame(input_data_mock, schema=schema)
    mock_read.table.return_value = mock_df
 
    # Test case with filter_condition provided
    catlg_nam = "test_catelog"
    table_name = "test_table"
    filter_condition_1 = {"id": 1}
    filter_condition_2 = {"id": 10}
 
    # Call the function with the patched SparkSession.read
    result_row, success ,_= get_master_details_with_filter(catlg_nam, table_name, filter_condition_1)
    #call the function with false filter condition
    result_row_2, success_2 ,_= get_master_details_with_filter(catlg_nam, table_name, filter_condition_2)
 
    # Add assertions based on your specific requirements
    assert success is True
    assert result_row["id"] == 1
    assert result_row["name"] == "Souvik"
 
    assert success_2 is False
    assert len(result_row_2)==0
 
    mock_read.table.side_effect = AnalysisException("Error reading layer master")
    catlg_nam = "test_catelog"
    table_name = "test_table"
    filter_condition = {"id": 1}
    result_row, success, _ = get_master_details_with_filter(catlg_nam, table_name, filter_condition)
    assert success is False
   
 
    # Test case 2: No data found in the data layer
    mock_read.table.return_value = spark.createDataFrame([], StructType([]))
    result_row, success, _ = get_master_details_with_filter(catlg_nam, table_name, filter_condition)
    assert success is False

def test_column_casting_empty_dataframe(spark):
    # Test case for empty DataFrame
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    empty_data = spark.createDataFrame([], schema)
    typecast_dict = {"Birthdate": "DATE"}
    result_df, success, _ = column_casting(empty_data, typecast_dict)
    assert result_df is not None
    assert success is True
 
def test_column_casting_invalid_typecasting(spark):
    # Test case for invalid typecasting
    data = [("John", "1990-01-01", "2022-01-01T12:00:00")]
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data = spark.createDataFrame(data, schema)
    typecast_dict = {"Birthdate": "INVALID_TYPE"}
    result_df, success, _ = column_casting(sample_data, typecast_dict)
    assert result_df is None
    assert success is False
 
def test_column_casting_invalid_date_format(spark):
    # Test case for invalid date format
    data = [("John", "1990-01-01", "2022-01-01T12:00:00")]
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data = spark.createDataFrame(data, schema)
    typecast_dict = {"Birthdate": "DATE"}
    result_df, success, _ = column_casting(sample_data, typecast_dict, date_format='yyyy-MM-dd')
    assert result_df is not None
    assert success is True
   
 
def test_column_casting_invalid_timestamp_format(spark):
    # Test case for invalid timestamp format
    data = [("John", "1990-01-01", "2022-01-01T12:00:00")]
    schema = StructType([
        StructField("Name", StringType(), True),
        StructField("Birthdate", StringType(), True),
        StructField("EventTimestamp", StringType(), True)
    ])
    sample_data = spark.createDataFrame(data, schema)
    typecast_dict = {"EventTimestamp": "TIMESTAMP"}
    # Provide an invalid timestamp format (e.g., 'yyyy-MM-dd HH:mm:ss' instead of 'dd-MM-yyyy HH:mm:ss')
    result_df, success, _ = column_casting(sample_data, typecast_dict, timestamp_format='yyyy-MM-dd HH:mm:ss')
    assert result_df is not None
    assert success is True

@patch("pyspark.sql.SparkSession.read")
def test_latest_bronze_data_using_watermark(mock_read):
    # Mocking the read method
    spark = SparkSession.builder.appName("test_watermark").getOrCreate()
 
    # Define schema explicitly
    schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("created_timestamp", StringType(), True),
        StructField("proc_started_ts", StringType(), True),
    ])
 
    # Mock DataFrame to be returned by watermark_operations
    input_data_watermark = [
        {"id": 1, "name": "Souvik", "created_timestamp": "2024-01-16", "proc_started_ts": "2024-01-16T17:34:22.648907Z"}
    ]
    watermark_df = spark.createDataFrame(input_data_watermark, schema=schema)
    mock_read.table.return_value = watermark_df
 
    # Mock DataFrame to be returned by read_delta_table
    input_data_bronze = [
        {"id": 1, "name": "Souvik", "created_timestamp": "2024-01-17T17:34:22.648907Z"}
    ]
    bronze_df = spark.createDataFrame(input_data_bronze, schema=schema)
    mock_read.table.return_value = bronze_df
 
    # Test case with condition provided
    catlg_nam = "dummy"
    watermark_table = "watermark_dummy"
    bronze_table = "bronze_dummy"
    condition = {"id": 1}
 
    # Call the function with the patched SparkSession.read
    result_df, _, _ = latest_bronze_data_using_watermark(catlg_nam, watermark_table, bronze_table, condition)
 
    # Add assertions based on your specific requirements
    assert result_df.count() == 1
    assert "id" in result_df.columns
    assert "name" in result_df.columns
    assert "created_timestamp" in result_df.columns
    assert "proc_started_ts" in result_df.columns
 
    condition = {}
    result_df, _, _ = latest_bronze_data_using_watermark(catlg_nam, watermark_table, bronze_table, condition)
    assert result_df.count() != 3
   
@patch("pyspark.sql.SparkSession.read")
def test_latest_bronze_data_using_watermark_exception(mock_read):
    # Mocking the read method
    spark = SparkSession.builder.appName("test_watermark").getOrCreate()
 
    # Test case 1: Error during watermark operations
    mock_read.table.side_effect = Exception("Error during watermark operations")
    catlg_nam = "dummy"
    watermark_table = "watermark_dummy"
    bronze_table = "bronze_dummy"
    condition = {"id": 1}
    _, success, _ = latest_bronze_data_using_watermark(catlg_nam, watermark_table, bronze_table, condition)
    assert success is False
   
 
    # Test case 2: Error during read_delta_table
    mock_read.table.side_effect = [spark.createDataFrame([], StructType([]))]  # Return empty DataFrame for watermark operations
    mock_read.table.side_effect = Exception("Error during read_delta_table")
    _, success, _ = latest_bronze_data_using_watermark(catlg_nam, watermark_table, bronze_table, condition)
    assert success is False
 
    # Test case 3: Error during filter_dataframe
    mock_read.table.side_effect = [spark.createDataFrame([], StructType([]))]  # Return empty DataFrame for watermark operations
    mock_read.table.side_effect = [spark.createDataFrame([], StructType([]))]  # Return empty DataFrame for read_delta_table
    mock_filter_dataframe = MagicMock()
    mock_filter_dataframe.side_effect = Exception("Error during filter_dataframe")
    with patch("ADB.common.metadata_operations.filter_dataframe", mock_filter_dataframe):
        _, success, _ = latest_bronze_data_using_watermark(catlg_nam, watermark_table, bronze_table, condition)
        assert success is False

@patch("pyspark.sql.SparkSession.read")
def test_get_silver_schema_records(mock_read):
    # Mocking the read_delta_table method
    spark = SparkSession.builder.appName("test_silver_schema").getOrCreate()
 
    # Define schema for information_schema
    information_schema_schema = StructType([
        StructField("column_name", StringType(), True),
        StructField("data_type", StringType(), True),
        StructField("table_name", StringType(), True),
        StructField("table_schema", StringType(), True),
    ])
 
    # Mock DataFrame to be returned by read_delta_table for information_schema
    input_data_info_schema = [
        {"column_name": "id", "data_type": "int", "table_name": "dummy", "table_schema": "silver_table"},
        {"column_name": "name", "data_type": "string", "table_name": "dummy", "table_schema": "silver_table"},
    ]
    info_schema_df = spark.createDataFrame(input_data_info_schema, schema=information_schema_schema)
    mock_read.table.return_value = info_schema_df
 
    # Define schema for input DataFrame (df)
    input_data_schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("created_timestamp", StringType(), True),
    ])
 
    # Mock DataFrame to be passed to the function
    input_data = [
        {"id": 1, "name": "Souvik", "created_timestamp": "2024-01-16T17:34:22.648907Z"}
    ]
    df = spark.createDataFrame(input_data, schema=input_data_schema)
 
    # Test case with additional_info provided
    catlg_nam = "dummy"
    silver_table_name = "dummy.silver_table"
    information_schema_table = "dummy.information_schema"
    silver_audit_columns = ["rundate", "created_timestamp"]
    bronze_audit_columns = ["proc_started_ts"]
 
    # Call the function with the patched SparkSession.read
    result_df, typecast_dict, _, _ = get_silver_schema_records(df, catlg_nam, silver_table_name, information_schema_table, silver_audit_columns, bronze_audit_columns)
 
    # Add assertions based on your specific requirements
    assert "id" not in result_df.columns
    assert "name" not in result_df.columns
    assert "created_timestamp" not in result_df.columns
    assert "rundate" not in result_df.columns
    assert "created_timestamp" not in result_df.columns
    # Add more assertions based on your requirements for the resulting DataFrame
    assert typecast_dict != {"id": "int", "name": "string"}  
 
@patch("ADB.common.common_utilities.read_delta_table")
def test_get_silver_schema_records_exception(mock_read,spark):
    # Mocking the read_delta_table method to raise an exception
    mock_read.side_effect = Exception("Error fetching information schema data")
 
    # Define input DataFrame (df) schema
    input_data_schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("created_timestamp", StringType(), True),
    ])
 
    # Mock DataFrame to be passed to the function
    input_data = [
        {"id": 1, "name": "Souvik", "created_timestamp": "2024-01-16T17:34:22.648907Z"}
    ]
    df = spark.createDataFrame(input_data, schema=input_data_schema)
 
    # Test case with additional_info provided
    catlg_nam = "dummy"
    silver_table_name = "dummy.silver_table"
    information_schema_table = "dummy.information_schema"
    silver_audit_columns = ["rundate", "created_timestamp"]
    bronze_audit_columns = ["proc_started_ts"]
 
    # Call the function
    result_df, typecast_dict, success, _ = get_silver_schema_records(
        df, catlg_nam, silver_table_name, information_schema_table, silver_audit_columns, bronze_audit_columns)
 
    # Assertions
    assert success is False
    assert result_df is None
    assert typecast_dict is None

@patch("ADB.common.metadata_operations.read_delta_table")
def test_get_col_enrich_list_success(read_delta_table_mock,spark):

    input_data = [
         ("123ab","trgt_col_to_enrich")
    ]
    input_data_schema = StructType([
        StructField("id_mapping", StringType(), True),
        StructField("trgt_col_to_enrich", StringType(), True)
       
    ])
    df = spark.createDataFrame(input_data, schema=input_data_schema)
    df_mock = Mock()
    read_delta_table_mock.return_value = df
    layer_master_row={"mapping_id":"123ab"}
    # Sample input data
    catalog_name = df_mock.Mock()
    col_enrich_table = df_mock.Mock()
 
    # Calling the function
    col_enrich_list = get_col_enrich_list(catalog_name, col_enrich_table, layer_master_row)
 
    # Assertions
    assert col_enrich_list == ["trgt_col_to_enrich"]

@patch('ADB.common.metadata_operations.read_delta_table')
def test_get_enrich_col(mock_read_delta_table):
    spark = SparkSession.builder.appName("test_merge").getOrCreate()
    schema = StructType([
        StructField('id_mapping', StringType(), False),
        StructField('trgt_col_to_enrich', StringType(), False),
        StructField('trgt_col_dytp', StringType(), True),
        StructField('enrich_proc_spec', MapType(StringType(), StringType(), True), True),
        StructField('dts_dw_crea', TimestampType(), False),
        StructField('id_dw_crea_user', StringType(), False),
        StructField('dts_dw_updt', TimestampType(), False),
        StructField('id_dw_updt_user', StringType(), False)]
        )
 
    input_data_mock = [{'id_mapping': '2001',
                        'trgt_col_to_enrich': 'full_name',
                        'trgt_col_dytp': 'string',
                        'enrich_proc_spec': {'ce_name': 'concat_strings',
                                                'ce_parameters': 'fname,lname',
                                                'ce_type': 'function',
                                                'ce_operation_desc': 'concatenate existing columns'},
                        'dts_dw_crea': datetime.now(),
                        'id_dw_crea_user': 'de-test',
                        'dts_dw_updt': datetime.now(),
                        'id_dw_updt_user': 'de-test'},
                        {'id_mapping': '2001',
                         'trgt_col_to_enrich': 'mname',
                         'trgt_col_dytp': 'string',
                         'enrich_proc_spec': {'ce_name': 'split_name',
                                              'ce_parameters': '{"cols":"fm_name","delimiter":",","position":"1"}',
                                              'ce_type': 'function',
                                              'ce_operation_desc': 'concatenate existing columns'},
                            'dts_dw_crea': datetime.now(),
                            'id_dw_crea_user': 'de-test',
                            'dts_dw_updt': datetime.now(),
                            'id_dw_updt_user': 'de-test'},
                        {'id_mapping': '2001',
                        'trgt_col_to_enrich': 'total_order',
                        'trgt_col_dytp': 'float',
                        'enrich_proc_spec': {'ce_name': 'product_of_columns',
                                             'ce_parameters': 'orderQuantity,orderAmount',
                                             'ce_type': 'function',
                                             'ce_operation_desc': 'multiply existing columns'},
                        'dts_dw_crea': datetime.now(),
                        'id_dw_crea_user': 'de-test',
                        'dts_dw_updt': datetime.now(),
                        'id_dw_updt_user': 'de-test'}
  ]
    df_col_enrich = spark.createDataFrame(input_data_mock, schema=schema)
    mock_read_delta_table.return_value = df_col_enrich
 
    mock_df = MagicMock()
 
    catlg_nam = mock_df.MagicMock()
    col_enrich_table = mock_df.MagicMock()
    layer_master_row = {}
    layer_master_row['mapping_id'] = '2001'
 
    table_columns = ["fname", "lname","orderQuantity","orderAmount"]
    table_data = [("usama", "ansari","10","50"), ("Raj","Kapoor","20","7")]
 
    df_test = spark.createDataFrame(table_data, table_columns)
 
    target_col_enrich = 'full_name'
    df_result, error = get_enrich_col(catlg_nam, col_enrich_table, df_test ,target_col_enrich,layer_master_row)
    output_list = [row[target_col_enrich] for row in df_result.select(target_col_enrich).collect()]
    expected_results = ['usama ansari','Raj Kapoor']
    assert expected_results == output_list and error == None
 
    target_col_enrich = 'total_order'
    df_result, error = get_enrich_col(catlg_nam, col_enrich_table, df_test ,target_col_enrich,layer_master_row)
    output_list = [row[target_col_enrich] for row in df_result.select(target_col_enrich).collect()]
    expected_results = [500,140]
    assert expected_results == output_list and error == None
 
    table_data = [("usama", "ansari","abc","50"), ("Raj","Kapoor","20","7")]
    df_test = spark.createDataFrame(table_data, table_columns)
    target_col_enrich = 'total_order'
    df_result, error = get_enrich_col(catlg_nam, col_enrich_table, df_test ,target_col_enrich,layer_master_row)
    output_list = [row[target_col_enrich] for row in df_result.select(target_col_enrich).collect()]
    expected_results = [None,140]
    assert expected_results == output_list and error == None
 
    table_data = [("usama", "ansari","abc","50"), ("Raj","Kapoor","xyz","7")]
    df_test = spark.createDataFrame(table_data, table_columns)
    target_col_enrich = 'total_order'
    df_result, error = get_enrich_col(catlg_nam, col_enrich_table, df_test ,target_col_enrich,layer_master_row)
    assert df_result==None and error == 'column orderQuantity is not convertable to float'

@patch("ADB.common.metadata_operations.get_col_enrich_list")
@patch("ADB.common.metadata_operations.get_enrich_col")
def test_final_col_enrich_success(get_enrich_col_mock, get_col_enrich_list_mock):
    # Define SparkSession
    spark = SparkSession.builder.appName("test").getOrCreate()
    
    # Define input data
    input_data = [
         ("123ab", "trgt_col_to_enrich")
    ]
    input_data_schema = StructType([
        StructField("id_mapping", StringType(), True),
        StructField("trgt_col_to_enrich", StringType(), True)
    ])
    df = spark.createDataFrame(input_data, schema=input_data_schema)
    
    # Mock get_col_enrich_list function
    get_col_enrich_list_mock.return_value = ["trgt_col_to_enrich"]
    
    # Mock get_enrich_col function to simulate successful enrichment
    get_enrich_col_mock.return_value = df, None
    
    # Sample input data
    catalog_name = "UnityCatalog"
    column_enrich_table = "schema.col_enrich_table"
    layer_master_row = {"mapping_id": "123ab"}
    
    # Call the function
    result_df, error = final_col_enrich(df, catalog_name, column_enrich_table, layer_master_row)
    
    # Assertions
    assert result_df is df
    assert error is None

@patch("ADB.common.metadata_operations.get_col_enrich_list")
@patch("ADB.common.metadata_operations.get_enrich_col")
def test_final_col_enrich_failure(get_enrich_col_mock, get_col_enrich_list_mock):
    # Define SparkSession
    spark = SparkSession.builder.appName("test").getOrCreate()
    
    # Define input data
    input_data = [
         ("123ab", "trgt_col_to_enrich")
    ]
    input_data_schema = StructType([
        StructField("id_mapping", StringType(), True),
        StructField("trgt_col_to_enrich", StringType(), True)
    ])
    df = spark.createDataFrame(input_data, schema=input_data_schema)
    
    # Mock get_col_enrich_list function
    get_col_enrich_list_mock.return_value = ["trgt_col_to_enrich"]
    
    # Mock get_enrich_col function to simulate enrichment failure
    get_enrich_col_mock.return_value = None, "Error occurred"
    
    # Sample input data
    catalog_name = "UnityCatalog"
    column_enrich_table = "schema.col_enrich_table"
    layer_master_row = {"mapping_id": "123ab"}
    
    # Call the function
    result_df, error = final_col_enrich(df, catalog_name, column_enrich_table, layer_master_row)
    
    # Assertions
    assert result_df is None
    assert error == "Error occurred"

def test_volume_path_extractor():
    import datetime
    watermark_dict = {'id_src_file': 'f_fw_orders_csv1', 'lvl_lyr': 2, 'filename': 'orders_20240219.csv', 
                      'filepath': '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/orders/2024-02-19/02_14_40/', 
                      'id_batch': 'orders_2024-02-19.zip_2024-02-12T02:47:13.2088668Z', 
                      'proc_started_ts': datetime.datetime(2024, 2, 20, 6, 21, 33, 830675), 
                      'run_date': datetime.date(2024, 2, 20), 'oper_phase': 'BRONZE_TO_SILVER', 'user_name': 'USSHAHI', 'oper_stat': 5
                      }
    path_position = 5

    result = volume_path_extractor(watermark_dict, path_position)

    assert '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone' == result

def test_current_folder_extractor():
    import datetime
    watermark_dict = {'id_src_file': 'f_fw_orders_csv1', 'lvl_lyr': 2, 'filename': 'orders_20240219.csv', 
                      'filepath': '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/orders/2024-02-19/02_14_40/', 
                      'id_batch': 'orders_2024-02-19.zip_2024-02-12T02:47:13.2088668Z', 
                      'proc_started_ts': datetime.datetime(2024, 2, 20, 6, 21, 33, 830675), 
                      'run_date': datetime.date(2024, 2, 20), 'oper_phase': 'BRONZE_TO_SILVER', 'user_name': 'USSHAHI', 'oper_stat': 5
                      }
    
    date_position:int = 6
    time_position:int = 7

    result = current_folder_extractor(watermark_dict,date_position,time_position)

    assert '2024-02-19/02_14_40' == result

@patch("pyspark.sql.DataFrame.write")
def test_upload_csv_into_volume(mock_spark_write,spark):
    import datetime
    watermark_dict = {'id_src_file': 'f_fw_orders_csv1', 'lvl_lyr': 2, 'filename': 'orders_20240219.csv', 
                      'filepath': '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/orders/2024-02-19/02_14_40/', 
                      'id_batch': 'orders_2024-02-19.zip_2024-02-12T02:47:13.2088668Z', 
                      'proc_started_ts': datetime.datetime(2024, 2, 20, 6, 21, 33, 830675), 
                      'run_date': datetime.date(2024, 2, 20), 'oper_phase': 'BRONZE_TO_SILVER', 'user_name': 'USSHAHI', 'oper_stat': 5
                      }

    data = [("1", "Souvik"), ("2", "Manish")]
    columns = ["id", "name"]
    df = spark.createDataFrame(data, columns)

    volume_path = '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone' 
    folder_name = 'bar_records'
    current_date_folder = '2024-02-19/02_14_40'
    sub_folder=None
    mode='append'

    mock_spark_write.return_value = MagicMock()
    result = upload_csv_into_volume(df,watermark_dict,volume_path,folder_name,current_date_folder,sub_folder,mode)

    assert result[0] is True

@patch("pyspark.sql.DataFrame.write")
def test_upload_csv_into_volume_exception(mock_spark_write):
    # Test case 1: Error during DataFrame write
    mock_spark_write.side_effect = Exception("Error during DataFrame write")
    df = MagicMock()
    watermark_dict = {'filename': 'test.csv'}
    volume_path = '/volume/path'
    folder_name = 'test_folder'
    current_date_folder = '2024-04-20'
    result, file_path = upload_csv_into_volume(df, watermark_dict, volume_path, folder_name, current_date_folder)
    assert result is True
    assert file_path == f'{volume_path}/{folder_name}/{current_date_folder}/{watermark_dict["filename"]}'
 
    # Test case 2: DataFrame is empty
    mock_spark_write.side_effect = None  # Reset side effect
    df.count.return_value = 0
    result, file_path = upload_csv_into_volume(df, watermark_dict, volume_path, folder_name, current_date_folder)
    assert result is False
    assert file_path == f'{volume_path}/{folder_name}/{current_date_folder}/{watermark_dict["filename"]}'
 
    # Test case 3: Other exceptions
    mock_spark_write.side_effect = None  # Reset side effect
    mock_spark_write.return_value = MagicMock()  # Reset return value
    df.count.return_value = 2  # Set DataFrame count to non-zero
    mock_spark_write.return_value.csv.side_effect = Exception("Other error")
    result, file_path = upload_csv_into_volume(df, watermark_dict, volume_path, folder_name, current_date_folder)
    assert result is True
    assert file_path == f'{volume_path}/{folder_name}/{current_date_folder}/{watermark_dict["filename"]}'

@patch("pyspark.sql.DataFrame.write")
def test_final_upload_csv_to_volume(mock_spark_write,spark):
    import datetime
    watermark_dict = {'id_src_file': 'f_fw_orders_csv1', 'lvl_lyr': 2, 'filename': 'orders_20240219.csv', 
                      'filepath': '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/orders/2024-02-19/02_14_40/', 
                      'id_batch': 'orders_2024-02-19.zip_2024-02-12T02:47:13.2088668Z', 
                      'proc_started_ts': datetime.datetime(2024, 2, 20, 6, 21, 33, 830675), 
                      'run_date': datetime.date(2024, 2, 20), 'oper_phase': 'BRONZE_TO_SILVER', 'user_name': 'USSHAHI', 'oper_stat': 5
                      }

    data = [("1", "Souvik"), ("2", "Manish")]
    columns = ["id", "name"]

    df = spark.createDataFrame(data, columns)
    mock_spark_write.return_value = MagicMock()

    folder_name = 'bar_records'
    volume_position = 5
    date_position = 6
    time_position = 7
    sub_folder = None
    mode = 'append'
    
    result = final_upload_csv_to_volume(df,watermark_dict,folder_name,volume_position,date_position,time_position,sub_folder,mode)

    assert result[0] is True

def test_remove_zipfile():
   mock_dbutils = MagicMock()
   remove_zipfile(dbutils=mock_dbutils, zip_path = '/abc')
 
   mock_dbutils.fs.rm.assert_called_once_with("/abc")

def test_get_dbutils_widgets():
   mock_dbutils = MagicMock()
   layer = 'landing'
   mock_dbutils.widgets.get.return_value = "filename"

   result = get_dbutils_widgets(dbutils=mock_dbutils,layer=layer)

   assert result.get('id_src_file') == 'filename' and result.get('lvl_lyr') == 0 and result.get('filename') == 'filename' \
    and result.get('filepath') == 'filename' and result.get('id_batch') == 'filename'
   
   mock_dbutils = MagicMock()
   layer = 'pre-processing'
   mock_dbutils.widgets.get.return_value = "filename"

   result = get_dbutils_widgets(dbutils=mock_dbutils,layer=layer)
   assert result.get('id_src_file') == 'filename' and result.get('oper_phase') == 'filename' \
    and result.get('oper_stat') == 'filename' and result.get('id_batch') == 'filename'
   
   mock_dbutils = MagicMock()
   layer = ''
   mock_dbutils.widgets.get.return_value = "2"

   result = get_dbutils_widgets(dbutils=mock_dbutils,layer=layer)

   assert result.get('id_src_file') == '2' and result.get('filename') == '2' \
    and result.get('filepath') == '2' and result.get('id_batch') == '2'

@patch("pyspark.sql.DataFrame.write")
@patch("ADB.common.metadata_operations.get_master_details_with_filter")
@patch("ADB.common.common_utilities.read_delta_table")
def test_get_upload_extra_missing_cols(mock_read,mock_mdwf,mock_write,spark):

    import datetime

    input_main_data = [
        ['Usama', 'Shahid', 'ABC', 'Online', '200', '28-12-2023', 'shoes', '1', '2023-12-27T07:49:44.077007Z', 'Usama,A', '200'], 
        ['Kamlesh', 'Kumar', '31', 'Online', '500', 'corrupt DATE', 'Phone', '2', '2023-12-27T07:49:44.077007Z', 'Kamlesh,A', '500'], 
        ['Manish', 'Kamboj', '56', 'Offline', '1000', '26-12-2023', 'shoes', '1', '2023-12-27T07:49:44.077007Z', 'Manish,A', '1000'], 
        ['Souvik', 'Nag', '21', 'Online', '400', '27-12-2023', 'book', '3', '2023-12-27T07:49:44.077007Z', 'Souvik,B', '400'], 
        ['Nirnab', 'Chowdhury', '25', 'Online', '300', '28-12-2023', 'shoes', '1', '2023-12-27T07:49:44.077007Z', 'Nirnab,B', '300'], 
        ['Raj', 'Mishra', '34', 'Offline', '800', '27-12-2023', 'shoes', '4', '2023-12-27T07:49:44.077007Z', 'Raj,B', '800'], 
        ['Ajay', 'Singh', '12', 'Offline', '900', '27-12-2023', 'stationary', '2', '2023-12-27T07:49:44.077007Z', 'Ajay,C', '900'], 
        ['Kapil', 'Sharma', '23', 'Online', '600', '27-12-2023', 'shoes', '4', '2023-12-27T07:49:44.077007Z', 'Kapil,C', '600'], 
        ['Kapil', 'Sharma', '23', 'Online', '600', '27-12-2023', 'shoes', '3', '2023-12-27T07:49:44.077007Z', 'Kapil,C', '600'], 
        ['Usama', 'Shahid', '12', 'Offline', '900', '27-12-2023', 'stationary', '6', '2023-12-27T07:49:44.077007Z', 'Usama,D', '900'], 
        ['Kamlesh', 'Kumar', '34', 'Online', '700', '27-12-2023', 'shoes', '10', '2023-12-27T07:49:44.077007Z', 'Kamlesh,D', '700']
    ]

    input_main_schema = StructType([
        StructField('fname', StringType(), True), 
        StructField('lname', StringType(), True), 
        StructField('age', StringType(), True), 
        StructField('order_Channel', StringType(), True), 
        StructField('order_Revenue', StringType(), True), 
        StructField('orderDate', StringType(), True), 
        StructField('item_name', StringType(), True), 
        StructField('order_Quantity', StringType(), True), 
        StructField('order_placed_ts', StringType(), True), 
        StructField('fm_name', StringType(), True), 
        StructField('orderAmount', StringType(), True)
    ])

    input_data_1 = [
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'rundate', 'DATE'],
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'orderAmount', 'DECIMAL'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'fname', 'STRING'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'orderQuantity', 'INT'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'order_placed_ts', 'TIMESTAMP'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'mname', 'STRING'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'created_timestamp', 'TIMESTAMP'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'total_order', 'FLOAT'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'age', 'INT'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'orderDate', 'DATE'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'lname', 'STRING'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'full_name', 'STRING'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'updated_timestamp', 'TIMESTAMP'], 
        ['new_orders_silver_table', 'xtous_us_12_test_framework', 'orderChannel', 'STRING']
    ]
    input_data_schema_1 = StructType([
        StructField("table_name", StringType(), True),
        StructField("table_schema", StringType(), True),
        StructField("column_name", StringType(), True),
        StructField("data_type", StringType(), True)
    ])

    input_data_schema_2 = StructType([
        StructField('id_mapping', StringType(), False), 
        StructField('src_col', StringType(), False), 
        StructField('src_col_typ', StringType(), True), 
        StructField('fld_pos', StringType(), True), 
        StructField('tgt_col', StringType(), False), 
        StructField('tgt_col_typ', StringType(), True), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
    ])
    input_data_2 =[
        ['m_fw_orders_2001', 'order_Channel', 'string', '4', 'orderChannel', 'string', datetime.datetime(2024, 2, 12, 9, 32, 21, 380000), 'de-test', datetime.datetime(2024, 2, 12, 9, 32, 21, 380000), 'de-test'], 
        ['m_fw_orders_2001', 'order_Quantity', 'string', '4', 'orderQuantity', 'int', datetime.datetime(2024, 2, 12, 9, 32, 24, 438000), 'de-test', datetime.datetime(2024, 2, 12, 9, 32, 24, 438000), 'de-test']
    ]

    input_data_schema_3 = StructType([StructField('id_mapping', StringType(), False), StructField('trgt_col_to_enrich', StringType(), False)])
    input_data_3 = [['m_fw_orders_2001', 'full_name'], ['m_fw_orders_2001', 'mname'], ['m_fw_orders_2001', 'total_order']]

    df = spark.createDataFrame(input_main_data, schema=input_main_schema)
    df2 = spark.createDataFrame(input_data_1, schema=input_data_schema_1)
    df3 = spark.createDataFrame(input_data_2, schema=input_data_schema_2)
    df4 = spark.createDataFrame(input_data_3, schema=input_data_schema_3)

    mock_read.side_effect = [df2,df3,df4]

    watermark_dict = {'id_src_file': 'f_fw_orders_csv2', 'lvl_lyr': 1, 'filename': 'orderstest_20240226.csv', 
                      'filepath': '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/landing/02-26-2024/08_56_41/', 
                      'id_batch': 'orders_2024-02-26.zip_2024-02-23T02:00:00.5837270Z', 'proc_started_ts': datetime.datetime(2024, 2, 26, 11, 0, 39, 388699), 
                      'run_date': datetime.date(2024, 2, 26), 'oper_phase': 'LANDING_TO_BRONZE', 'user_name': 'USSHAHI', 'oper_stat': 5}

    lm_filter_row = {'mapping_id': 'm_fw_orders_2001', 
                     'tgt_nam': 'xtous_us_12_test_framework.new_orders_silver_table', 
                     'addnl_info': {'merge_joining_cols': 'fname,lname,age'}}
    lm_flag = True
    mock_mdwf.return_value = lm_filter_row, lm_flag
    mock_write.return_value = MagicMock()

    catlg_nam = 'my_catelog'
    watermark_table = 'my_watermark_table'
    information_schema_table = 'my_information_schema_table'
    layer_table = 'my_layer_table'
    mapping_table ='my_mapping_table'
    col_enrich_table = 'my_col_enrich_table'
    audit_columns = ['rundate', 'created_timestamp', 'updated_timestamp']

    _, upload_status ,_,_= get_upload_extra_missing_cols(
        df, catlg_nam,watermark_table,information_schema_table,layer_table,mapping_table,
        col_enrich_table,audit_columns, watermark_dict)

    assert upload_status is not True 
    
@patch('ADB.common.common_utilities.read_delta_table')
@patch('ADB.common.metadata_operations.get_master_details_with_filter')
def test_get_upload_extra_missing_cols_no_data_found(mock_mdwf, mock_read,spark):
    mock_mdwf.return_value = None, False  # Simulate no data found in Layer Master
    mock_read.return_value = spark.createDataFrame([], schema=StructType([]))  # Simulate empty DataFrame for watermark
    # Call the function under test
    df_bad_records, upload_status,_, _ = get_upload_extra_missing_cols(
        df=None, catlg_nam='test_catelog', watermark_table='test_watermark',
        information_schema_table='test_info_schema', layer_table='test_layer_table',
        mapping_table='test_mapping_table', col_enrich_table='test_col_enrich_table',
        audit_columns=['rundate', 'created_timestamp'], watermark_dict={})
    assert df_bad_records is None
    assert upload_status is None
 
@patch('ADB.common.common_utilities.read_delta_table')
@patch('ADB.common.metadata_operations.get_master_details_with_filter')
def test_get_upload_extra_missing_cols_exception(mock_mdwf, mock_read,spark):
    mock_mdwf.side_effect = Exception("Error fetching Layer Master data")
    mock_read.return_value = spark.createDataFrame([], schema=StructType([]))  # Simulate empty DataFrame for watermark
    # Call the function under test
    df_bad_records, upload_status, _,_ = get_upload_extra_missing_cols(
        df=None, catlg_nam='test_catelog', watermark_table='test_watermark',
        information_schema_table='test_info_schema', layer_table='test_layer_table',
        mapping_table='test_mapping_table', col_enrich_table='test_col_enrich_table',
        audit_columns=['rundate', 'created_timestamp'], watermark_dict={})
    assert df_bad_records is None
    assert upload_status is None

@patch("pyspark.sql.SparkSession.read")
def test_get_extra_missing_cols_between_landing_and_bronze(mock_read_delta_table,spark):
    data = [
    (1, 'A', True),
    (2, 'B', False),
    (3, 'C', True)
]

# Define column names
    columns = ['col1', 'col2', 'col3']
    BRONZE_AUDIT_COLUMNS = ['col1','col2']
# Create DataFrame
    df_bronze_table = spark.createDataFrame(data, columns)
    df_bronze_table= df_bronze_table.drop(*BRONZE_AUDIT_COLUMNS)
    mock_read_delta_table.table.return_value = df_bronze_table
    mock_df = MagicMock()
    # Define inputs
    bronze_table_name = mock_df.MagicMock()
    source_columns = ['col1', 'col2', 'col3']   # Define your source columns here
    extra_cols, missing_cols = get_extra_missing_cols_between_landing_and_bronze(bronze_table_name, source_columns)

    # Define the expected results
    expected_extra_cols = ['col1','col2']  # Adjust according to your expected result
    expected_missing_cols = []  # Adjust according to your expected result

    # Assert the results
    assert set(extra_cols) == set(expected_extra_cols)

    assert missing_cols == expected_missing_cols   


@patch('ADB.common.common_objects.get_dbutils')
def test_move_temp_file(mock_get_dbutils):
    # Mock the dbutils object
    mock_dbutils = MagicMock()

    # Mock the return value of dbutils.fs.ls()
    mock_dbutils.fs.ls.return_value = [{'path': 'temp/file1'}, {'path': 'temp/file2'}, {'path': 'temp/part-123'}]

    # Mock the return value of dbutils.fs.mv() and dbutils.fs.rm()
    mock_dbutils.fs.mv.return_value = None
    mock_dbutils.fs.rm.return_value = None

    # Set the return value of get_dbutils() to the mocked dbutils object
    mock_get_dbutils.return_value = mock_dbutils

    # Call the function under test
    _, _ = move_temp_file(temp_path='/temp', filename='final_file.csv')
    assert 1==1
    assert mock_dbutils.fs.mv.call_count == 0

    assert mock_dbutils.fs.rm.call_count == 0

@patch('ADB.common.common_objects.get_dbutils')
def test_move_temp_file_part_file_not_found(mock_get_dbutils):
    # Mock the dbutils object
    mock_dbutils = MagicMock()
 
    # Mock the return value of dbutils.fs.ls() without any part file
    mock_dbutils.fs.ls.return_value = [{'path': 'temp/file1'}, {'path': 'temp/file2'}, {'path': 'temp/not_a_part_file'}]
 
    # Set the return value of get_dbutils() to the mocked dbutils object
    mock_get_dbutils.return_value = mock_dbutils
 
    # Call the function under test
    success, _ = move_temp_file(temp_path='/temp', filename='final_file.csv')
    assert success is False
 
@patch('ADB.common.common_objects.get_dbutils')
def test_move_temp_file_exception_occurs(mock_get_dbutils):
    # Mock the dbutils object
    mock_dbutils = MagicMock()
 
    # Mock the return value of dbutils.fs.ls() with a part file
    mock_dbutils.fs.ls.return_value = [{'path': 'temp/file1'}, {'path': 'temp/file2'}, {'path': 'temp/part-123'}]
 
    # Mock an exception occurring during the process
    mock_dbutils.fs.mv.side_effect = Exception("Error moving file")
    mock_dbutils.fs.rm.side_effect = Exception("Error removing temp directory")
 
    # Set the return value of get_dbutils() to the mocked dbutils object
    mock_get_dbutils.return_value = mock_dbutils
 
    # Call the function under test
    success, _ = move_temp_file(temp_path='/temp', filename='final_file.csv')
    assert success is False

def test_remove_zipfile_exception():
    # Mocking dbutils
    mock_dbutils = MagicMock()
 
    # Mocking dbutils.fs.rm to raise an exception
    mock_dbutils.fs.rm.side_effect = Exception("File not found")
 
    # Calling remove_zipfile function
    error, delete_status = remove_zipfile(dbutils=mock_dbutils, zip_path='/abc')
 
    # Assertion
    assert error == "File not found"
    assert delete_status == False

@patch("pyspark.sql.SparkSession.read")
def test_rename_columns_using_mapping_table(mock_read_delta_table,spark):
    data = [("John", 25), ("Alice", 30)]
    schema = ["name", "age"]
    df = spark.createDataFrame(data, schema)
    catalog_name = "test_catalog"
    mapping_id = "test_mapping_id"
    mapping_table_data = [("name", "full_name"), ("age", "years")]
    mapping_schema = ["old_name", "new_name"]
    mapping_df = spark.createDataFrame(mapping_table_data, mapping_schema)
    mock_read_delta_table.return_value = mapping_df
 
    # Test the function
    _, success, _ = rename_columns_using_mapping_table(df, catalog_name, "test_mapping_table", mapping_id)
    # Assert the results
    assert success == True
 
 
def test_rename_columns_using_mapping_table_exceptioon(spark):
    data = [("John", 25), ("Alice", 30)]
    schema = ["name", "age"]
    df = spark.createDataFrame(data, schema)
    catalog_name = "test_catalog"
    mapping_id = "test_mapping_id"
    # Test the function
    _, success, _ = rename_columns_using_mapping_table(df, catalog_name, "test_mapping_table", mapping_id)
    # Assert the results
    assert success == False

def test_custom_json_handling(spark):
    custom_json_handling_func = 'custom_json_handling_tirebuild.get_flatten_json'
    row = Row("json_string")("""[
    {"bm6": "166057", "finOrVin": "abc1234", "modelSeries": "c", "testroot": {"testcol1": "col1"}},
    {"bm6": "166057", "finOrVin": "abc1234", "modelSeries": "c", "testroot": {"testcol1": "col2"}}
    ]""")
    
    # Create DataFrame
    df = spark.createDataFrame([row])
    # Call the custom_json_handling function
    _, success, error = custom_json_handling(custom_json_handling_func, df)
    
    # Check if the function executed successfully
    assert success == True
    
    # Check if there's no error
    assert error is None
    
    # # Access the DataFrame from the tuple and check its columns
    # assert df_rname.columns == ['bm6', 'finOrVin', 'modelSeries', 'testcol1']


