from unittest.mock import patch, MagicMock
from ADB.common.pii_utils import encrypt_rsa_deterministic,decrypt_rsa_deterministic,create_encrypted_dataframe,get_rsa_key_file,get_pii_columns_list,check_encryption_flag,move_temp_part_file,encrypt_file_data,create_decrypted_dataframe
import os
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType,MapType

# # Test case with mocking
@patch('os.listdir')
def test_get_rsa_key_file(mock_listdir):
    # Mock the return value of os.listdir
    mock_listdir.return_value = ['example.pem']
    
    # Test case parameters
    RSA_KEY_PATH = '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/'
    domain = 'domain1'
    extension = 'pem'
    expected = RSA_KEY_PATH+'domain1/example.pem'

    # Perform the function call
    result = get_rsa_key_file(domain, extension)

    # Assert the result
    assert result == expected

@patch('os.listdir')
def test_get_rsa_key_file_fail(mock_listdir):
    # Mock the return value of os.listdir
    mock_listdir.return_value = ['example.ppk']
    
    # Test case parameters
    domain = 'domain1'
    extension = 'pem'

    # Perform the function call
    result = get_rsa_key_file(domain, extension)

    # Assert the result
    assert result == None

@patch("pyspark.sql.SparkSession.read")
# @patch("ADB.common.pii_utils.read_delta_table")
def test_get_pii_columns_list(mock_read_delta_table,spark):
    data = [
    ("eastus2_extollo_ms_us_edwdev_adbv", "xtous_us_12_test_framework", 'table1', "col1", "pii", ""),
    ("eastus2_extollo_ms_us_edwdev_adbv", "xtous_us_12_test_framework", 'table1', "col2", "pii", "")
    ]
    schema = ['catalog_name','schema_name','table_name','column_name','tag_name','tag_value']
    df = spark.createDataFrame(data, schema)
    mock_read_delta_table.table.return_value = df
    # Test case parameters
    table_name = 'table1'

    expected = ['col1', 'col2']

    result = get_pii_columns_list(table_name)

    # Assert the result
    assert result == expected

@patch("pyspark.sql.SparkSession.read")
# @patch("ADB.common.pii_utils.read_delta_table")
def test_get_pii_columns_list_fail(mock_read_delta_table,spark):
    data = [
    ("eastus2_extollo_ms_us_edwdev_adbv", "xtous_us_12_test_framework", 'table1', "col1", "pii", ""),
    ("eastus2_extollo_ms_us_edwdev_adbv", "xtous_us_12_test_framework", 'table1', "col2", "pii", "")
    ]
    schema = ['catalog_name','schema_name','table_name','column_name','tag_name','tag_value']
    df = spark.createDataFrame(data, schema)
    mock_read_delta_table.table.return_value = df
    # Test case parameters
    table_name = 'table2'

    expected = []

    result = get_pii_columns_list(table_name)

    # Assert the result
    assert result == expected

@patch("pyspark.sql.SparkSession.read")
def test_check_encryption_flag(mock_read_delta_table,spark):
    data = [
    ('table1', {"encryption": "true"})
    ]

    # Define schema
    schema = StructType([
        StructField('tgt_nam', StringType(), True),
        StructField('addnl_info', MapType(StringType(), StringType()), True)
    ])

    # Create DataFrame
    df = spark.createDataFrame(data, schema)
    mock_read_delta_table.table.return_value = df
    # Test case parameters
    table_name = 'table1'

    expected = "true"

    result = check_encryption_flag(table_name)

    # Assert the result
    assert result == expected

@patch("pyspark.sql.SparkSession.read")
def test_check_encryption_flag_fail(mock_read_delta_table,spark):
    data = [
    ('table1', {"pii": "true"})
    ]

    # Define schema
    schema = StructType([
        StructField('tgt_nam', StringType(), True),
        StructField('addnl_info', MapType(StringType(), StringType()), True)
    ])

    # Create DataFrame
    df = spark.createDataFrame(data, schema)
    mock_read_delta_table.table.return_value = df
    # Test case parameters
    table_name = 'table1'

    expected = "false"

    result = check_encryption_flag(table_name)

    # Assert the result
    assert result == expected

@patch('ADB.common.common_objects.get_dbutils')
def test_move_temp_file(mock_get_dbutils):
    # Mock the dbutils object
    mock_dbutils = MagicMock()

    # Mock the return value of dbutils.fs.ls()
    mock_dbutils.fs.ls.return_value = [{'path': 'temp/file3.csv_temp/dummy.json','name':'dummy.json'}, {'path': 'temp/file3.csv_temp/dummy1.json','name':'dummy2.json'}, {'path': 'temp/file3.csv_temp/part-123.csv','name':'part-123.csv'}]

    # Mock the return value of dbutils.fs.mv() and dbutils.fs.rm()
    mock_dbutils.fs.mv.return_value = None
    mock_dbutils.fs.rm.return_value = None

    # Set the return value of get_dbutils() to the mocked dbutils object
    mock_get_dbutils.return_value = mock_dbutils

    # Call the function under test
    _, _ = move_temp_part_file('temp/file3.csv_temp', 'file3.csv')
    assert 1==1
    assert mock_dbutils.fs.mv.call_count == 0

    assert mock_dbutils.fs.rm.call_count == 0


@patch("pyspark.sql.SparkSession.read")
@patch('ADB.common.pii_utils.create_encrypted_dataframe')
def test_encrypt_file_data_success(mock_df_read_file, mock_create_encrypted_dataframe,spark):
    # Mock the behavior of df_read_file
    data = [('A','Aaron'),('B','Finch')]
    schema = ['id','name']
    df_read_file = spark.createDataFrame(data,schema)
    mock_df_read_file.return_value = df_read_file#, mock_df_create_status, mock_read_error

    # Mock the behavior of create_encrypted_dataframe
    data_encrypted = [('B','xjuye'),('B','asdybc')]
    encrypted_df = spark.createDataFrame(data_encrypted,schema)
    mock_create_encrypted_dataframe.return_value = encrypted_df

    # Test case parameters
    filepath = 'test_file.csv'
    columns_list = ['name']

    # Expected result
    expected = (encrypted_df, True, 'Success')

    # Perform the function call
    result = encrypt_file_data(filepath,'delimited',columns_list)

    # Assert the result
    assert result[1] == expected[1]

@patch("pyspark.sql.SparkSession.read")
@patch('ADB.common.pii_utils.create_encrypted_dataframe')
def test_encrypt_file_data_fail_none_read_file(mock_df_read_file, mock_create_encrypted_dataframe,spark):
    # Mock the behavior of df_read_file
    # data = [('A','Aaron'),('B','Finch')]
    # schema = ['id','name']
    # df_read_file = spark.createDataFrame(data,schema)
    mock_df_read_file.return_value = None

    # Mock the behavior of create_encrypted_dataframe
    data_encrypted = [('B','xjuye'),('B','asdybc')]
    schema = ['id','name']
    encrypted_df = spark.createDataFrame(data_encrypted,schema)
    mock_create_encrypted_dataframe.return_value = encrypted_df

    # Test case parameters
    filepath = 'test_file.csv'
    columns_list = ['name']


    # Perform the function call
    result = encrypt_file_data(filepath,'delimited',columns_list)

    # Assert the result
    assert result[1] == False

@patch("pyspark.sql.SparkSession.read")
@patch('ADB.common.pii_utils.create_encrypted_dataframe')
def test_encrypt_file_data_fail_exception(mock_df_read_file, mock_create_encrypted_dataframe,spark):
    # Mock the behavior of df_read_file
    mock_df_read_file.return_value = None

    mock_create_encrypted_dataframe.return_value = None
    # Test case parameters
    filepath = 'test_file.csv'
    columns_list = ['name']
    # Perform the function call
    result = encrypt_file_data(filepath,'delimited',columns_list)
    # Assert the result
    assert result[1] == False


@patch("ADB.common.pii_utils.get_rsa_key_file")
@patch("ADB.common.pii_utils.obfuskator_rust")
def test_create_encrypted_dataframe(mock_obfuskator_rust, mock_get_rsa_key_file,spark):
    # Mocking the return values for pseudonymize_private_key and public_key
    mock_private_key = MagicMock()
    mock_public_key = MagicMock()
    mock_private_key.public_key.return_value = mock_public_key
    mock_obfuskator_rust.rsa.PrivateKey.load_from_file.return_value = mock_private_key

    # Sample data
    data = [("Alice", "alice@example.com"), ("Bob", "bob@example.com")]
    schema = ["name", "email"]
    pii_column_list = ["email"]

    # Create DataFrame
    df = spark.createDataFrame(data, schema)

    # Mocking encryption function
    mock_public_key.encrypt_deterministic.return_value = "encrypted_email"

    # Encrypt DataFrame
    encrypted_df = create_encrypted_dataframe(df, pii_column_list)

    # Check if DataFrame is not None
    assert encrypted_df is not None

@patch("ADB.common.pii_utils.get_rsa_key_file")
@patch("ADB.common.pii_utils.obfuskator_rust")
def test_create_decrypted_dataframe(mock_obfuskator_rust, mock_get_rsa_key_file,spark):
    # Mocking the return values for pseudonymize_private_key
    mock_private_key = MagicMock()
    mock_obfuskator_rust.rsa.PrivateKey.load_from_file.return_value = mock_private_key

    # Sample data
    data = [("Alice", "encrypted_email"), ("Bob", "encrypted_email")]
    schema = ["name", "email"]
    pii_column_list = ["email"]

    # Create DataFrame
    df = spark.createDataFrame(data, schema)

    # Mocking decryption function
    mock_private_key.decrypt.return_value = "alice@example.com"

    # Decrypt DataFrame
    decrypted_df = create_decrypted_dataframe(df, pii_column_list)

    # Check if DataFrame is not None
    assert decrypted_df is not None


@patch("ADB.common.pii_utils.get_rsa_key_file")
@patch("ADB.common.pii_utils.obfuskator_rust")
def test_decrypt_rsa_deterministic(mock_obfuskator_rust, mock_get_rsa_key_file):
    # Mocking the return values for pseudonymize_private_key
    mock_private_key = MagicMock()
    mock_obfuskator_rust.rsa.PrivateKey.load_from_file.return_value = mock_private_key

    # Mocking decryption result
    mock_private_key.decrypt.return_value = b'decrypted_data'

    # Calling the function with some encrypted input data
    decrypted_data = decrypt_rsa_deterministic(b'encrypted_data')

    # Check if decryption function was called with the correct input
    mock_private_key.decrypt.assert_called_once_with(b'encrypted_data')

    # Check if the output is as expected
    assert decrypted_data == b'decrypted_data'

@patch("ADB.common.pii_utils.get_rsa_key_file")
@patch("ADB.common.pii_utils.obfuskator_rust")
def test_encrypt_rsa_deterministic_exception(mock_obfuskator_rust, mock_get_rsa_key_file):
    # Mocking the return value for pseudonymize_private_key
    mock_private_key = MagicMock()
    mock_public_key = MagicMock()
    mock_obfuskator_rust.rsa.PrivateKey.load_from_file.return_value = mock_private_key
    mock_private_key.public_key.return_value = mock_public_key

    # Mocking get_rsa_key_file to raise an exception
    mock_get_rsa_key_file.side_effect = Exception("Key file not found")

    # Calling the function with some encrypted input data
    decrypted_data = encrypt_rsa_deterministic(b'some_data')

    # Check if the function returns None in case of exception
    assert decrypted_data is None

@patch("ADB.common.pii_utils.get_rsa_key_file")
@patch("ADB.common.pii_utils.obfuskator_rust")
def test_decrypt_rsa_deterministic_exception(mock_obfuskator_rust, mock_get_rsa_key_file):
    # Mocking the return value for pseudonymize_private_key
    mock_private_key = MagicMock()
    mock_obfuskator_rust.rsa.PrivateKey.load_from_file.return_value = mock_private_key

    # Mocking get_rsa_key_file to raise an exception
    mock_get_rsa_key_file.side_effect = Exception("Key file not found")

    # Calling the function with some encrypted input data
    decrypted_data = decrypt_rsa_deterministic(b'encrypted_data')

    # Check if the function returns None in case of exception
    assert decrypted_data is None
    