from unittest.mock import MagicMock, patch
from ADB.common.pipeline_failure_notif_utils import handle_pipeline_failure,generate_pipeline_failure_notification,generate_pipeline_failure_notification_api_eligibility,generate_pipeline_failure_notification_zip_eligibility,format_pipeline_trigger_time,parse_error,process_errors
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType
import unittest
import pytest
import json
from pyspark.sql import SparkSession

def test_valid_time_format():
        pipeline_trigger_time = "2024-04-01T12:30:45.123456"
        expected_result = "12:30:45"
        assert format_pipeline_trigger_time(pipeline_trigger_time) == expected_result

def test_parse_error():
    # Test with a valid error JSON
    valid_error_json = '{"activity_name": "Activity_1", "activity_runId": "123456", "domain_areas": "Domain_Area_1", "batch_id": "789"}'
    expected_error_item = "<b>Domain Area:</b> Domain_Area_1<br><ul><li><b>Batch ID:</b> 789</li><li><b>Activity Name:</b> Activity_1</li><li><b>Activity Run ID:</b> 123456</li></ul><br>"
    assert parse_error(valid_error_json) == expected_error_item

    # Test with a valid error JSON missing optional fields
    valid_error_json_missing_fields = '{"activity_name": "Activity_2", "activity_runId": "654321"}'
    expected_error_item_missing_fields = "<b>Domain Area:</b> None<br><ul><li><b>Batch ID:</b> None</li><li><b>Activity Name:</b> Activity_2</li><li><b>Activity Run ID:</b> 654321</li></ul><br>"
    assert parse_error(valid_error_json_missing_fields) == expected_error_item_missing_fields

@patch('ADB.common.pipeline_failure_notif_utils.parse_error')
def test_process_errors(mock_parse_error):
        # Define mocked parse_error return values
        mock_parse_error.side_effect = [
            "Error 1",
            "Error 2",
            "Error 3"
        ]
 
        errors_json = '["error_json1", "error_json2", "error_json3"]'
        expected_result = "Error 1<br>Error 2<br>Error 3"
        assert process_errors(errors_json) == expected_result

@patch('ADB.common.pipeline_failure_notif_utils.generate_pipeline_failure_notification')
def test_handle_pipeline_failure_succeeded(mock_generate_notification):
    # Mock the generate_pipeline_failure_notification function
    mock_generate_notification.return_value = True, "Notification sent successfully"
    
    # Call the function under test
    notification_status = handle_pipeline_failure('Succeeded', [], '123', 'test_pipeline', '2024-03-31T10:00:00Z')
    
    # Assertions
    assert notification_status == True
    mock_generate_notification.assert_called_once()

@patch('ADB.common.pipeline_failure_notif_utils.generate_pipeline_failure_notification')
@patch('ADB.common.pipeline_failure_notif_utils.generate_pipeline_failure_notification_api_eligibility')
def test_handle_pipeline_failure_failed_api(mock_api_notification, mock_generate_notification):
    # Mock the generate_pipeline_failure_notification_api_eligibility function
    mock_api_notification.return_value = True, "API Notification sent successfully"
    
    # Call the function under test
    notification_status = handle_pipeline_failure('Failed', [], '123', 'api_test_pipeline', '2024-03-31T10:00:00Z')
    
    # Assertions
    assert notification_status == True
    mock_api_notification.assert_called_once()
    mock_generate_notification.assert_not_called()

@patch('ADB.common.pipeline_failure_notif_utils.generate_pipeline_failure_notification_zip_eligibility')
@patch('ADB.common.pipeline_failure_notif_utils.generate_pipeline_failure_notification')
def test_handle_pipeline_failure_failed_zip(mock_generate_notification, mock_zip_notification):
    # Mock the generate_pipeline_failure_notification_zip_eligibility function
    mock_zip_notification.return_value = True, "ZIP Notification sent successfully"
    
    # Call the function under test
    notification_status = handle_pipeline_failure('Failed', [], '123', 'zip_test_pipeline', '2024-03-31T10:00:00Z')
    
    # Assertions
    assert notification_status == True
    mock_zip_notification.assert_called_once()
    mock_generate_notification.assert_not_called()