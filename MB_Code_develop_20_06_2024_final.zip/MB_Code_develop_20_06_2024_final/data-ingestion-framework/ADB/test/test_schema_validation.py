from ADB.common.schema_validation import check_schema_validation, schema_validation_spark_dict
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType
import unittest
import pytest
import json
from pyspark.sql import SparkSession

def test_check_schema_validation(spark):
    # Define input data
    typecast_dict = {
        'col1': 'INT',
        'col2': 'TIMESTAMP',
        'col3': 'DATE',
        'col4': 'DECIMAL',
        'col5': 'STRING'
    }
    data = [("1", "2024-01-01 00:00:00", "2024-01-01", "123.45", "value1"),
            ("2", None, "2024-01-02", None, "value2"),
            ("3", "2024-01-03 00:00:00", None, "345.67", "value3")]
    columns = ["col1", "col2", "col3", "col4", "col5"]
    df = spark.createDataFrame(data, columns)

    # Call check_schema_validation function
    df_good, df_bad, error = check_schema_validation(df, typecast_dict)

    # Assertions
    assert error is None
    assert df_good.count() == 1
    assert df_bad.count() == 2
