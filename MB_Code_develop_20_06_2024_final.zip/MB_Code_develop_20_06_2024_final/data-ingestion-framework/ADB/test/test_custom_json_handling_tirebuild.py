import pytest
from pyspark.sql.types import StructType,StructField,StringType
from pyspark.sql import SparkSession
from pyspark.sql.functions import length
from ADB.common.custom_json_handling_functions.custom_json_handling_tirebuild import get_flatten_json,column_length_validation

@pytest.fixture
def spark():
    return SparkSession.builder \
        .master("local") \
        .appName("pytest") \
        .getOrCreate()

def test_get_flatten_json(spark, mocker):
    schema = StructType([
        StructField("json_string", StringType(), True)
    ])
    data = [("example_json_data",)]
    df_s_i = spark.createDataFrame(data, schema)
    mocker.patch("ADB.common.common_objects.get_dbutils")
    mocker.patch("ADB.tire_build_utils.api_config_transform.get_current_datetime")
    mocker.patch("ADB.tire_build_utils.api_config_transform.is_token_expired")
    mocker.patch("ADB.tire_build_utils.api_config_transform.generate_header")
    mocker.patch("ADB.common.custom_json_handling_functions.tirebuild_utils.explode_without_null")
    mocker.patch("ADB.common.custom_json_handling_functions.tirebuild_utils.column_mapping")
    mocker.patch("ADB.common.custom_json_handling_functions.tirebuild_utils.explode_with_null")
    result_df = get_flatten_json(df_s_i)
    assert result_df.count() == 0


column_length_dict = {
    "ID_USA_VIN": 17,
    "IND_RA_MERC_ORIGNL": 10,
    "NUM_FA_SUPLR_SKU": 13,
    "NUM_FA_TIRE_WDTH": 10,
    "NAM_ERR_LST": 200,
    "NAM_FA_VEND": 55,
    "IND_FA_MERC_ORIGNL": 10,
    "DES_WRN_MSG": 1000,
    "NUM_FA_RIM_DIAMTR": 10,
    "NUM_FA_SIDE_TIRE_SIZE": 55,
    "NUM_MODL_SER": 20,
    "NAM_FA_DSGNTN": 60,
    "NUM_RA_LOAD_IDX": 5,
    "NUM_RA_SUPLR_PART": 10,
    "NUM_FA_ASPT_RTIO": 10,
    "NUM_RA_RIM_DIAMTR": 10,
    "NUM_FA_LOAD_IDX": 5,
    "NUM_FA_SUPLR_PART": 10,
    "DES_ERR_MSG": 1000,
    "NUM_RA_SIDE_TIRE_SIZE": 55,
    "NUM_RA_DIM_SIZE": 11,
    "NUM_RA_SPD_IDX": 5,  
    "NUM_FA_DIM_SIZE": 11,
    "CDE_BAUM": 6,
    "NAM_RA_SEAS": 55,
    "NAM_RA_VEND": 55,
    "NUM_FA_SPD_IDX": 5,
    "NAM_FA_SEAS": 55,
    "NUM_RA_TIRE_WDTH": 10,
    "NUM_RA_GER_PART": 20,
    "NUM_FA_GER_PART": 20,
    "NUM_RA_SUPLR_SKU": 13,
    "NAM_RA_DSGNTN": 60,
    "NUM_RA_ASPT_RTIO": 10
}


schema = StructType([
    StructField("ID_USA_VIN", StringType(), True),
    StructField("IND_RA_MERC_ORIGNL", StringType(), True),
    StructField("NUM_FA_SUPLR_SKU", StringType(), True),
    StructField("NUM_FA_TIRE_WDTH", StringType(), True),
    StructField("NAM_ERR_LST", StringType(), True),
    StructField("NAM_FA_VEND", StringType(), True),
    StructField("IND_FA_MERC_ORIGNL", StringType(), True),
    StructField("DES_WRN_MSG", StringType(), True),
    StructField("NUM_FA_RIM_DIAMTR", StringType(), True),
    StructField("NUM_FA_SIDE_TIRE_SIZE", StringType(), True),
    StructField("NUM_MODL_SER", StringType(), True),
    StructField("NAM_FA_DSGNTN", StringType(), True),
    StructField("NUM_RA_LOAD_IDX", StringType(), True),
    StructField("NUM_RA_SUPLR_PART", StringType(), True),
    StructField("NUM_FA_ASPT_RTIO", StringType(), True),
    StructField("NUM_RA_RIM_DIAMTR", StringType(), True),
    StructField("NUM_FA_LOAD_IDX", StringType(), True),
    StructField("NUM_FA_SUPLR_PART", StringType(), True),
    StructField("DES_ERR_MSG", StringType(), True),
    StructField("NUM_RA_SIDE_TIRE_SIZE", StringType(), True),
    StructField("NUM_RA_DIM_SIZE", StringType(), True),
    StructField("NUM_RA_SPD_IDX", StringType(), True),
    StructField("NUM_FA_DIM_SIZE", StringType(), True),
    StructField("CDE_BAUM", StringType(), True),
    StructField("NAM_RA_SEAS", StringType(), True),
    StructField("NAM_RA_VEND", StringType(), True),
    StructField("NUM_FA_SPD_IDX", StringType(), True),
    StructField("NAM_FA_SEAS", StringType(), True),
    StructField("NUM_RA_TIRE_WDTH", StringType(), True),
    StructField("NUM_RA_GER_PART", StringType(), True),
    StructField("NUM_FA_GER_PART", StringType(), True),
    StructField("NUM_RA_SUPLR_SKU", StringType(), True),
    StructField("NAM_RA_DSGNTN", StringType(), True),
    StructField("NUM_RA_ASPT_RTIO", StringType(), True)   
])

# Sample data
data = [
    (
    "12345678901234567", 
     "1234567890", 
     "1234567890123", 
     "1234567890", 
     "Sample Error List", 
     "Sample Vendor Name", 
     "1", 
     "Sample Warning Message", 
     "1234567890", 
     "Sample Tire Size", 
     "Sample Model Series", 
     "Sample Designation", 
     "1", 
     "1234567890", 
     "1234567890", 
     "1234567890", 
     "1", 
     "1234567890", 
     "Sample Error Message", 
     "Sample Tire Size", 
     "Sample Dimension Size", 
     "1", 
     "Sample Dimension Size", 
     "1", 
     "Sample Baum", 
     "Sample Season", 
     "Sample Vendor", 
     "1", 
     "Sample Season", 
     "1234567890", 
     "Sample German Part", 
     "Sample German Part", 
     "1234567890123", 
     "Sample Designation"
     )
]

spark = SparkSession.builder.getOrCreate()
mock_df = spark.createDataFrame(data, schema)


def test_column_length_validation():
    result_df = column_length_validation(mock_df)
    assert result_df is not None
    assert set(result_df.columns) == set(mock_df.columns)
    for column, max_length in column_length_dict.items():
        assert result_df.select(length(column)).collect()[0][0] <= max_length