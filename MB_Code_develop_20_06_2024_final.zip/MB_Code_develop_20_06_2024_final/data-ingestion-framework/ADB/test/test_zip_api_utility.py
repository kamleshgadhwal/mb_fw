from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType,BooleanType
import unittest
import pytest
import json
from pyspark.sql import SparkSession
from ADB.common.zip_api_utility_functions import read_filtered_table,process_api_file,filter_watermark_data,join_watermark_and_filemaster,get_cron_schedule_datetime,get_current_date,get_current_datetime,adjust_current_datetime,check_cron_schedule,get_active_zip_details,update_dates_in_dict_list,active_api_details
from unittest.mock import MagicMock, patch
from pyspark.sql import DataFrame
from datetime import datetime,timedelta,date
from croniter import croniter,CroniterBadCronError

 
 
spark = SparkSession.builder.appName("test").getOrCreate()
 
def test_read_filtered_table():
    data = [("csv", 10), ("json", 20), ("csv", 30)]
    schema = ["file_typ", "value"]
    test_df = spark.createDataFrame(data, schema=schema)
 
    # Call the function with a specific file_type
    result_df = read_filtered_table(test_df, "csv")
 
    assert result_df.count()==2
 
def test_filter_watermark_data():
    # Sample data for testing
    data = {
        "opr_stat": ["1", "2", "1", "1", "1"],
        "run_dte": ["2022-01-01", "2022-01-02", "2022-01-01", "2022-01-01", "2022-01-01"],
        "oper_phase": ["api_copy", "api_copy", "other_phase", "api_copy", "api_copy"],
    }
 
    # Create a PySpark DataFrame
    log_df = spark.createDataFrame(list(data.values()), list(data.keys()))
 
    # Define the expected result based on the filter condition
    expected_result = log_df.filter(
        (col("opr_stat") == '1') & (col("run_dte") == "2022-01-01") & (col("oper_phase") == "api_copy")
    )
 
    # Call the function with the input data
    result = filter_watermark_data(log_df, "2022-01-01")
 
    # Assert that the filtered DataFrames are equal
    assert result.collect() == expected_result.collect()
 
def test_join_watermark_and_filemaster():
    # Sample data for testing
    data_filemaster = {
        "id_src_file": [1, 2, 3, 4, 5],
        "file_name": ["file1", "file2", "file3", "file4", "file5"],
    }
 
    data_filtered_watermark = {
        "id_proc": [3, 4, 5],
        "other_column": ["value1", "value2", "value3"],
    }
 
    # Create PySpark DataFrames
    df_filemaster_api = spark.createDataFrame(list(data_filemaster.values()), list(data_filemaster.keys()))
    df_filtered_watermark_data = spark.createDataFrame(list(data_filtered_watermark.values()), list(data_filtered_watermark.keys()))
 
    # Define the expected result based on the left_anti join condition
    expected_result = df_filemaster_api.join(df_filtered_watermark_data, col("id_src_file") == col("id_proc"), how="left_anti")
 
    # Call the function with the input data
    result = join_watermark_and_filemaster(df_filemaster_api, df_filtered_watermark_data)
 
    # Assert that the joined DataFrames are equal
    assert result.collect() == expected_result.collect()
 
@patch("ADB.common.common_utilities.read_delta_table")
@patch("ADB.common.zip_api_utility_functions.filter_watermark_data")
def test_process_api_file(read_mock, read_filter,spark):
 
    current_date = "2024-01-31"
   
    data_delta = [
        ('id1','1', '2024-01-31', 'api_copy', 10),
        ('id1','2', '2024-01-31', 'api_copy', 20),
        ('id1','1', '2024-01-30', 'api_copy', 30),
        ('id1','1', '2024-01-31', 'other_phase', 40),
    ]
 
    # Define the schema for the DataFrame
    schema_delta = ["id_proc","opr_stat", "run_dte", "oper_phase", "value"]
 
    data_filemaster = [
        ('id1',10),
        ('id2',20),
    ]
    schema_filemaster = ["id_src_file","value"]
    df_filemaster_api = spark.createDataFrame(data_filemaster, schema=schema_filemaster)
 
    read_mock.return_value = spark.createDataFrame(data_delta, schema=schema_delta)
    read_filter.return_value = spark.createDataFrame(data_delta, schema=schema_delta)
    result_df = process_api_file(df_filemaster_api, current_date, "water_mark_table", "catlg_nam")
 
    assert "id_src_file" in result_df.columns
 
def test_get_cron_schedule_datetime():
    # Sample data for testing
    cron_expression = "0 0 * * *"
    current_datetime = datetime(2024, 1, 30, 18, 30)  # January 31, 2024, 12:30 PM
 
    # Call the function with the input data
    result = get_cron_schedule_datetime(cron_expression, current_datetime)
 
    # Calculate the expected result manually based on the cron expression
    expected_result = croniter(cron_expression, current_datetime).get_prev(datetime)
 
    # Assert that the calculated result is equal to the expected result
    assert result == expected_result
 
def test_get_current_date():
    # Call the function
    result = get_current_date()
 
    # Assert that the result is of type datetime.date
    assert isinstance(result, date)
 
def test_get_current_datetime():
    # Call the function
    result = get_current_datetime()
 
    # Assert that the result is of type datetime.datetime
    assert isinstance(result, datetime)
 
def test_adjust_current_datetime():
    # Sample data for testing
    current_datetime = datetime(2024, 1, 31, 0, 30)
    prev_schedule_datetime = datetime(2024, 1, 31, 0, 30)
 
    # Call the function
    result, adjusted = adjust_current_datetime(current_datetime, prev_schedule_datetime)
 
    # Assert that the result is of type datetime.datetime
    assert isinstance(result, datetime)
 
    # Assert that the adjusted flag is of type bool
    assert isinstance(adjusted, bool)
  
    # Assert that the result is adjusted when times are the same
    assert result == current_datetime + timedelta(minutes=1) and adjusted
 

def test_check_cron_schedule_invalid():
         
    result = check_cron_schedule("0 1 # # *")
 
    assert result is False
 
def test_get_active_zip_details():
    column_names = ["id_src_file", "nam_src_file", "ldg_path_extollo", "src_addr_spec","domn_area"]
   
    data = [
        ("1", "file1", "/path1", "address1","orders"),
        ("2", "file2", "/path2", "address2","orders"),
        ("1", "file1", "/path1", "address1","orders"),
    ]
 
    df_filtered_zip_details = spark.createDataFrame(data, schema=column_names)
 
    result = get_active_zip_details(df_filtered_zip_details)
 
    assert len(result) == 2
 
def test_update_dates_in_dict_list():
    # Create a sample input dictionary list
    dict_list = [
        {
            'ldg_path_extollo': 'path/file_yyyy-MM-dd',
            'src_addr_spec': 'path1/file_yyyy/MM/dd',
            'nam_src_file': 'file_yyyy_mm_dd.txt'
        },
    ]
 
    result = update_dates_in_dict_list(dict_list)
 
    expected_result = [{
                'ldg_path_extollo': 'path/file_2024-02-01',
                'src_addr_spec': 'path1/file_2024/02/01',
                'nam_src_file': 'file_2024_02_01.txt'
            },
        ]
    assert result != expected_result

