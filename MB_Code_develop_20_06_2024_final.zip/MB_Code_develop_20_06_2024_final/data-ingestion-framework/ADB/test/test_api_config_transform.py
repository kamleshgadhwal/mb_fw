from ADB.tire_build_utils.api_config_transform import get_load_query,get_payload,get_vin_list,is_token_expired,get_current_datetime,get_run_date,get_auth_data,generate_header,create_adw_connection,execute_queries_for_extract,get_api_config,write_json_to_file,create_folder,get_api_response_batch,save_api_response,poll_api_server,fetch_get_response,fetch_job_id,fetch_jobid_response,empty_vins_lookup
import requests
import pyspark
from pyspark.sql import functions as F
from pyspark.sql.types import StringType,StructField,StructType
from pyspark.sql import SparkSession
from datetime import datetime,timedelta
import json
import time
from unittest.mock import patch, MagicMock,call
from ADB.test.conftest import spark
import pytest
spark=SparkSession.builder.appName("test").getOrCreate()
 

@pytest.fixture
def mock_dbutils():
    return MagicMock()

def test_get_api_config(mock_dbutils):
    mock_dbutils.secrets.get.side_effect = lambda scope, key: {
        'daps-kv': {'ecs4dq-client-id': 'dummy_client_id',
                    'ecs4dq-client-secret': 'dummy_client_secret',
                    'ecs4dq-auth-url': 'dummy_auth_url',
                    'ecs4dq-api-base-url': 'dummy_base_url'}
    }[scope][key]
    api_config_dict = get_api_config(mock_dbutils)
    assert api_config_dict == {
        'client_id': 'dummy_client_id',
        'client_secret': 'dummy_client_secret',
        'grant_type': 'client_credentials',
        'auth_url': 'dummy_auth_url',
        'api_base_url': 'dummy_base_url'
    }
    assert mock_dbutils.secrets.get.call_count == 4
    mock_dbutils.secrets.get.assert_any_call(scope='daps-kv', key='ecs4dq-client-id')
    mock_dbutils.secrets.get.assert_any_call(scope='daps-kv', key='ecs4dq-client-secret')
    mock_dbutils.secrets.get.assert_any_call(scope='daps-kv', key='ecs4dq-auth-url')
    mock_dbutils.secrets.get.assert_any_call(scope='daps-kv', key='ecs4dq-api-base-url')


def test_get_load_query_historical():
    flag = "historical"
    expected_query = "select ID_FIN_VIN,DTE_MODL_YR from ADW_VISTA_EDW.VEHICLE WHERE DTE_MODL_YR IS NOT NULL AND TRY_CAST(DTE_MODL_YR AS INT) IS NOT NULL and ID_FIN_VIN IS NOT NULL and DTE_ACTL_PRODN >= '{0}' and DTE_ACTL_PRODN <= '{1}'"
    assert get_load_query(flag) == expected_query

def test_get_load_query_other():
    flag = "some_other_value"
    expected_query = "select ID_USA_VIN,DTE_EFF,CDE_EVENT from ADW_VISTA_EDW.SWT_VEH_HIST where ID_USA_VIN is not null and CDE_EVENT IN ('ZFVP','ZVPN','ZLPN','ZLVP') and  datediff(day,DTE_EFF,'{0}') = 1"
    assert get_load_query(flag) == expected_query

def test_get_auth_data():
    data={'client_id':'cc91159c-e3d9-40f0-aaff-437360894c7b','client_secret': 'hfBiiwFqpwunzNaxigfkhmEpurhdSbdxAyAqcrLhIAjYLKvdaHcoADxJmhkprgfN','grant_type':"client_credentials"}
    auth_data=get_auth_data('https://sso-int.mercedes-benz.com/as/token.oauth2',data)
    expected_expiration_value=0
    assert auth_data.get('expires_in') > expected_expiration_value

def test_generate_header():
    access_token = "sample_access_token"
    headers = generate_header(access_token)
    assert isinstance(headers, dict) 
    assert headers["Authorization"] == f"Bearer {access_token}" 
    assert headers["Content-type"] == "application/json"
    assert headers["Connection"] == "keep-alive"
    assert headers["Accept"] == "*/*"
    assert headers["Accept-Encoding"] == "gzip, deflate, br"

def test_get_payload():
    vins = ["4JG1660571A447973","W1NYC6BJ9PX466880","WDDSJ4EB7JN581479","WDCTG4GB8JJ437516"]
    actual_payload=get_payload(vins)
    index_of_first=actual_payload.index("{")
    assert index_of_first==0

def test_get_vin_list():
    data = [("W1KMK4HB7RF019167",'A'), ("4JGFB4FB0RB211667",'B'), ("4JGFB4FB5RB213060",'C')]
    sample_df = spark.createDataFrame(data, ["ID_USA_VIN",'Name'])
    vin_list=sorted(get_vin_list(sample_df,"incremental"))
    actual_data=vin_list[1]
    expected_data="4JGFB4FB5RB213060"
    assert expected_data==actual_data

def test_is_token_expired():
    current_time = time.time()
    token_expire_time=1799+current_time
    assert is_token_expired(token_expire_time)==False

def test_get_current_datetime():
    actual_date=get_current_datetime()
    current_date = datetime.now()
    expected_date = current_date.strftime('%Y%m%d')
    assert actual_date==expected_date

def test_get_run_date():
    actual_date=get_run_date()
    expected_date = datetime.now()
    expected_date = expected_date.strftime("%Y-%m-%d")
    assert expected_date==actual_date

def test_write_json_to_file():
    mock_dbutils = MagicMock()
    data = {"key": "value"}
    expected_json_content = '{"key": "value"}'
    dbfs_file_path = "dbfs:/path/to/file.json"
    with patch("ADB.common.common_objects.get_dbutils", mock_dbutils):
        write_json_to_file(dbfs_file_path, data, mock_dbutils)
    mock_dbutils.fs.put.assert_called_once_with(dbfs_file_path, expected_json_content, overwrite=True)

def test_create_folder():
    mock_dbutils = MagicMock()
    folder_path = "dbfs:/path/to/folder"
    with patch("ADB.common.common_objects.get_dbutils", mock_dbutils):
        create_folder(folder_path, mock_dbutils)
    mock_dbutils.fs.mkdirs.assert_called_once_with(folder_path)

@pytest.fixture
def api_config_dict():
    return {
        'client_id': 'your_client_id',
        'client_secret': 'your_client_secret',
        'grant_type': 'client_credentials',
        'auth_url': 'your_auth_url',
        'api_base_url': 'your_api_base_url'
    }

@pytest.fixture
def data():
    return {}

@pytest.fixture
def headers():
    return {} 

@pytest.fixture
def token_expire_time():
    return "your_token_expire_time"

@pytest.fixture
def time_interval():
    return 1 

@pytest.fixture
def vins_data_list():
    return []

@pytest.fixture
def batch_size():
    return 10

def test_get_api_response_batch(api_config_dict, data, headers, token_expire_time, time_interval, vins_data_list, batch_size):
    mock_fetch_job_id = MagicMock(return_value="sample_job_id")
    mock_poll_api_server = MagicMock(return_value={"job_processing": "Completed"})
    mock_fetch_jobid_response = MagicMock(return_value="sample_api_response")

    with patch('ADB.tire_build_utils.api_config_transform.fetch_job_id', mock_fetch_job_id), \
         patch('ADB.tire_build_utils.api_config_transform.poll_api_server', mock_poll_api_server), \
         patch('ADB.tire_build_utils.api_config_transform.fetch_jobid_response', mock_fetch_jobid_response):
        
        result = list(get_api_response_batch(api_config_dict, data, headers, token_expire_time, time_interval, vins_data_list, batch_size))
    assert len(result) == 0
    
@pytest.fixture
def api_response():
    return {}

@pytest.fixture
def landing_storage_path():
    return "/your/unity/catalog/volume"

@pytest.fixture
def partition_folder():
    return "your_partition_folder"

@pytest.fixture
def flag():
    return "incremental"

@pytest.fixture
def mock_dbutils():
    return MagicMock()

def test_save_api_response(api_response,landing_storage_path, partition_folder, flag, mock_dbutils):
    mock_get_current_datetime = MagicMock(return_value="2022-01-01")
    mock_create_folder = MagicMock()
    mock_write_json_to_file = MagicMock()

    with patch('ADB.tire_build_utils.api_config_transform.get_current_datetime', mock_get_current_datetime), \
         patch('ADB.tire_build_utils.api_config_transform.create_folder', mock_create_folder), \
         patch('ADB.tire_build_utils.api_config_transform.write_json_to_file', mock_write_json_to_file), \
         patch('ADB.tire_build_utils.api_config_transform.os.path.join', MagicMock(side_effect=lambda *args: "/".join(args))):
        result = save_api_response(api_response,landing_storage_path, partition_folder, flag, mock_dbutils)
    expected_api_file_name = "oneapi_2022-01-01.json"
    assert result == expected_api_file_name
   

@patch("ADB.common.common_objects.get_dbutils")
def test_create_adw_connection(dbutils_obj):
    dbutils_obj.secrets.get.return_value="test",
    _,u=create_adw_connection(dbutils_obj)
    actual_driver_value=u.get("driver")
    expected_driver_value='com.microsoft.sqlserver.jdbc.SQLServerDriver'
    assert actual_driver_value==expected_driver_value


@pytest.fixture
def mock_requests():
    with patch('ADB.tire_build_utils.api_config_transform.requests') as requests_mock:
        yield requests_mock

def test_poll_api_server(mock_requests):
    api_config_dict = {
        "api_base_url": "http://example.com/api",
        "auth_url": "http://example.com/auth"
    }
    job_id = '12345'
    data = {}  
    headers = {}
    token_expire_time = 0.00001
    time_interval = 1
    auth_response = MagicMock()
    auth_response.json.return_value = {"access_token": "your_access_token"}
    mock_requests.post.return_value = auth_response

    job_status_response = {"done": True}
    job_response = MagicMock()
    job_response.json.return_value = job_status_response
    mock_requests.get.return_value = job_response
    result = poll_api_server(api_config_dict, job_id, data, headers, token_expire_time, time_interval)
    assert result["job_processing"] == "Completed"
    assert result["job_id"] == job_id

@pytest.fixture
def mock_requests():
    with patch('ADB.tire_build_utils.api_config_transform.requests') as requests_mock:
        yield requests_mock

def test_fetch_get_response(mock_requests):
    api_config_dict = {
        "api_base_url": "http://example.com/api",
        "auth_url": "http://example.com/auth"
    }
    vin = "123456789"
    data = {}
    headers = {}
    token_expire_time = 0.0000001
    api_data = {"vin": vin, "model": "TestModel"}
    api_response = MagicMock()
    api_response.json.return_value = api_data
    mock_requests.get.return_value = api_response
    result = fetch_get_response(api_config_dict, vin, data, headers, token_expire_time)
    assert result == api_data

@pytest.fixture
def mock_requests():
    with patch('ADB.tire_build_utils.api_config_transform.requests') as requests_mock:
        yield requests_mock

def test_fetch_job_id(mock_requests):
    api_config_dict = {
        "api_base_url": "http://example.com/api",
        "auth_url": "http://example.com/auth"
    }
    vins_list = ["123456789", "987654321"]
    data = {}
    headers = {}
    token_expire_time = 0.000001
    job_id = "12345"
    api_data = {"id": job_id}
    api_response = MagicMock()
    api_response.json.return_value = api_data
    mock_requests.post.return_value = api_response
    result = fetch_job_id(api_config_dict, vins_list, data, headers, token_expire_time)
    assert result == job_id

@pytest.fixture
def mock_requests():
    with patch('ADB.tire_build_utils.api_config_transform.requests') as requests_mock:
        yield requests_mock

def test_fetch_jobid_response(mock_requests):
    api_config_dict = {
        "api_base_url": "http://example.com/api",
        "auth_url": "http://example.com/auth"
    }
    job_id = "12345"
    data = {}
    headers = {}
    token_expire_time = 0.00000001
    json_data = {"key": "value"}
    json_response = MagicMock()
    json_response.json.return_value = json_data
    mock_requests.post.return_value = MagicMock(json=lambda: {"access_token": "mock_access_token"})
    mock_requests.get.return_value = json_response
    result = fetch_jobid_response(api_config_dict, job_id, data, headers, token_expire_time)
    assert result == json_data

def test_execute_queries_for_extract():
    jdbc_url = "jdbc:mysql://localhost:3306/database"
    connection_properties = {"user": "root", "password": "password"}
    query = "SELECT * FROM table"
    test_data = [("John Doe", 25), ("Jane Smith", 30)]
    expected_result = spark.createDataFrame(test_data, ["name", "age"])
    with patch.object(pyspark.sql.DataFrameReader,"jdbc") as mock_jdbc:
        mock_jdbc.return_value = expected_result
        result_df = execute_queries_for_extract(jdbc_url, connection_properties, query)
        assert result_df.collect() == expected_result.collect()
        mock_jdbc.assert_called_once_with(url=jdbc_url, table=f"({query}) AS adw_table", properties=connection_properties)



# Sample schema and data for the mock DataFrame
schema = StructType([
    StructField("ID_ERR", StringType(), True),
    StructField("ID_USA_VIN", StringType(), True)
])

data_vin = [
    ("1", "12345678901234567"),
    (None, "12345678901234568"),
    ("2", "12345678901234569")
]

# Create the mock DataFrame
spark = SparkSession.builder.getOrCreate()
mock_df = spark.createDataFrame(data_vin, schema)

# Test function
def test_empty_vins_lookup():
    catalog_name = "test_catalog"
    schema_name = "test_schema"
    table_name = "test_table"

    with patch('pyspark.sql.SparkSession.read') as mock_read:
        # Mock the format and table methods
        mock_format = mock_read.return_value.format.return_value
        mock_table = mock_format.table.return_value
        mock_table.filter.return_value = mock_df.filter(F.col("ID_ERR").isNotNull())

        # Call the function
        result_df = empty_vins_lookup(catalog_name, schema_name, table_name)

        # Assertions
        assert result_df is not None



@patch('ADB.tire_build_utils.api_config_transform.requests.post')
@patch('ADB.tire_build_utils.api_config_transform.requests.get')
@patch('ADB.tire_build_utils.api_config_transform.is_token_expired')
def test_fetch_get_response_token_not_expired(mock_is_token_expired, mock_requests_get, mock_requests_post):
    api_config_dict = {"api_base_url": "https://api.example.com", "auth_url": "https://auth.example.com"}
    vin = "12345"
    data = {"username": "user", "password": "pass"}
    headers = {"Authorization": "Bearer old_token"}
    token_expire_time = "some_expire_time"

    # Mock is_token_expired to return False
    mock_is_token_expired.return_value = False

    # Mock the get request to return the API data
    mock_api_response = MagicMock()
    mock_api_response.json.return_value = {"data": "sample_data"}
    mock_requests_get.return_value = mock_api_response

    # Call the function
    response = fetch_get_response(api_config_dict, vin, data, headers, token_expire_time)

    # Assertions
    mock_requests_post.assert_not_called()
    mock_requests_get.assert_called_once_with("https://api.example.com/single/12345", headers=headers, verify=False)
    assert response == {"data": "sample_data"}


@patch('ADB.tire_build_utils.api_config_transform.requests.get')
@patch('ADB.tire_build_utils.api_config_transform.is_token_expired')
def test_fetch_jobid_response_token_not_expired(mock_is_token_expired, mock_requests_get):
    api_config_dict = {"api_base_url": "https://api.example.com", "auth_url": "https://auth.example.com"}
    job_id = "job123"
    data = {"username": "user", "password": "pass"}
    headers = {"Authorization": "Bearer old_token"}
    token_expire_time = "some_expire_time"

    # Mock is_token_expired to return False
    mock_is_token_expired.return_value = False

    # Mock the get request to return the API data
    mock_api_response = MagicMock()
    mock_api_response.json.return_value = {"data": "sample_data"}
    mock_requests_get.return_value = mock_api_response

    # Call the function
    response = fetch_jobid_response(api_config_dict, job_id, data, headers, token_expire_time)

    # Assertions
    mock_requests_get.assert_called_once_with("https://api.example.com/batch/job123/download", headers=headers, verify=False)
    assert response == {"data": "sample_data"}


def test_is_token_expired_true():
    future_time = 2000  # Arbitrary future timestamp
    with patch('time.time', return_value=3000):  # Mock current time to 3000
        assert is_token_expired(future_time) == True

def test_is_token_expired_false():
    future_time = 3000  # Arbitrary future timestamp
    with patch('time.time', return_value=2000):  # Mock current time to 2000
        assert is_token_expired(future_time) == False



def test_save_api_response_historical():
    api_response = '{"key": "value"}'
    landing_storage_path = "/mnt/storage"
    partition_folder = "2023"
    flag = "historical"
    dbutils = MagicMock()
    
    with patch('ADB.tire_build_utils.api_config_transform.get_current_datetime', return_value="2024-05-23T12-00-00"):        
        result = save_api_response(api_response, landing_storage_path, partition_folder, flag, dbutils)
        
        folder_path = "/mnt/storage/historical_load/model_year=2023/2024-05-23T12-00-00/"
        api_json_path = "/mnt/storage/historical_load/model_year=2023/2024-05-23T12-00-00/oneapi_2024-05-23T12-00-00.json"
        
        abs_path = folder_path+'oneapi_2024-05-23T12-00-00.json'
        assert abs_path == api_json_path
        assert result == "oneapi_2024-05-23T12-00-00.json"


@patch('ADB.tire_build_utils.api_config_transform.requests.get')
@patch('ADB.tire_build_utils.api_config_transform.is_token_expired', return_value=False)
def test_poll_api_server_else_case(mock_is_token_expired, mock_requests_get):
    api_config_dict = {
        "api_base_url": "http://fakeapi.com",
        "auth_url": "http://fakeapi.com/auth"
    }
    job_id = "12345"
    data = {"client_id": "fake_id", "client_secret": "fake_secret"}
    headers = {"Authorization": "Bearer fake_token"}
    token_expire_time = time.time() + 3600  # Token expires in 1 hour
    time_interval = 1  # Poll every 1 second

    # Mock response for requests.get
    mock_response = MagicMock()
    mock_response.json.return_value = {"done": True}
    mock_requests_get.return_value = mock_response

    result = poll_api_server(api_config_dict, job_id, data, headers, token_expire_time, time_interval)

    # Assertions to check the output
    assert result["job_processing"] == "Completed"
    assert result["job_id"] == job_id
    assert "job_start_time" in result
    assert "job_end_time" in result
    assert result["total_polled_second"] == 0

    # Assertions to check if the mock was called correctly
    mock_requests_get.assert_called_with(api_config_dict["api_base_url"] + "/batch/12345/status", headers=headers, verify=False)
    mock_is_token_expired.assert_called_once_with(token_expire_time)


@patch('ADB.tire_build_utils.api_config_transform.fetch_jobid_response')
@patch('ADB.tire_build_utils.api_config_transform.poll_api_server')
@patch('ADB.tire_build_utils.api_config_transform.fetch_job_id')
def test_get_api_response_batch(mock_fetch_job_id, mock_poll_api_server, mock_fetch_jobid_response):
    api_config_dict = {
        "api_base_url": "http://fakeapi.com",
        "auth_url": "http://fakeapi.com/auth"
    }
    data = {"client_id": "fake_id", "client_secret": "fake_secret"}
    headers = {"Authorization": "Bearer fake_token"}
    token_expire_time = 3600
    time_interval = 1
    vins_data_list = ["VIN1", "VIN2", "VIN3", "VIN4"]
    batch_size = 2

    # Mock the behavior of fetch_job_id
    mock_fetch_job_id.side_effect = ["job_id_1", "job_id_2"]

    # Mock the behavior of poll_api_server
    mock_poll_api_server.return_value = {"job_processing": "Completed"}

    # Mock the behavior of fetch_jobid_response
    mock_fetch_jobid_response.return_value = {"api_response_key": "api_response_value"}

    # Call the function and collect the results
    results = list(get_api_response_batch(api_config_dict, data, headers, token_expire_time, time_interval, vins_data_list, batch_size))

    # Assertions
    assert len(results) == 2  # There should be 2 results because we have 4 VINs and a batch size of 2
    for api_response, job_response in results:
        assert api_response == {"api_response_key": "api_response_value"}
        assert job_response == {"job_processing": "Completed"}

    # Verify the mocks were called correctly
    mock_fetch_job_id.assert_any_call(api_config_dict, ["VIN1", "VIN2"], data, headers, token_expire_time)
    mock_fetch_job_id.assert_any_call(api_config_dict, ["VIN3", "VIN4"], data, headers, token_expire_time)
    assert mock_fetch_job_id.call_count == 2

    mock_poll_api_server.assert_any_call(api_config_dict, "job_id_1", data, headers, token_expire_time, time_interval)
    mock_poll_api_server.assert_any_call(api_config_dict, "job_id_2", data, headers, token_expire_time, time_interval)
    assert mock_poll_api_server.call_count == 2

    mock_fetch_jobid_response.assert_any_call(api_config_dict, "job_id_1", data, headers, token_expire_time)
    mock_fetch_jobid_response.assert_any_call(api_config_dict, "job_id_2", data, headers, token_expire_time)
    assert mock_fetch_jobid_response.call_count == 2