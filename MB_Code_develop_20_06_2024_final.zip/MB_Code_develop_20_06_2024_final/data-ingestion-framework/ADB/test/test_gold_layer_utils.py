from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType,BooleanType,TimestampType,IntegerType, MapType, LongType, DateType
import unittest
import pytest
import json
from pyspark.sql import SparkSession
from ADB.common.gold_layer_utils import resolve_dependency_watermark,execute_gold_layer,run_notebook, get_gold_watermark_init_dict, final_gold_lyr_watermark_dict
from unittest.mock import MagicMock, patch
from pyspark.sql import DataFrame
from datetime import datetime,timedelta,date
from pyspark.sql.functions import to_timestamp
from unittest import TestCase

spark = SparkSession.builder.appName("test").getOrCreate()

# testcase for execute_gold_layer
def test_execute_gold_layer():
    data = [("xtous_us_12_test_framework.test_gold_orders_table", "hard","xtous_us_12_test_framework.test_silver_orders_table" ,"{'prcs_nbk': '/Repos/kamkum@americas.corpdir.net/data-ingestion-framework/ADB/layer_build/gold_layer_build/sample_gold_orders_populate'}",
                      "2024-02-27T05:55:03.958Z","de-test","2024-02-27T05:55:03.958Z","de-test")]
    columns = ["tgt_tbl_nam", "dep_dgre", "src_nam" ,"addnl_info","dts_dw_crea","id_dw_crea_user","dts_dw_updt","id_dw_updt_user"]
    t_d_metadata = spark.createDataFrame(data,columns)
    dbutils = MagicMock()
    src_name = 'xtous_us_12_test_framework.test_silver_orders_table'
    execute_gold_layer(t_d_metadata,src_name,dbutils)
    assert dbutils.assert_called

# testcase for run_notebook
@patch('ADB.common.gold_layer_utils.requests.post')
@patch('ADB.common.gold_layer_utils.get_cluster_info')
def test_run_notebook(cluster_info_mock,request_mock):
    dbutils = MagicMock()
    notebook_list = [
        {'notebook_path': '/Repos/kamkum@americas.corpdir.net/data-ingestion-framework/ADB/layer_build/gold_layer_build/sample_gold_orders_populate'},
    {'notebook_path': '/Repos/kamkum@americas.corpdir.net/data-ingestion-framework/ADB/layer_build/gold_layer_build/sample_gold_sales_populate'
     }
   ]   

    cluster_info_mock.return_value = {'DATABRICKS_TOKEN': 'test_token', 'cluster_id': 'test_cluster_id', 'api_endpoint': 'test_api_endpoint'}
    request_mock.return_value = MagicMock()
    run_notebook(notebook_list,dbutils)
    assert request_mock.assert_called 

def test_resolve_dependency_success():
    import datetime
    successor_name = 't_1_2_gold'
    w_data = [
    ("id1.1", "id1_zip1", "21-02-2024", "delta", "t_1_bronze", "BRONZE_TO_SILVER", "t_1_silver", 1, 5, 5, None, None, None, None, "2024-02-21T01:03:44.325495Z", "2024-02-21T01:05:56.635181Z", "user1", "user1"),
    ("id2.1", "id2_zip1", "21-02-2024", "delta", "t_2_bronze", "BRONZE_TO_SILVER", "t_2_silver", 1, 5, 5, None, None, None, None, "2024-02-21T01:13:44.325495Z", "2024-02-21T01:15:56.635181Z", "user1", "user1")
    ]

    # Define the schema
    w_schema = StructType([
    StructField("id_batch", StringType(), True),
    StructField("id_proc", StringType(), True),
    StructField("run_dte", StringType(), True),
    StructField("inp_typ", StringType(), True),
    StructField("inp_nam", StringType(), True),
    StructField("oper_phase", StringType(), True),
    StructField("tgt_nam", StringType(), True),
    StructField("opr_stat", StringType(), True),
    StructField("in_cnt", IntegerType(), True),
    StructField("out_cnt", IntegerType(), True),
    StructField("ins_cnt", IntegerType(), True),
    StructField("upd_cnt", IntegerType(), True),
    StructField("err_dtls", StringType(), True),
    StructField("addnl_info", StringType(), True),
    StructField("proc_started_ts", StringType(), True),
    StructField("last_updated_ts", StringType(), True),
    StructField("id_dw_crea_user", StringType(), True),
    StructField("id_dw_updt_user", StringType(), True)
    ])
    # Create DataFrame
    watermark_df = spark.createDataFrame(w_data, w_schema)

    # Convert timestamp columns to TimestampType
    timestamp_cols = ["proc_started_ts", "last_updated_ts"]
    for col in timestamp_cols:
        watermark_df = watermark_df.withColumn(col, to_timestamp(col))

    # Define the schema
    t_d_schema = StructType([
    StructField("tgt_tbl_nam", StringType(), True),
    StructField("dep_dgre", StringType(), True),
    StructField("src_nam", StringType(), True),
    StructField("addnl_info", StringType(), True),
    StructField("dts_dw_crea", StringType(), True),
    StructField("id_dw_crea_user", StringType(), True),
    StructField("dts_dw_updt", StringType(), True),
    StructField("id_dw_updt_user", StringType(), True)
    ])

    # Define the data
    t_d_data = [
    ("t_1_2_gold", "hard", "t_1_silver", None, "2024-02-21T07:00:42.142Z", "user1", "2024-02-21T07:00:42.142Z", "user1"),
    ("t_1_2_gold", "hard", "t_2_silver", None, "2024-02-21T07:00:42.142Z", "user1", "2024-02-21T07:00:42.142Z", "user1")
    ]

    # Create DataFrame
    t_d_metadata = spark.createDataFrame(t_d_data, t_d_schema)

    dependency_status,dependency_df,dependency_list = resolve_dependency_watermark(successor_name,t_d_metadata,watermark_df)
    dependency_df = dependency_df.drop('proc_started_ts').orderBy(dependency_df.tgt_nam)

    schema_expect = StructType(
        [
            StructField('id_batch', StringType(), True), 
            StructField('tgt_nam', StringType(), True), 
            StructField('opr_stat', StringType(), True), 
            StructField('run_dte', StringType(), True), 
            StructField('proc_started_ts', TimestampType(), True), 
            StructField('dependency_flag', BooleanType(), True)
        ]
    )

    data_expected = [
        ['id2.1', 't_2_silver', '1', '21-02-2024', datetime.datetime(2024, 2, 21, 6, 43, 44, 325495), True], 
        ['id1.1', 't_1_silver', '1', '21-02-2024', datetime.datetime(2024, 2, 21, 6, 33, 44, 325495), True]
    ]

    df_expected = spark.createDataFrame(data_expected, schema_expect)

    dependency_df.show(truncate=False)
    df_expected = df_expected.drop('proc_started_ts').orderBy(df_expected.tgt_nam)
    df_expected.show(truncate=False)

    dependency_list.sort()

    assert dependency_status == True and dependency_df.subtract(df_expected).count() == 0 and dependency_list == ['t_1_silver', 't_2_silver']

def test_resolve_dependency_failure():
    import datetime
    successor_name = 't_1_2_gold'
    w_data = [
        ("id1.1", "id1_zip1", "21-02-2024", "delta", "t_1_bronze", "BRONZE_TO_SILVER", "t_1_silver", 1, 5, 5, None, None, None, None, "2024-02-21T01:03:44.325495Z", "2024-02-21T01:05:56.635181Z", "user1", "user1"),
        ("id2.1", "id2_zip1", "21-02-2024", "delta", "t_2_bronze", "BRONZE_TO_SILVER", "t_2_silver", 1, 5, 5, None, None, None, None, "2024-02-21T01:13:44.325495Z", "2024-02-21T01:15:56.635181Z", "user1", "user1"),
        ("id1_2.1", "id1_2_zip1", "21-02-2024", "delta", "t_1_silver,t_2_silver", "SILVER_TO_GOLD", "t_1_2_gold", 1, 5, 5, None, None, None, None, "2024-02-21T01:30:44.325495Z", "2024-02-21T01:30:56.635181Z", "user1", "user1")
    ]

    # Define the schema
    w_schema = StructType([
    StructField("id_batch", StringType(), True),
    StructField("id_proc", StringType(), True),
    StructField("run_dte", StringType(), True),
    StructField("inp_typ", StringType(), True),
    StructField("inp_nam", StringType(), True),
    StructField("oper_phase", StringType(), True),
    StructField("tgt_nam", StringType(), True),
    StructField("opr_stat", StringType(), True),
    StructField("in_cnt", IntegerType(), True),
    StructField("out_cnt", IntegerType(), True),
    StructField("ins_cnt", IntegerType(), True),
    StructField("upd_cnt", IntegerType(), True),
    StructField("err_dtls", StringType(), True),
    StructField("addnl_info", StringType(), True),
    StructField("proc_started_ts", StringType(), True),
    StructField("last_updated_ts", StringType(), True),
    StructField("id_dw_crea_user", StringType(), True),
    StructField("id_dw_updt_user", StringType(), True)
    ])
    # Create DataFrame
    watermark_df = spark.createDataFrame(w_data, w_schema)

    # Convert timestamp columns to TimestampType
    timestamp_cols = ["proc_started_ts", "last_updated_ts"]
    for col in timestamp_cols:
        watermark_df = watermark_df.withColumn(col, to_timestamp(col))

    # Define the schema
    t_d_schema = StructType([
    StructField("tgt_tbl_nam", StringType(), True),
    StructField("dep_dgre", StringType(), True),
    StructField("src_nam", StringType(), True),
    StructField("addnl_info", StringType(), True),
    StructField("dts_dw_crea", StringType(), True),
    StructField("id_dw_crea_user", StringType(), True),
    StructField("dts_dw_updt", StringType(), True),
    StructField("id_dw_updt_user", StringType(), True)
    ])

    # Define the data
    t_d_data = [
        ("t_1_2_gold", "hard", "t_1_silver", None, "2024-02-21T07:00:42.142Z", "user1", "2024-02-21T07:00:42.142Z", "user1"),
        ("t_1_2_gold", "hard", "t_2_silver", None, "2024-02-21T07:00:42.142Z", "user1", "2024-02-21T07:00:42.142Z", "user1")
    ]

    # Create DataFrame
    t_d_metadata = spark.createDataFrame(t_d_data, t_d_schema)

    dependency_status,dependency_df,dependency_list = resolve_dependency_watermark(successor_name,t_d_metadata,watermark_df)
    dependency_df = dependency_df.drop('proc_started_ts').orderBy(dependency_df.tgt_nam)

    schema_expect = StructType(
        [
            StructField('id_batch', StringType(), True), 
            StructField('tgt_nam', StringType(), True), 
            StructField('opr_stat', StringType(), True), 
            StructField('run_dte', StringType(), True), 
            StructField('proc_started_ts', TimestampType(), True), 
            StructField('dependency_flag', BooleanType(), True)
        ]
    )

    data_expected = [
        ['id2.1', 't_2_silver', '1', '21-02-2024', datetime.datetime(2024, 2, 21, 6, 43, 44, 325495), False], 
        ['id1.1', 't_1_silver', '1', '21-02-2024', datetime.datetime(2024, 2, 21, 6, 33, 44, 325495), False]
    ]

    df_expected = spark.createDataFrame(data_expected, schema_expect)

    dependency_df.show(truncate=False)
    df_expected = df_expected.drop('proc_started_ts').orderBy(df_expected.tgt_nam)
    df_expected.show(truncate=False)

    dependency_list.sort()

    assert dependency_status == False and dependency_df.subtract(df_expected).count() == 0 and dependency_list == ['t_1_silver', 't_2_silver']

def test_get_gold_watermark_init_dict():
    import datetime
    user_name = 'USSHAHI'
    gold_table_name = 'xtous_us_12_test_framework.test_gold_sales_table'
    dependency_status = False

    dependency_schema = StructType(
        [
            StructField('id_batch', StringType(), True), 
            StructField('tgt_nam', StringType(), True), 
            StructField('opr_stat', StringType(), True), 
            StructField('run_dte', StringType(), True), 
            StructField('proc_started_ts', TimestampType(), True), 
            StructField('dependency_flag', BooleanType(), True)
        ]
    )

    dependency_data = [
        [None, 'xtous_us_12_test_framework.test_gold_employee_table', None, None, None, False], 
        ['testjsonfileone_20240328.json_2024-03-28T00:00:02', 'xtous_us_12_test_framework.test_gold_products_table', '1', datetime.date(2024, 3, 28), datetime.datetime(2024, 3, 28, 17, 15, 30, 353000), True]]

    dependency_df = spark.createDataFrame(dependency_data, dependency_schema)
    dependency_list = ['xtous_us_12_test_framework.test_gold_employee_table','xtous_us_12_test_framework.test_gold_products_table']

    watermark_dict = get_gold_watermark_init_dict(dependency_status,dependency_df, dependency_list, gold_table_name, user_name)

    watermark_expected_dict = {
        'id_batch': 'testjsonfileone_20240328.json_2024-03-28T00:00:02',
        'oper_stat': 0,
        'err_dtls': 'Gold Layer Dependency not satisfied',
        'addnl_info': {'msg': 'Dependency partically satisfied',
        'Not satisfied dependency tables': 'xtous_us_12_test_framework.test_gold_employee_table'},
        'tgt_nam': 'xtous_us_12_test_framework.test_gold_sales_table',
        'id_src_file': 'xtous_us_12_test_framework.test_gold_sales_table',
        'oper_phase': 'GOLD_POPULATION',
        'inp_typ': 'delta',
        'inp_nam': 'xtous_us_12_test_framework.test_gold_employee_table,xtous_us_12_test_framework.test_gold_products_table',
        'user_name': 'USSHAHI'
    }

    del watermark_dict['run_date']
    del watermark_dict['proc_started_ts']

    print()
    print(watermark_dict)
    print(watermark_expected_dict)
    
    assert watermark_dict == watermark_expected_dict

    # TestCase().assertDictEqual(watermark_expected_dict, watermark_dict)

@patch('pyspark.sql.SparkSession.read')
# @patch("ADB.common.common_utilities.read_delta_table")
def test_final_gold_lyr_watermark_dict(mock_read_spark,spark):
    import datetime

    metadata_schema = StructType(
        [
            StructField('tgt_tbl_nam', StringType(), False), StructField('dep_dgre', StringType(), False), StructField('src_nam', StringType(), False), 
            StructField('addnl_info', MapType(StringType(), StringType(), True), True), StructField('dts_dw_crea', TimestampType(), False), 
            StructField('id_dw_crea_user', StringType(), False), StructField('dts_dw_updt', TimestampType(), False), StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    metadata_inp = [
        ['xtous_us_12_test_framework.test_gold_sales_table', 'hard', 'xtous_us_12_test_framework.test_gold_products_table', {'prcs_nbk': '/Repos/kamkum@americas.corpdir.net/data-ingestion-framework/ADB/layer_build/gold_layer_build/test_gold_sales_table'}, datetime.datetime(2024, 3, 13, 12, 30, 6, 71000), 'de-test', datetime.datetime(2024, 3, 13, 12, 30, 6, 71000), 'de-test'], 
        ['xtous_us_12_test_framework.test_gold_sales_table', 'hard', 'xtous_us_12_test_framework.test_gold_employee_table', {'prcs_nbk': '/Repos/kamkum@americas.corpdir.net/data-ingestion-framework/ADB/layer_build/gold_layer_build/test_gold_sales_table'}, datetime.datetime(2024, 3, 13, 12, 30, 36, 968000), 'de-test', datetime.datetime(2024, 3, 13, 12, 30, 36, 968000), 'de-test']
    ]
    
    watermark_schema = StructType(
        [
            StructField('id_batch', StringType(), True), StructField('id_proc', StringType(), False), StructField('run_dte', DateType(), False), 
            StructField('inp_typ', StringType(), True), StructField('inp_nam', StringType(), True), StructField('oper_phase', StringType(), True), 
            StructField('tgt_nam', StringType(), True), StructField('opr_stat', StringType(), True), StructField('in_cnt', LongType(), True), 
            StructField('out_cnt', LongType(), True), StructField('ins_cnt', LongType(), True), StructField('upd_cnt', LongType(), True), 
            StructField('err_dtls', StringType(), True), StructField('addnl_info', MapType(StringType(), StringType(), True), True), 
            StructField('proc_started_ts', TimestampType(), True), StructField('last_updated_ts', TimestampType(), True), StructField('id_dw_crea_user', StringType(), False), 
            StructField('id_dw_updt_user', StringType(), False)
        ]
    )
    
    watermark_data = [
        ['testjsonfileone_20240328.json_2024-03-28T00:00:01', 'f_fw_kakmum_test_api', datetime.date(2024, 3, 28), 'delta', 'xtous_us_12_test_framework.test_bronze_products_table', 'BRONZE_TO_SILVER', 'xtous_us_12_test_framework.test_gold_products_table', '1', 1, 2, 0, 2, None, None, datetime.datetime(2024, 3, 28, 17, 4, 41, 297000), datetime.datetime(2024, 3, 28, 17, 4, 41, 297000), 'USSHAHI', 'USSHAHI'], 
        ['testjsonfileone_20240328.json_2024-03-28T00:00:02', 'f_fw_kakmum_test_api', datetime.date(2024, 3, 28), 'delta', 'xtous_us_12_test_framework.test_bronze_products_table', 'BRONZE_TO_SILVER', 'xtous_us_12_test_framework.test_gold_products_table', '1', 1, 2, 0, 2, None, None, datetime.datetime(2024, 3, 28, 17, 15, 30, 353000), datetime.datetime(2024, 3, 28, 17, 15, 30, 353000), 'USSHAHI', 'USSHAHI'], 
        ['testjsonfileone_20240328.json_2024-03-28T00:00:02', 'xtous_us_12_test_framework.test_gold_sales_table', datetime.date(2024, 3, 29), 'delta', 'xtous_us_12_test_framework.test_gold_employee_table,xtous_us_12_test_framework.test_gold_products_table', 'SILVER_TO_GOLD', 'xtous_us_12_test_framework.test_gold_sales_table', '9', None, None, None, None, 'Gold Layer Dependency not satisfied', {'msg': 'Dependency partically satisfied', 'Not satisfied dependency tables': 'xtous_us_12_test_framework.test_gold_employee_table'}, datetime.datetime(2024, 3, 29, 11, 25, 26, 208358), datetime.datetime(2024, 3, 29, 11, 26, 8, 279259), 'USSHAHI', 'USSHAHI']    
    ]
    
    t_d_metadata = spark.createDataFrame(metadata_inp, metadata_schema)
    watermark_df = spark.createDataFrame(watermark_data, watermark_schema)

    gold_lyr_tbl = 'xtous_us_12_test_framework.test_gold_sales_table'
    dependency_tbl = '`xto-us-12_data-ingestion-control-tables`.`fw_tbl_dep`'
    user_name = 'USSHAHI'
    watermark_tbl = '`xto-us-12_data-ingestion-control-tables`.`fw_watermark`'

    mock_read_spark.side_effect = [t_d_metadata,watermark_df]

    watermark_dict = final_gold_lyr_watermark_dict(gold_lyr_tbl, user_name, dependency_tbl,watermark_tbl)
    
    del watermark_dict['run_date']
    del watermark_dict['proc_started_ts']
    watermark_expected = {'id_batch': None, 'oper_stat': 5, 'tgt_nam': 'xtous_us_12_test_framework.test_gold_sales_table', 'id_src_file': 'xtous_us_12_test_framework.test_gold_sales_table', 'oper_phase': 'GOLD_POPULATION', 'inp_typ': 'delta', 'inp_nam': '', 'user_name': 'USSHAHI'}

    assert watermark_dict == watermark_expected
