from unittest.mock import MagicMock, patch
from ADB.common.pre_process_utils import get_zip_file_metadata,explode_map_column,extract_specific_file_from_zip,get_latest_wm_zip_details,extract_specific_file,string_value_modifier
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType,LongType,MapType
import unittest
import pytest
import json
from pyspark.sql import SparkSession,DataFrame
import pyspark.sql.functions as F
from pyspark.sql import Row

@patch("zipfile.ZipFile")
def test_get_zip_file_metadata(mock_zipfile):
   
    # Set up mock data
    mock_file_info = MagicMock()
    mock_file_info.filename = "file1.txt"
    mock_file_info.date_time = (2024, 1, 31, 12, 0, 0)
    mock_file_info.file_size = 1024
 
    mock_zipfile.return_value.__enter__.return_value.infolist.return_value = [mock_file_info]
 
    # Call the function
    result_df, zip_dict,success,_ = get_zip_file_metadata("dummy.zip")
 
    # Assertions
    assert result_df.schema != StructType([
        StructField("file_name", StringType(), True),
        StructField("modification_time", TimestampType(), True),
        StructField("file_size", LongType(), True),
        StructField("concatenated_meta_columns", StringType(), True)
    ])
 
    assert zip_dict == {"file1.txt": "2024-01-31 12:00:00,1024"}
    assert success is True

def test_explode_map_column(spark):
    # Assuming you have a SparkSession object named spark

    data = [(1, {'key1': 'value1', 'key2': 'value2'}),
            (2, {'key3': 'value3', 'key4': 'value4'})]

    schema = ["id", "map_column"]
    df = spark.createDataFrame(data, schema=schema)

    result_df = explode_map_column(df, "map_column")

    assert result_df.schema == StructType([
    StructField("map_column", MapType(StringType(), StringType(), True), True),
    StructField("file_name", StringType(), False),  # Update this line
    StructField("concatenated_meta_columns", StringType(), True)
])
    
@patch("pyspark.sql.SparkSession.read")
@patch("zipfile.ZipFile")
def test_extract_specific_file_from_zip_success(mock_zipfile, mock_read):
    # Mocking the binaryFile read
    mock_binary_file = MagicMock()
    mock_read.format.return_value.load.return_value.first.return_value.__getitem__.return_value = mock_binary_file

    # Mock the extract method of ZipFile
    mock_zipfile.return_value.__enter__.return_value.extract.return_value = None

    # Call the function
    status = extract_specific_file_from_zip("dummy.zip", "file2.txt", "/extracted/path")

    # Assertions
    assert status != "Successfully extracted file2.txt"
    
@patch("pyspark.sql.SparkSession.read")
@patch("zipfile.ZipFile")
def test_extract_specific_file_from_zip_failure(mock_zipfile, mock_read):
    # Mocking the binaryFile read
    mock_binary_file = MagicMock()
    mock_read.format.return_value.load.return_value.first.return_value.__getitem__.return_value = mock_binary_file

    # Mock the extract method of ZipFile to raise an exception
    mock_zipfile.return_value.__enter__.return_value.extract.side_effect = Exception("Mocked exception")

    # Call the function
    status = extract_specific_file_from_zip("dummy.zip", "file2.txt", "/extracted/path")

    # Assertions
    assert "Error extracting file2.txt" in status
  
@patch("pyspark.sql.SparkSession.read")
@patch("zipfile.ZipFile")
def test_get_latest_wm_zip_details(mock_zipfile, mock_read):
    # Set up SparkSession
    spark = SparkSession.builder.appName("pytest_spark").getOrCreate()

    # Set up mock data for watermark_operations
    mock_watermark_data = [
        (1, "file1.zip", datetime(2024, 1, 31), 1, "success", "2024-01-31 12:00:00"),
        # Add more rows as needed
    ]
    watermark_df = spark.createDataFrame(mock_watermark_data, ["id_proc", "file_name", "run_dte", "opr_stat", "oper_phase", "last_updated_ts"])

    # Mock watermark_operations function
    with patch("ADB.common.watermark_utils.watermark_operations") as mock_watermark_operations:
        mock_watermark_operations.return_value = watermark_df

        # Set up mock data for df_metadata and watermark_dict
        mock_metadata_data = [
            ("file1.zip", "2024-01-31 12:00:00,1024"),
            # Add more rows as needed
        ]
        metadata_df = spark.createDataFrame(mock_metadata_data, ["file_name", "concatenated_meta_columns"])

        watermark_dict = {
            "id_src_file": 1,
            "oper_phase": "phase1",
            "run_date": datetime(2024, 1, 31)
        }

        # Call the function
        result_df,_,_ = get_latest_wm_zip_details("dummy_catalog", "dummy_watermark_table", metadata_df, watermark_dict)

        # Assertions
        assert result_df.count() == 1
        assert "file_name" in result_df.columns
        assert "concatenated_meta_columns" in result_df.columns

@patch("pyspark.sql.SparkSession.read")
@patch("zipfile.ZipFile")
def test_extract_specific_file_success(mock_zipfile, mock_read):
    # Set up SparkSession
    spark = SparkSession.builder.appName("pytest_spark").getOrCreate()

    # Set up mock data for df_to_be_unzip
    mock_metadata_data = [
        ("file1.txt", "2024-01-31 12:00:00,1024"),
        # Add more rows as needed
    ]
    df_to_be_unzip = spark.createDataFrame(mock_metadata_data, ["file_name", "concatenated_meta_columns"])

    # Set up mock data for lm_filter_row
    
    mock_lm_filter_row = {"src_loc": "/staging/", "tgt_nam": "/target/"}

    # Mock the extract_specific_file_from_zip method
    with patch("ADB.common.pre_process_utils.extract_specific_file_from_zip") as mock_extract_specific_file_from_zip:
        mock_extract_specific_file_from_zip.return_value = None

        # Call the function
        total_file_extracted, files_unzipped, list_extracted_file ,_,_= extract_specific_file(mock_lm_filter_row, "dummy.zip", df_to_be_unzip)

        # Assertions
        assert total_file_extracted == 1
        assert files_unzipped == "file1.txt"
        assert len(list_extracted_file) == 1
        assert list_extracted_file[0]["filename"] == "file1.txt"
        assert list_extracted_file[0]["filepath"] == "/target/"

def test_string_value_modifier_no_changes():
    input_string = "Hello, world!"
    key_val_dict = {"foo": "bar", "123": "456"}
    
    result = string_value_modifier(input_string, key_val_dict)
    
    assert result == input_string  

def test_string_value_modifier_single_change():
    input_string = "Replace this foo"
    key_val_dict = {"foo": "bar"}
    
    result = string_value_modifier(input_string, key_val_dict)
    
    assert result == "Replace this bar"

def test_string_value_modifier_multiple_changes():
    input_string = "Replace foo and 123 with their values"
    key_val_dict = {"foo": "bar", "123": "456"}
    
    result = string_value_modifier(input_string, key_val_dict)
    
    assert result == "Replace bar and 456 with their values"

def test_string_value_modifier_empty_input():
    input_string = ""
    key_val_dict = {"foo": "bar", "123": "456"}
    
    result = string_value_modifier(input_string, key_val_dict)
    
    assert result == ""

def test_string_value_modifier_empty_dict():
    input_string = "No changes here"
    key_val_dict = {}
    
    result = string_value_modifier(input_string, key_val_dict)
    
    assert result == input_string


