from ADB.common.dqf_utils import get_config_row, get_final_config, get_parameter_dict, get_failed_records_df, get_good_records, get_rule_config_join_df, get_check_fail_df, get_aggregate_dfq_report, write_df_to_delta, get_row_id, get_information_schema_df, update_null_check_info, update_string_length_check, update_custom_config, update_type_check_info, custom_check_datatype, get_dynamic_config
import pytest
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, LongType, MapType, IntegerType, TimestampType, BooleanType, FloatType
from pyspark.sql.functions import col
from unittest.mock import MagicMock, patch,Mock

# Define a fixture to create a SparkSession.
@pytest.fixture
def spark():
    return SparkSession.builder.appName("pytest_spark").getOrCreate()   

def test_get_config_row():
    row = {
            'id_rule': 1002,
            'rule_nam': 'check_string_consistency',
            'rule_args': 'string_length,method',
            'col_nam': 'lname,fname',
            'kwargs_lst': {'string_length': '6', 'method': 'max'}
        }
    
    result = get_config_row(row)

    excepted_result = {'type': 'check_string_consistency', 'kwargs': {'columns': ['lname', 'fname'], 'string_length': '6', 'method': 'max'}}

    assert result == excepted_result

def test_get_final_config(spark):
    data = [
        [1002, 'check_string_consistency', 'string_length,method', 'fname,lname', {'string_length': '6', 'method': 'max'}]
    ]

    schema = ['id_rule', 'rule_nam', 'rule_args', 'col_nam', 'kwargs_lst']

    df_rule_config_join = spark.createDataFrame(data,schema)

    result_dict = get_final_config(df_rule_config_join, profile_name = 'FRAMEWORK', data_profiling='full', system_name='TEST')

    assert result_dict['checks'][0]['type'] == 'check_string_consistency' and result_dict['checks'][0]['kwargs']['method'] == 'max' \
        and result_dict['checks'][0]['kwargs']['string_length'] == '6' and set(result_dict['checks'][0]['kwargs']['columns']) == set(['fname', 'lname'])

def test_get_failed_records_df(spark):

    data_a = [
        ['Kamlesh', 'Kumar', 'D', '34', '700', 'Online', '2024-03-12', '10', '2024-03-12 05:17:37.765', '7000.0', 'Kamlesh Kumar', '2024-03-12',\
          '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765', 0],
        ['Abhishek', 'Rastogi', None, '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi', \
         '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368]
    ]
    
    data_b = [['Nirnab', 'Chowdhury', 'B', '25', '300', 'Online', '2024-03-12', '1', '2024-03-12 05:17:37.765', '300.0', 'Nirnab Chowdhury',\
                '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765', 3], 
                ['Abhishek', 'Rastogi', None, '12', '900', 'Offline','2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
                  '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368]
            ]
    
    schema = ['fname', 'lname', 'mname', 'age', 'orderAmount', 'orderChannel', 'orderDate', 'orderQuantity', 'order_placed_ts', \
            'total_order', 'full_name', 'rundate', 'created_timestamp', 'updated_timestamp', 'dqf_custom_id']
    
    df_a = spark.createDataFrame(data_a,schema)
    df_b = spark.createDataFrame(data_b,schema)

    inp_list = [
        {'type': 'check_string_consistency',
         'failed_data':[
             {'for_column':'fname','dataframe':df_a},
             {'for_column':'lname','dataframe':df_b}]
        }
    ]

    result_df = get_failed_records_df(dfq_results=inp_list)

    df = df_a.unionAll(df_b)
    df = df.filter(df.dqf_custom_id==0)
    tmp_res = result_df.select(df_b.columns).filter(result_df.dqf_custom_id==0)

    assert set(df.first().asDict().values())==set(tmp_res.first().asDict().values())

def test_get_good_records(spark):

    source_data = [
        ['Kamlesh', 'Kumar', 'D', '34', '700', 'Online', '2024-03-12', '10', '2024-03-12 05:17:37.765', '7000.0', 'Kamlesh Kumar', \
         '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765', 0], 
        ['Abhishek', 'Rastogi', 'None', '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
          '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368]
    ]

    src_schema = ['fname', 'lname', 'mname', 'age', 'orderAmount', 'orderChannel', 'orderDate', 'orderQuantity', 'order_placed_ts', \
        'total_order', 'full_name', 'rundate', 'created_timestamp', 'updated_timestamp', 'dqf_custom_id']

    bad_records_data = [
        ['Abhishek', 'Rastogi', 'None', '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
          '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_string_consistency', 'fname'], 
        ['Abhishek', 'Rastogi', 'None', '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
          '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_string_consistency', 'lname'], 
        ['Abhishek', 'Rastogi', 'None', '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
          '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_null', 'mname']
    ]

    schema_bad = ['fname', 'lname', 'mname', 'age', 'orderAmount', 'orderChannel', 'orderDate', 'orderQuantity', 'order_placed_ts',\
                   'total_order', 'full_name', 'rundate', 'created_timestamp', 'updated_timestamp', 'dqf_custom_id', 'check_type', 'for_column']

    source_df = spark.createDataFrame(source_data,src_schema)
    df_bad_records = spark.createDataFrame(bad_records_data,schema_bad)
    dqf_col_seq_nam = 'dqf_custom_id'

    df_good_records = get_good_records(source_df,df_bad_records,dqf_col_seq_nam)

    excepted_result = set(['Kamlesh', 'Kumar', 'D', '34', '700', 'Online', '2024-03-12', '10', '2024-03-12 05:17:37.765', '7000.0', 'Kamlesh Kumar', \
         '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765'])
    result_from_func = set(df_good_records.first().asDict().values())

    assert result_from_func == excepted_result

def test_get_rule_config_join_df(spark):
    import datetime

    config_id_obj = 'orders_silver_20240312'

    col_config_data = [
        [3, 'orders_silver_20240312', 'this is orders sample table', 'mname', {'string_length': '1', 'method': 'max'}, 1002,\
          datetime.datetime(2024, 3, 12, 5, 42, 22, 754000), 'USSHAHI', datetime.datetime(2024, 3, 12, 5, 42, 22, 754000),'USSHAHI'], 
        [9, 'orders_silver_20240312', 'this is orders sample table', 'lname', {"d_type":"string"}, 1001, \
         datetime.datetime(2024, 3, 12, 5, 43, 22, 143000), 'USSHAHI', datetime.datetime(2024, 3, 12, 5, 43, 22, 143000), 'USSHAHI']
    ]

    col_config_schema = StructType(
        [
            StructField('id_config', LongType(), True), StructField('id_obj', StringType(), False), StructField('obj_des', StringType(), False), 
            StructField('col_nam', StringType(), True), StructField('kwargs_lst', MapType(StringType(), StringType(), True), True), 
            StructField('id_rule', IntegerType(), False), StructField('dts_dw_crea', TimestampType(), False), 
            StructField('id_dw_crea_user', StringType(), False), StructField('dts_dw_updt', TimestampType(), False), 
            StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    rule_data = [
        [1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 12, 7, 25, 32, 895000),\
          'USSHAHI', datetime.datetime(2024, 3, 12, 7, 25, 32, 895000), 'USSHAHI'], 
        [1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 12, 6, 2, 20, 314000), 'USSHAHI', \
         datetime.datetime(2024, 3, 12, 6, 2, 20, 314000), 'USSHAHI'], 
        [1001, 'check_datatype', 'd_type', 'datatype checking', datetime.datetime(2024, 3, 12, 6, 2, 39, 635000), 'USSHAHI', \
         datetime.datetime(2024, 3, 12, 6, 2, 39, 635000), 'USSHAHI']
    ]

    rule_schema = StructType(
        [
            StructField('id_rule', LongType(), True), StructField('rule_nam', StringType(), True), StructField('rule_args', StringType(), True),
            StructField('rule_des', StringType(), True), StructField('dts_dw_crea', TimestampType(), False), 
            StructField('id_dw_crea_user', StringType(), False), StructField('dts_dw_updt', TimestampType(), False), 
            StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    expected_result_data = [
        [1002, 'check_string_consistency', 'string_length,method', 'mname', {'method': 'max', 'string_length': '1'}], 
        [1001, 'check_datatype', 'd_type', 'lname', {'d_type': 'string'}]
    ]
    expected_result_schema = StructType(
        [
            StructField('id_rule', IntegerType(), False), StructField('rule_nam', StringType(), True), 
            StructField('rule_args', StringType(), True), StructField('col_nam', StringType(), False), 
            StructField('kwargs_lst', MapType(StringType(), StringType(), True), True)
        ]
    )

    df_expected_result = spark.createDataFrame(expected_result_data,expected_result_schema)
    df_expected_result = df_expected_result.withColumns(
        {'string_length':df_expected_result.kwargs_lst['string_length'],'method':df_expected_result.kwargs_lst['method']}).drop('kwargs_lst')
    
    df_col_config = spark.createDataFrame(col_config_data,col_config_schema)
    df_rule = spark.createDataFrame(rule_data,rule_schema)

    df_final_result = get_rule_config_join_df(df_col_config,df_rule,config_id_obj)
    df_final_result = df_final_result.withColumns({'string_length':df_final_result.kwargs_lst['string_length'],
                                                   'method':df_final_result.kwargs_lst['method']}).drop('kwargs_lst')

    df_expected_result_typecasting = [col(col_nam).cast('string') for col_nam in df_expected_result.columns]
    df_final_result_typecasting = [col(col_nam).cast('string') for col_nam in df_final_result.columns]

    df_a = df_expected_result.select(df_expected_result_typecasting).drop('col_nam')
    df_b = df_final_result.select(df_final_result_typecasting).drop('col_nam')
    
    df_count = df_a.subtract(df_b)

    assert df_count.count() == 0

@patch('pyspark.sql.SparkSession.read')
@patch("pyspark.sql.DataFrame.write")
def test_write_df_to_delta(mock_write,mock_read,spark):
    import datetime

    inp_data = [
        ['6d368290-3f5b-447e-8b61-3c24174f3bed', 'FRAMEWORK', '0:00:16', datetime.datetime(2024, 3, 15, 19, 50, 30), 'fail', 94.6329345703125,\
          100.0, 94.72222137451172, 96.1111068725586, None, 92.70833587646484, 96.66666412353516, 88.8888931274414, 12, 15, 93.33333587646484,\
        'TEST', False, None
        ]
    ]
    
    inp_schema = StructType(
        [
            StructField('profile_run_id', StringType(), False), StructField('profile_name', StringType(), False), StructField('check_duration[hh:mm:ss]', StringType(), False),
            StructField('time', TimestampType(), False), StructField('checks_result', StringType(), False), StructField('dq_score', FloatType(), True), 
            StructField('uniqueness', FloatType(), True), StructField('completeness', FloatType(), True), StructField('validity', FloatType(), True), 
            StructField('timeliness', FloatType(), True), StructField('accuracy', FloatType(), True), StructField('integrity', FloatType(), True), 
            StructField('reasonability', FloatType(), True), StructField('row_count', LongType(), True), StructField('column_count', IntegerType(), True), 
            StructField('consistency', FloatType(), True), StructField('system_name', StringType(), True), StructField('incremental_flag', BooleanType(), True), 
            StructField('unique_dp_id', StringType(), True)
        ]
    )

    df_inp = spark.createDataFrame(inp_data, inp_schema)

    mock_read.table.return_value = df_inp
    mock_write.return_value = MagicMock()
    catalog_name = 'abc'

    a,b = write_df_to_delta(df_inp,table_name='abc', mode='append',catalog_name=catalog_name)

    assert a == True and b == None

def test_get_row_id(spark):
    source_data = [
        ['Kamlesh', 'Kumar', 'D', '34', '700', 'Online', '2024-03-12', '10', '2024-03-12 05:17:37.765', '7000.0', 'Kamlesh Kumar', \
         '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765',2], 
        ['Abhishek', 'Rastogi', 'None', '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi',\
          '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454',1]
    ]

    src_schema = ['fname', 'lname', 'mname', 'age', 'orderAmount', 'orderChannel', 'orderDate', 'orderQuantity', 'order_placed_ts', \
        'total_order', 'full_name', 'rundate', 'created_timestamp', 'updated_timestamp','dqf_col_seq_nam']
    
    source_df = spark.createDataFrame(source_data,src_schema)
    source_df = source_df.orderBy(source_df.fname)

    expected_df = get_row_id(source_df.drop('dqf_col_seq_nam'), dqf_col_seq_nam='dqf_col_seq_nam')

    assert expected_df.subtract(source_df).count() == 0 

def test_get_check_fail_df(spark):
    import datetime
    mock_dqf_obj = MagicMock()

    check_fail_data = [
        ['ea6b6e2e-c017-4131-866f-acb46ef646bd', 'check_datatype', '0:00:00.001456', '', 'user-defined dataframe', '[check_datatype]: Check run successful',\
        'fname', "[{'d_type': 'string'}, {'overwrite_a22_mapping': None}, {'business_description': None}, {'exclude_check': False}]",\
        'pass', "Expected 'str' is same as fname column datatype 'str'", None, 12, datetime.datetime(2024, 3, 15, 11, 47, 58, 610761),\
        'FRAMEWORK', '4d143545-50d8-4f7f-937f-e6063b98f646', '{pass_count=12, failed_count=0}'], 
        ['ef983b44-00d2-4eb8-83ce-6268a2126251', 'check_string_consistency', '0:00:00.952282', '', 'user-defined dataframe',\
        '[check_string_consistency]: Kindly look into the log file - /dbfs/mnt/de-test/dfq/dqf_log/dqf_FRAMEWORK_TEST_20240315114652_56.log',\
        'fname', "[{'string_length': '6'}, {'method': 'max'}, {'pre_filter': None}, {'overwrite_a22_mapping': None}, {'business_description': None}, {'exclude_check': False}]",\
        'fail', "There are 2 inconsistent strings in column 'fname' which are not matching the max length of 6 ",None, 12,\
        datetime.datetime(2024, 3, 15, 11, 47, 58, 610761), 'FRAMEWORK', '4d143545-50d8-4f7f-937f-e6063b98f646', \
        '{failed_count=2, empty_count=0, pass_count=10}'],
        ['d39b8956-47fc-445e-ba5c-49ba72e2ab56', 'check_null', '0:00:02.717364', '', 'user-defined dataframe',\
        '[check_null]: Check run successful', 'fname', "[{'string_check': False}, {'pre_filter': None}, {'overwrite_a22_mapping': None}, {'business_description': None}, {'exclude_check': False}]",\
        'pass', 'There are no null values', None, 12, datetime.datetime(2024, 3, 15, 11, 47, 58, 610761), 'FRAMEWORK',\
        '4d143545-50d8-4f7f-937f-e6063b98f646', '{pass_count=12, failed_count=0}']
    ]

    check_fail_schema = StructType(
        [
            StructField('check_id', StringType(), True), StructField('check_name', StringType(), True), 
            StructField('runtime[hh:mm:ss:ms]',StringType(), True), StructField('source_path', StringType(), True), 
            StructField('table', StringType(), True), 
            StructField('message', StringType(), True), StructField('column', StringType(), True), 
            StructField('check_arguments', StringType(), True), StructField('result', StringType(), True),
            StructField('description', StringType(), True), StructField('business_description', StringType(), True), 
            StructField('row_count', LongType(), True), StructField('time', TimestampType(), False), 
            StructField('profile_name', StringType(), False), StructField('profile_run_id', StringType(), False), 
            StructField('failure_summary', StringType(), True)
        ]
    )

    df_inp_check_results = spark.createDataFrame(check_fail_data,check_fail_schema)

    mock_dqf_obj.df_check_results = df_inp_check_results

    rule_data = [
        [1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 12, 7, 25, 32, 895000),\
          'USSHAHI', datetime.datetime(2024, 3, 12, 7, 25, 32, 895000), 'USSHAHI'], 
        [1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 12, 6, 2, 20, 314000), 'USSHAHI', \
         datetime.datetime(2024, 3, 12, 6, 2, 20, 314000), 'USSHAHI'], 
        [1001, 'check_datatype', 'd_type', 'datatype checking', datetime.datetime(2024, 3, 12, 6, 2, 39, 635000), 'USSHAHI', \
         datetime.datetime(2024, 3, 12, 6, 2, 39, 635000), 'USSHAHI']
    ]

    rule_schema = StructType(
        [
            StructField('id_rule', LongType(), True), StructField('rule_nam', StringType(), True), StructField('rule_args', StringType(), True),
            StructField('rule_des', StringType(), True), StructField('dts_dw_crea', TimestampType(), False), 
            StructField('id_dw_crea_user', StringType(), False), StructField('dts_dw_updt', TimestampType(), False), 
            StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    df_rule = spark.createDataFrame(rule_data,rule_schema)

    current_ts = datetime.datetime.now()
    df_result = get_check_fail_df(mock_dqf_obj,df_rule,current_ts,current_user='USSHAHI')

    expected_data = [
        ['ef983b44-00d2-4eb8-83ce-6268a2126251', '4d143545-50d8-4f7f-937f-e6063b98f646', 1002, 'fname', 12, 10, 2, \
        '[check_string_consistency]: Kindly look into the log file - /dbfs/mnt/de-test/dfq/dqf_log/dqf_FRAMEWORK_TEST_20240315114652_56.log',\
        datetime.datetime(2024, 3, 16, 1, 4, 37, 699419), 'USSHAHI', datetime.datetime(2024, 3, 16, 1, 4, 37, 699419), 'USSHAHI']
    ]

    expected_schema = StructType(
        [
            StructField('id_chk_fail', StringType(), True), StructField('id_rslt', StringType(), False), 
            StructField('id_rule', IntegerType(), True), StructField('col_nam', StringType(), True), 
            StructField('tot_rcd', IntegerType(), True), StructField('good_rcd', IntegerType(), True), 
            StructField('bad_rcd', IntegerType(), True), StructField('msg', StringType(), True), 
            StructField('dts_dw_crea', TimestampType(), False), StructField('id_dw_crea_user', StringType(), False), 
            StructField('dts_dw_updt', TimestampType(), False), StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    expected_df = spark.createDataFrame(expected_data, expected_schema)
    expected_df = expected_df.drop('dts_dw_crea').drop('dts_dw_updt')
    
    df_result = df_result.drop('dts_dw_crea').drop('dts_dw_updt')

    assert expected_df.subtract(df_result).count() == 0

def test_get_aggregate_dfq_report(spark):
    import datetime

    dfq_profile_results_data = [
        ['6d368290-3f5b-447e-8b61-3c24174f3bed', 'FRAMEWORK', '0:00:16', datetime.datetime(2024, 3, 15, 19, 50, 30), 'fail', 94.6329345703125,\
          100.0, 94.72222137451172, 96.1111068725586, None, 92.70833587646484, 96.66666412353516, 88.8888931274414, 12, 15, 93.33333587646484,\
        'TEST', False, None
        ]
    ]
    
    dfq_profile_results_schema = StructType(
        [
            StructField('profile_run_id', StringType(), False), StructField('profile_name', StringType(), False), StructField('check_duration[hh:mm:ss]', StringType(), False),
            StructField('time', TimestampType(), False), StructField('checks_result', StringType(), False), StructField('dq_score', FloatType(), True), 
            StructField('uniqueness', FloatType(), True), StructField('completeness', FloatType(), True), StructField('validity', FloatType(), True), 
            StructField('timeliness', FloatType(), True), StructField('accuracy', FloatType(), True), StructField('integrity', FloatType(), True), 
            StructField('reasonability', FloatType(), True), StructField('row_count', LongType(), True), StructField('column_count', IntegerType(), True), 
            StructField('consistency', FloatType(), True), StructField('system_name', StringType(), True), StructField('incremental_flag', BooleanType(), True), 
            StructField('unique_dp_id', StringType(), True)
        ]
    )

    df_dfq_profile_results = spark.createDataFrame(dfq_profile_results_data, dfq_profile_results_schema)

    mock_dqf_obj = MagicMock()
    mock_dqf_obj.df_profile_results = df_dfq_profile_results

    id_obj = 'orders_silver_20240312'
    dqf_col_seq_nam = 'dqf_custom_id'

    bad_records_data = [
        ['Abhishek', 'Rastogi', None, '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi', '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_null', 'mname'], 
        ['Abhishek', 'Rastogi', None, '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi', '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_string_consistency', 'fname'], 
        ['Abhishek', 'Rastogi', None, '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:09:35.454', '1800.0', 'Abhishek Rastogi', '2024-03-12', '2024-03-12 19:09:35.454', '2024-03-12 19:09:35.454', 34359738368, 'check_string_consistency', 'lname'],
        ['Harun', 'Jain', None, None, '900', 'Offline', '2024-03-12', '2', '2024-03-12 19:32:48.041', '1800.0', 'Harun Jain', '2024-03-12', '2024-03-12 19:32:48.041', '2024-03-12 19:32:48.041', 42949672960, 'check_null', 'mname'], 
        ['Kamlesh', 'Kumar', 'D', '34', '700', 'Online', '2024-03-12', '10', '2024-03-12 05:17:37.765', '7000.0', 'Kamlesh Kumar', '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765', 0, 'check_string_consistency', 'fname'], 
        ['Nirnab', 'Chowdhury', 'B', '25', '300', 'Online', '2024-03-12', '1', '2024-03-12 05:17:37.765', '300.0', 'Nirnab Chowdhury', '2024-03-12', '2024-03-12 05:17:37.765', '2024-03-12 05:17:37.765', 3, 'check_string_consistency', 'lname'], 
        ['Usama', 'Shahid', None, '12', '900', 'Offline', '2024-03-12', '2', '2024-03-12 07:38:52.602', '1800.0', 'Ajay Singh', '2024-03-12', '2024-03-12 07:38:52.602', '2024-03-12 07:38:52.602', 25769803776, 'check_null', 'mname']
    ]

    bad_records_schema = StructType(
        [
            StructField('fname', StringType(), True), StructField('lname', StringType(), True), StructField('mname', StringType(), True),
            StructField('age', StringType(), True), StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), StructField('order_placed_ts', StringType(), True), 
            StructField('total_order', StringType(), True), StructField('full_name', StringType(), True), 
            StructField('rundate', StringType(), True), StructField('created_timestamp', StringType(), True), 
            StructField('updated_timestamp', StringType(), True), StructField('dqf_custom_id', LongType(), False), 
            StructField('check_type', StringType(), False), StructField('for_column', StringType(), False)
        ]
    )

    df_bad_records = spark.createDataFrame(bad_records_data, bad_records_schema)

    expected_data = [
        ['6d368290-3f5b-447e-8b61-3c24174f3bed', datetime.datetime(2024, 3, 15, 19, 50, 30), 'orders_silver_20240312', 'Framework_layer_build', 12, 7, 5, '/some/path', datetime.datetime(2024, 3, 15, 19, 51, 12, 210860), 'USSHAHI', datetime.datetime(2024, 3, 15, 19, 51, 12, 210860), 'USSHAHI']
    ]

    expected_schema = StructType(
        [
            StructField('id_rslt', StringType(), True), StructField('run_dte', TimestampType(), True), 
            StructField('obj_id', StringType(), False), StructField('obj_des', StringType(), False), 
            StructField('tot_rcd', IntegerType(), True), StructField('good_rcd', IntegerType(), True), 
            StructField('bad_rcd', IntegerType(), True), StructField('bad_rcd_path', StringType(), True), 
            StructField('dts_dw_crea', TimestampType(), False), StructField('id_dw_crea_user', StringType(), False), 
            StructField('dts_dw_updt', TimestampType(), False), StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    df_expected = spark.createDataFrame(expected_data, expected_schema)
    df_expected = df_expected.drop('dts_dw_crea','dts_dw_updt')

    current_ts = datetime.datetime.now()

    df_agg = get_aggregate_dfq_report(mock_dqf_obj,id_obj,dqf_col_seq_nam,df_bad_records,current_ts,bad_rcd_path='/some/path',current_user='USSHAHI')
    df_agg = df_agg.drop('dts_dw_crea','dts_dw_updt')

    assert df_expected.subtract(df_agg).count() == 0

@patch('pyspark.sql.SparkSession.sql')
def test_get_information_schema_df(mock_sql,spark):
    df_inf_sch_schema = StructType(
    [
        StructField('table_catalog', StringType(), False), 
        StructField('table_schema', StringType(), False), 
        StructField('table_name', StringType(), False), 
        StructField('column_name', StringType(), False), 
        StructField('ordinal_position', IntegerType(), False), 
        StructField('column_default', StringType(), True), 
        StructField('is_nullable', StringType(), False), 
        StructField('full_data_type', StringType(), False), 
        StructField('data_type', StringType(), False), 
        StructField('character_maximum_length', LongType(), True), 
        StructField('character_octet_length', LongType(), True), 
        StructField('numeric_precision', IntegerType(), True), 
        StructField('numeric_precision_radix', IntegerType(), True), 
        StructField('numeric_scale', IntegerType(), True), 
        StructField('datetime_precision', IntegerType(), True), 
        StructField('interval_type', StringType(), True), 
        StructField('interval_precision', IntegerType(), True), 
        StructField('maximum_cardinality', LongType(), True), 
        StructField('is_identity', StringType(), False), 
        StructField('identity_generation', StringType(), True), 
        StructField('identity_start', StringType(), True), 
        StructField('identity_increment', StringType(), True), 
        StructField('identity_maximum', StringType(), True), 
        StructField('identity_minimum', StringType(), True), 
        StructField('identity_cycle', StringType(), True), 
        StructField('is_generated', StringType(), False), 
        StructField('generation_expression', StringType(), True), 
        StructField('is_system_time_period_start', StringType(), False), 
        StructField('is_system_time_period_end', StringType(), False), 
        StructField('system_time_period_timestamp_generation', StringType(), True), 
        StructField('is_updatable', StringType(), False), 
        StructField('partition_index', IntegerType(), True), 
        StructField('comment', StringType(), True)
    ]
    )

    df_inf_sch_data = [
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
    ]

    df_inf_sch_expected = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)

    table_name = 'xtous_us_12_test_framework.test_silver_orders_table'
    catalog_name = 'eastus2_extollo_ms_us_edwdev_adbv'

    mock_sql.return_value = df_inf_sch_expected

    df_inf_sch_output = get_information_schema_df(catalog_name,table_name)
    df_inf_sch_output = df_inf_sch_output.select('table_catalog','table_schema','column_name','full_data_type','data_type','ordinal_position','is_nullable')

    df_inf_sch_expected = df_inf_sch_expected.select('table_catalog','table_schema','column_name','full_data_type','data_type','ordinal_position','is_nullable')

    assert df_inf_sch_output.subtract(df_inf_sch_output).count() == 0

def test_update_null_check_info(spark):

    df_rule_config_join_data = [
        (1003, 'check_null', None, 'fname,lname', None), 
        (1002, 'check_string_consistency', 'string_length,method', 'fname,lname', {'method': 'max', 'string_length': '5'})
    ]

    df_rule_config_join_schema = StructType(
        [
            StructField('id_rule', IntegerType(), False), 
            StructField('rule_nam', StringType(), True), 
            StructField('rule_args', StringType(), True), 
            StructField('col_nam', StringType(), False), 
            StructField('kwargs_lst', MapType(StringType(), StringType(), True), True)
        ]
    )

    df_rule_config_join = spark.createDataFrame(df_rule_config_join_data,df_rule_config_join_schema)

    df_inf_sch_schema = StructType(
    [
        StructField('table_catalog', StringType(), False), 
        StructField('table_schema', StringType(), False), 
        StructField('table_name', StringType(), False), 
        StructField('column_name', StringType(), False), 
        StructField('ordinal_position', IntegerType(), False), 
        StructField('column_default', StringType(), True), 
        StructField('is_nullable', StringType(), False), 
        StructField('full_data_type', StringType(), False), 
        StructField('data_type', StringType(), False), 
        StructField('character_maximum_length', LongType(), True), 
        StructField('character_octet_length', LongType(), True), 
        StructField('numeric_precision', IntegerType(), True), 
        StructField('numeric_precision_radix', IntegerType(), True), 
        StructField('numeric_scale', IntegerType(), True), 
        StructField('datetime_precision', IntegerType(), True), 
        StructField('interval_type', StringType(), True), 
        StructField('interval_precision', IntegerType(), True), 
        StructField('maximum_cardinality', LongType(), True), 
        StructField('is_identity', StringType(), False), 
        StructField('identity_generation', StringType(), True), 
        StructField('identity_start', StringType(), True), 
        StructField('identity_increment', StringType(), True), 
        StructField('identity_maximum', StringType(), True), 
        StructField('identity_minimum', StringType(), True), 
        StructField('identity_cycle', StringType(), True), 
        StructField('is_generated', StringType(), False), 
        StructField('generation_expression', StringType(), True), 
        StructField('is_system_time_period_start', StringType(), False), 
        StructField('is_system_time_period_end', StringType(), False), 
        StructField('system_time_period_timestamp_generation', StringType(), True), 
        StructField('is_updatable', StringType(), False), 
        StructField('partition_index', IntegerType(), True), 
        StructField('comment', StringType(), True)
    ]
    )

    df_inf_sch_data = [
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
    ]

    df_inf_sch = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)

    null_id_rule = 1003
    null_rule_nam = 'check_null'

    df_result = update_null_check_info(df_rule_config_join,df_inf_sch,null_id_rule, null_rule_nam)

    df_rule_config_join = df_rule_config_join.drop('kwargs_lst')
    df_result = df_result.drop('kwargs_lst')
    assert df_rule_config_join.subtract(df_result).count() == 0

def test_update_string_length_check(spark):
    import datetime
    df_rule_config_join_data = [
        (1003, 'check_null', None, 'fname,lname', None), 
        (1002, 'check_string_consistency', 'string_length,method', 'fname,lname', {'method': 'max', 'string_length': '5'})
    ]

    df_rule_config_join_schema = StructType(
        [
            StructField('id_rule', IntegerType(), False), 
            StructField('rule_nam', StringType(), True), 
            StructField('rule_args', StringType(), True), 
            StructField('col_nam', StringType(), False), 
            StructField('kwargs_lst', MapType(StringType(), StringType(), True), True)
        ]
    )

    df_rule_config_join = spark.createDataFrame(df_rule_config_join_data,df_rule_config_join_schema)

    df_inf_sch_schema = StructType(
    [
        StructField('table_catalog', StringType(), False), 
        StructField('table_schema', StringType(), False), 
        StructField('table_name', StringType(), False), 
        StructField('column_name', StringType(), False), 
        StructField('ordinal_position', IntegerType(), False), 
        StructField('column_default', StringType(), True), 
        StructField('is_nullable', StringType(), False), 
        StructField('full_data_type', StringType(), False), 
        StructField('data_type', StringType(), False), 
        StructField('character_maximum_length', LongType(), True), 
        StructField('character_octet_length', LongType(), True), 
        StructField('numeric_precision', IntegerType(), True), 
        StructField('numeric_precision_radix', IntegerType(), True), 
        StructField('numeric_scale', IntegerType(), True), 
        StructField('datetime_precision', IntegerType(), True), 
        StructField('interval_type', StringType(), True), 
        StructField('interval_precision', IntegerType(), True), 
        StructField('maximum_cardinality', LongType(), True), 
        StructField('is_identity', StringType(), False), 
        StructField('identity_generation', StringType(), True), 
        StructField('identity_start', StringType(), True), 
        StructField('identity_increment', StringType(), True), 
        StructField('identity_maximum', StringType(), True), 
        StructField('identity_minimum', StringType(), True), 
        StructField('identity_cycle', StringType(), True), 
        StructField('is_generated', StringType(), False), 
        StructField('generation_expression', StringType(), True), 
        StructField('is_system_time_period_start', StringType(), False), 
        StructField('is_system_time_period_end', StringType(), False), 
        StructField('system_time_period_timestamp_generation', StringType(), True), 
        StructField('is_updatable', StringType(), False), 
        StructField('partition_index', IntegerType(), True), 
        StructField('comment', StringType(), True)
    ]
    )

    df_inf_sch_data = [
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
    ]

    df_inf_sch = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)

    df_rule_schema = StructType(
    [
        StructField('id_rule', LongType(), True), 
        StructField('rule_nam', StringType(), True), 
        StructField('rule_args', StringType(), True), 
        StructField('rule_des', StringType(), True), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
    ]
    )

    df_rule_data = [
    (1013, 'custom_check_datatype', None, 'checking datatype', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI'), 
    (1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI'), 
    (1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI')
    ]

    df_rule = spark.createDataFrame(df_rule_data, df_rule_schema)

    df_col_config_schema = StructType(
    [
        StructField('id_config', LongType(), True), 
        StructField('id_obj', StringType(), False), 
        StructField('obj_des', StringType(), False), 
        StructField('col_nam', StringType(), True), 
        StructField('kwargs_lst', MapType(StringType(), StringType(), True), True), 
        StructField('id_rule', IntegerType(), False), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    df_col_config_data = [
    (8, 'test_silver_orders_table', 'this is orders sample table', 'fname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI'), 
    (6, 'test_silver_orders_table', 'this is orders sample table', 'lname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (5, 'test_silver_orders_table', 'this is orders sample table', 'fname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (4, 'test_silver_orders_table', 'this is orders sample table', 'lname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI')
    ]

    df_col_config = spark.createDataFrame(df_col_config_data, df_col_config_schema)

    id_rule = 1002
    length_side = 'max'
    id_obj = 'test_silver_orders_table'

    df_result = update_string_length_check(df_rule_config_join, df_col_config,df_rule, df_inf_sch, id_obj,id_rule,length_side)

    df_rule_config_join = df_rule_config_join.drop('kwargs_lst')
    df_result = df_result.drop('kwargs_lst')
    assert df_rule_config_join.subtract(df_result).count() == 0

def test_update_type_check_info(spark):
    import datetime
    df_rule_config_join_data = [
        (1003, 'check_null', None, 'fname,lname', None), 
        (1002, 'check_string_consistency', 'string_length,method', 'fname,lname', {'method': 'max', 'string_length': '5'})
    ]

    df_rule_config_join_schema = StructType(
        [
            StructField('id_rule', IntegerType(), False), 
            StructField('rule_nam', StringType(), True), 
            StructField('rule_args', StringType(), True), 
            StructField('col_nam', StringType(), False), 
            StructField('kwargs_lst', MapType(StringType(), StringType(), True), True)
        ]
    )

    df_rule_config_join = spark.createDataFrame(df_rule_config_join_data,df_rule_config_join_schema)

    df_inf_sch_schema = StructType(
    [
        StructField('table_catalog', StringType(), False), 
        StructField('table_schema', StringType(), False), 
        StructField('table_name', StringType(), False), 
        StructField('column_name', StringType(), False), 
        StructField('ordinal_position', IntegerType(), False), 
        StructField('column_default', StringType(), True), 
        StructField('is_nullable', StringType(), False), 
        StructField('full_data_type', StringType(), False), 
        StructField('data_type', StringType(), False), 
        StructField('character_maximum_length', LongType(), True), 
        StructField('character_octet_length', LongType(), True), 
        StructField('numeric_precision', IntegerType(), True), 
        StructField('numeric_precision_radix', IntegerType(), True), 
        StructField('numeric_scale', IntegerType(), True), 
        StructField('datetime_precision', IntegerType(), True), 
        StructField('interval_type', StringType(), True), 
        StructField('interval_precision', IntegerType(), True), 
        StructField('maximum_cardinality', LongType(), True), 
        StructField('is_identity', StringType(), False), 
        StructField('identity_generation', StringType(), True), 
        StructField('identity_start', StringType(), True), 
        StructField('identity_increment', StringType(), True), 
        StructField('identity_maximum', StringType(), True), 
        StructField('identity_minimum', StringType(), True), 
        StructField('identity_cycle', StringType(), True), 
        StructField('is_generated', StringType(), False), 
        StructField('generation_expression', StringType(), True), 
        StructField('is_system_time_period_start', StringType(), False), 
        StructField('is_system_time_period_end', StringType(), False), 
        StructField('system_time_period_timestamp_generation', StringType(), True), 
        StructField('is_updatable', StringType(), False), 
        StructField('partition_index', IntegerType(), True), 
        StructField('comment', StringType(), True)
    ]
    )

    df_inf_sch_data = [
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
    ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
    ]

    df_inf_sch = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)

    df_rule_schema = StructType(
    [
        StructField('id_rule', LongType(), True), 
        StructField('rule_nam', StringType(), True), 
        StructField('rule_args', StringType(), True), 
        StructField('rule_des', StringType(), True), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
    ]
    )

    df_rule_data = [
    (1013, 'custom_check_datatype', None, 'checking datatype', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI'), 
    (1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI'), 
    (1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI')
    ]

    df_rule = spark.createDataFrame(df_rule_data, df_rule_schema)

    df_col_config_schema = StructType(
    [
        StructField('id_config', LongType(), True), 
        StructField('id_obj', StringType(), False), 
        StructField('obj_des', StringType(), False), 
        StructField('col_nam', StringType(), True), 
        StructField('kwargs_lst', MapType(StringType(), StringType(), True), True), 
        StructField('id_rule', IntegerType(), False), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
        ]
    )

    df_col_config_data = [
    (8, 'test_silver_orders_table', 'this is orders sample table', 'fname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI'), 
    (6, 'test_silver_orders_table', 'this is orders sample table', 'lname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (5, 'test_silver_orders_table', 'this is orders sample table', 'fname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (4, 'test_silver_orders_table', 'this is orders sample table', 'lname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI')
    ]

    df_col_config = spark.createDataFrame(df_col_config_data, df_col_config_schema)

    id_rule = 1013
    id_obj = 'test_silver_orders_table'
    typecast_dict = {'full_name': 'STRING','fname': 'STRING','orderQuantity': 'INT','orderAmount': 'DECIMAL','orderChannel': 'STRING','age': 'INT','lname': 'STRING','orderDate': 'DATE'}
    type_name = 'INT'

    df_result = update_type_check_info(df_rule_config_join, df_col_config,df_rule, df_inf_sch, id_obj,id_rule, type_name, typecast_dict)

    df_rule_config_join = df_rule_config_join.drop('kwargs_lst')
    df_result = df_result.drop('kwargs_lst')
    assert df_rule_config_join.subtract(df_result).count() == 0
    
def test_update_custom_config(spark):
    config = {
        'profile_name': 'FRAMEWORK','data_profiling': 'full','system_name': 'TEST',
        'checks': [
            {'type': 'check_null', 'kwargs': {'columns': ['fname', 'lname']}},
            {'type': 'check_string_consistency','kwargs': {'columns': ['fname', 'lname'],'method': 'max','string_length': '5'}}
        ]
    }

    custom_datatype_check_func = custom_check_datatype
    col_list = ['orderQuantity', 'age']
    dtype = 'int'
    date_format = 'dd-MM-yyyy'
    timestamp_format = None

    config_result = update_custom_config(config,custom_datatype_check_func,cols=col_list,dtype=dtype,date_format=date_format, timestamp_format = timestamp_format)
    
    del config_result['checks'][-1]['kwargs']['compute_method']

    config_expected = {
        'profile_name': 'FRAMEWORK','data_profiling': 'full','system_name': 'TEST',
        'checks': [
            {'type': 'check_null', 'kwargs': {'columns': ['fname', 'lname']}},
            {'type': 'check_string_consistency','kwargs': {'columns': ['fname', 'lname'],'method': 'max','string_length': '5'}},
            {'type': 'check_custom_function','display_name': 'custom_check_datatype',
             'kwargs': {
                 'columns': ['orderQuantity', 'age'],
                 'iter_cols': True,
                 'extra_args': {'dtype': 'int','date_format': 'dd-MM-yyyy','timestamp_format': None}
                }
            }
        ]
    }
    
    assert config_expected == config_result

def test_custom_check_datatype_int_fail(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid'), 
        ('Usama', 'Shahid', 'ABC', '200', 'Online', '28-12-2023', '1', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='int', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    failed_record_result = result[1].first().asDict()

    failed_record_expected = {'fname': 'Usama',
                              'lname': 'Shahid',
                              'age': 'ABC',
                            'orderAmount': '200',
                            'orderChannel': 'Online',
                            'orderDate': '28-12-2023',
                            'orderQuantity': '1',
                            'full_name': 'Usama Shahid'
                            }

    assert result[0] == False and failed_record_expected == failed_record_result and result[2] == 'Non IntegerType  exists 1 times in age'

def test_custom_check_datatype_int_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='int', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'IntegerType Values in age'

def test_custom_check_datatype_long_fail(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid'), 
        ('Usama', 'Shahid', 'ABC', '200', 'Online', '28-12-2023', '1', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='long', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    failed_record_result = result[1].first().asDict()

    failed_record_expected = {'fname': 'Usama',
                              'lname': 'Shahid',
                              'age': 'ABC',
                            'orderAmount': '200',
                            'orderChannel': 'Online',
                            'orderDate': '28-12-2023',
                            'orderQuantity': '1',
                            'full_name': 'Usama Shahid'
                            }

    assert result[0] == False and failed_record_expected == failed_record_result and result[2] == 'Non LongType  exists 1 times in age'

def test_custom_check_datatype_long_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='long', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'LongType Values in age'

def test_custom_check_datatype_short_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='short', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'ShortType Values in age'

def test_custom_check_datatype_float_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='float', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'FloatType Values in age'

def test_custom_check_datatype_double_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='double', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'DoubleType Values in age'

def test_custom_check_datatype_decimal_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='age', dtype='decimal', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'DecimalType Values in age'

def test_custom_check_datatype_boolean_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh','True'), 
        ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar','True'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar','True'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma','True'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj','True'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury','True'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra','True'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag','True'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid','False')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False),
            StructField('status', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='status', dtype='boolean', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'BooleanType Values in status'

def test_custom_check_datatype_date_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh','True'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar','True'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma','True'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj','True'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury','True'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra','True'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag','True'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid','False')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False),
            StructField('status', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='orderDate', dtype='date', date_format = 'dd-MM-yyyy', timestamp_format = None)
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'DateType Values in orderDate'

def test_custom_check_datatype_timestamp_pass(spark):

    df_unique_records_data = [
        ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh','True'), 
        ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar','True'), 
        ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma','True'), 
        ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj','True'), 
        ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury','True'), 
        ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra','True'), 
        ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag','True'), 
        ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid','False')
    ]

    df_unique_records_schema = StructType(
        [
            StructField('fname', StringType(), False), 
            StructField('lname', StringType(), False), 
            StructField('age', StringType(), False), 
            StructField('orderAmount', StringType(), True), 
            StructField('orderChannel', StringType(), True), 
            StructField('orderDate', StringType(), True), 
            StructField('orderQuantity', StringType(), True), 
            StructField('full_name', StringType(), False),
            StructField('status', StringType(), False)
        ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    result = custom_check_datatype(df_unique_records,column_name='orderDate', dtype='timestamp', date_format = 'dd-MM-yyyy', timestamp_format = 'dd-MM-yyyy')
    
    pass_record_result = result[1].first()

    assert result[0] == True and pass_record_result == None and result[2] == 'TimestampType Values in orderDate'

def test_get_parameter_dict():
    # Define input parameters
    dqf_col_seq_nam = "dqf_col_seq"
    id_obj = "id_object"
    date_format = "dd/MM/yyyy"
    timestamp_format = "HH:mm:ss"
    null_rule_nam = "custom_check_null"
    str_consis_rule_nam = "custom_check_string_consistency"
    str_length_side = "min"
    custom_dtype_rule_nam = "custom_check_datatype"

    # Call the function with the input parameters
    output_dict = get_parameter_dict(
        dqf_col_seq_nam,
        id_obj,
        date_format,
        timestamp_format,
        null_rule_nam,
        str_consis_rule_nam,
        str_length_side,
        custom_dtype_rule_nam
    )

    # Assert the output dictionary contains the expected values.
    assert output_dict == {
        'dqf_col_seq_nam': dqf_col_seq_nam,
        'id_obj': id_obj,
        'date_format': date_format,
        'timestamp_format': timestamp_format,
        'null_rule_nam': null_rule_nam,
        'str_consis_rule_nam': str_consis_rule_nam,
        'str_length_side': str_length_side,
        'custom_dtype_rule_nam': custom_dtype_rule_nam
    }

@patch("ADB.common.dqf_utils.get_rule_config_join_df")
@patch("ADB.common.dqf_utils.update_null_check_info")
@patch("ADB.common.dqf_utils.update_string_length_check")
@patch("ADB.common.dqf_utils.get_final_config")
@patch("ADB.common.dqf_utils.update_type_check_info")
@patch("ADB.common.dqf_utils.update_custom_config")
def test_get_dynamic_config_exception(mock_get_rule_config_join_df,mock_update_null_check_info,mock_update_string_length_check,mock_get_final_config,mock_update_type_check_info,mock_update_custom_config):
    # Mock DataFrame objects
    mock_df_unique_records = MagicMock()
    mock_df_col_config = MagicMock()
    mock_df_rule = MagicMock()
    mock_df_inf_sch = MagicMock()

    # Mock dictionaries
    mock_check_rule_id = {"check_null": 1, "check_string_consistency": 2, "custom_check_datatype": 3}
    mock_typecast_dict = {"column1": "DOUBLE", "column2": "STRING"}
    mock_addnl_param_dict = {
        'id_obj': 'table',
        'date_format': 'dd-MM-yyyy',
        'timestamp_format': 'yyyy-MM-dd',
        'null_rule_nam': 'check_null',
        'str_consis_rule_nam': 'check_string_consistency',
        'str_length_side': 'max',
        'custom_dtype_rule_nam': 'custom_check_datatype'
    }
    # Mock function
    mock_custom_datatype_check_func = MagicMock()
    mock_df_rule_config_join = MagicMock()

    # Mock return value for config
    mock_config = {"config_key": "config_value"}


    # Mock return values for mocked functions
    mock_get_rule_config_join_df.return_value = mock_df_rule_config_join
    mock_update_null_check_info.return_value = mock_df_rule_config_join
    mock_update_string_length_check.return_value = mock_df_rule_config_join
    mock_get_final_config.return_value = mock_config
    mock_update_type_check_info.return_value = mock_df_rule_config_join
    mock_update_custom_config.return_value = mock_config


    with pytest.raises(Exception) as e:
        _ = get_dynamic_config(mock_df_unique_records, mock_df_col_config, mock_df_rule, 
                                         mock_df_inf_sch, mock_check_rule_id, mock_typecast_dict, 
                                         mock_addnl_param_dict, mock_custom_datatype_check_func)

    assert "list index out of range" in str(e.value)


def test_get_dynamic_config(spark):
    import datetime

    df_unique_records_data = [
    ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
    ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
    ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
    ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
    ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
    ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
    ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
    ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
    ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid'), 
    ('Usama', 'Shahid', 'ABC', '200', 'Online', '28-12-2023', '1', 'Usama Shahid')
    ]

    df_unique_records_schema = StructType(
    [
        StructField('fname', StringType(), False), 
        StructField('lname', StringType(), False), 
        StructField('age', StringType(), False), 
        StructField('orderAmount', StringType(), True), 
        StructField('orderChannel', StringType(), True), 
        StructField('orderDate', StringType(), True), 
        StructField('orderQuantity', StringType(), True), 
        StructField('full_name', StringType(), False)
    ]
    )

    df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)

    df_col_config_schema = StructType(
  [
    StructField('id_config', LongType(), True), 
    StructField('id_obj', StringType(), False), 
    StructField('obj_des', StringType(), False), 
    StructField('col_nam', StringType(), True), 
    StructField('kwargs_lst', MapType(StringType(), StringType(), True), True), 
    StructField('id_rule', IntegerType(), False), 
    StructField('dts_dw_crea', TimestampType(), False), 
    StructField('id_dw_crea_user', StringType(), False), 
    StructField('dts_dw_updt', TimestampType(), False), 
    StructField('id_dw_updt_user', StringType(), False)
    ]
)

    df_col_config_data = [
    (8, 'test_silver_orders_table', 'this is orders sample table', 'fname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI'), 
    (6, 'test_silver_orders_table', 'this is orders sample table', 'lname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (5, 'test_silver_orders_table', 'this is orders sample table', 'fname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
    (4, 'test_silver_orders_table', 'this is orders sample table', 'lname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI')
    ]

    df_col_config = spark.createDataFrame(df_col_config_data, df_col_config_schema)

    df_rule_schema = StructType(
    [
        StructField('id_rule', LongType(), True), 
        StructField('rule_nam', StringType(), True), 
        StructField('rule_args', StringType(), True), 
        StructField('rule_des', StringType(), True), 
        StructField('dts_dw_crea', TimestampType(), False), 
        StructField('id_dw_crea_user', StringType(), False), 
        StructField('dts_dw_updt', TimestampType(), False), 
        StructField('id_dw_updt_user', StringType(), False)
    ]
    )

    df_rule_data = [
    (1013, 'custom_check_datatype', None, 'checking datatype', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI'), 
    (1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI'), 
    (1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI')
    ]

    df_rule = spark.createDataFrame(df_rule_data, df_rule_schema)

    df_inf_sch_schema = StructType(
  [
    StructField('table_catalog', StringType(), False), 
    StructField('table_schema', StringType(), False), 
    StructField('table_name', StringType(), False), 
    StructField('column_name', StringType(), False), 
    StructField('ordinal_position', IntegerType(), False), 
    StructField('column_default', StringType(), True), 
    StructField('is_nullable', StringType(), False), 
    StructField('full_data_type', StringType(), False), 
    StructField('data_type', StringType(), False), 
    StructField('character_maximum_length', LongType(), True), 
    StructField('character_octet_length', LongType(), True), 
    StructField('numeric_precision', IntegerType(), True), 
    StructField('numeric_precision_radix', IntegerType(), True), 
    StructField('numeric_scale', IntegerType(), True), 
    StructField('datetime_precision', IntegerType(), True), 
    StructField('interval_type', StringType(), True), 
    StructField('interval_precision', IntegerType(), True), 
    StructField('maximum_cardinality', LongType(), True), 
    StructField('is_identity', StringType(), False), 
    StructField('identity_generation', StringType(), True), 
    StructField('identity_start', StringType(), True), 
    StructField('identity_increment', StringType(), True), 
    StructField('identity_maximum', StringType(), True), 
    StructField('identity_minimum', StringType(), True), 
    StructField('identity_cycle', StringType(), True), 
    StructField('is_generated', StringType(), False), 
    StructField('generation_expression', StringType(), True), 
    StructField('is_system_time_period_start', StringType(), False), 
    StructField('is_system_time_period_end', StringType(), False), 
    StructField('system_time_period_timestamp_generation', StringType(), True), 
    StructField('is_updatable', StringType(), False), 
    StructField('partition_index', IntegerType(), True), 
    StructField('comment', StringType(), True)
  ]
)

    df_inf_sch_data = [
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
]

    df_inf_sch = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)

    check_rule_id = {'check_null':1003,'check_string_consistency':1002,'custom_check_datatype':1013} 

    typecast_dict = {'full_name': 'STRING','fname': 'STRING','orderQuantity': 'INT','orderAmount': 'DECIMAL','orderChannel': 'STRING','age': 'INT','lname': 'STRING','orderDate': 'DATE'}

    addn_param_dict = {
        'dqf_col_seq_nam' : 'dqf_custom_row_id',
        'id_obj' : 'test_silver_orders_table',
        'date_format' : 'dd-MM-yyyy',
        'timestamp_format' : None,
        'null_rule_nam' : 'check_null',
        'str_consis_rule_nam' : 'check_string_consistency',
        'str_length_side' : 'max',
        'custom_dtype_rule_nam' : 'custom_check_datatype'
    }

    config_result = get_dynamic_config(df_unique_records,df_col_config,df_rule,df_inf_sch,check_rule_id,typecast_dict,addn_param_dict,custom_datatype_check_func = custom_check_datatype)

    for compute in config_result['checks'][2:]:
        del compute['kwargs']['compute_method']

    for i in config_result['checks']:
        if i['type'] == 'check_custom_function':
            if i['kwargs']['extra_args']['dtype'] == 'int':
                int_col_list = i['kwargs']['columns']
                int_col_list.sort()

            elif i['kwargs']['extra_args']['dtype'] == 'decimal':
                decimal_col_list = i['kwargs']['columns']
                decimal_col_list.sort()

            elif i['kwargs']['extra_args']['dtype'] == 'date':
                date_col_list = i['kwargs']['columns']
                date_col_list.sort()

        elif i['type'] == 'check_null':
            null_col_list = i['kwargs']['columns']
            null_col_list.sort()
        elif i['type'] == 'check_string_consistency':
            string_col_list = i['kwargs']['columns']
            string_col_list.sort()
    assert int_col_list == ['age', 'orderQuantity'] and decimal_col_list == ['orderAmount'] and date_col_list == ['orderDate'] and null_col_list == ['fname', 'lname'] and string_col_list == ['fname', 'lname']