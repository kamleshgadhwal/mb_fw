from unittest.mock import MagicMock, patch
from ADB.common.file_consitency_utility import is_file_readable,df_read_file,identify_pattern_from_filename,concatenate_columns_convert_to_list,insert_data_to_delta_table
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType
import unittest
import pytest
import json
from pyspark.sql import SparkSession
 
 
@patch("pyspark.sql.SparkSession.read")
def test_is_file_readable(mock_spark_read):
    file_path_csv = "/framework/test/file.csv"
    mock_csv_reader = mock_spark_read.option.return_value.csv.return_value
    mock_csv_reader.limit.return_value.count.return_value = 1
 
    result_csv, error_csv = is_file_readable(file_path_csv, header=True, num_lines_to_read=5, file_type='delimited')
    assert result_csv is True and error_csv is None
    #mock_csv_reader.assert_called_once_with(file_path_csv)
 
 
    file_path_json = "/framework/test/file.json"
    mock_json_reader = mock_spark_read.option.return_value.json.return_value
    mock_json_reader.limit.return_value.count.return_value = 1
 
    result_json, error_json = is_file_readable(file_path_json, header=True, num_lines_to_read=5, file_type='json')
    assert result_json is True and error_json is None
 
    file_path_invalid = "/framework/test/invalid_file.txt"
    result_invalid, error_invalid = is_file_readable(file_path_invalid, header=True, num_lines_to_read=5, file_type='txt')
    assert result_invalid is False and error_invalid is None
 
    # Test case for exception scenario
    mock_spark_read.option.return_value.csv.side_effect = Exception("Test exception")
    result_exception, error_exception = is_file_readable(file_path_csv, header=True, num_lines_to_read=5, file_type='delimited')
    assert result_exception is False and error_exception == "Test exception"
 
# @patch("pyspark.sql.SparkSession.read")
# def test_df_read_file(mock_spark_read):
#     file_path_csv = "/framework/test/orders_bronze_20240118.csv"
#     file_path_json = "/framework/test/file.json"
 
#     # Mocking the SparkSession read method
#     mock_csv_reader = mock_spark_read.option.return_value.csv.return_value
#     mock_csv_reader.limit.return_value.count.return_value = 1
 
#     mock_json_reader = mock_spark_read.option.return_value.json.return_value
#     mock_json_reader.limit.return_value.count.return_value = 1
 
#     # Test CSV file
#     _, success_csv, error_csv = df_read_file('delimited', file_path_csv)
#     assert success_csv is True and error_csv is None
   
#     # Test JSON file
#     _, success_json, error_json = df_read_file('json', file_path_json)
#     assert success_json is True and error_json is None
 
#     _, success_invalid, _ = df_read_file('txt', file_path_csv)
#     assert success_invalid is False
 
#     # Test case for exception scenario in CSV file reading
#     mock_spark_read.option.return_value.csv.side_effect = Exception("Test exception for CSV")
#     _, success_exception_csv, _ = df_read_file('delimited', file_path_csv)
#     assert success_exception_csv is True
 
#     # Test case for exception scenario in JSON file reading
#     mock_spark_read.option.return_value.json.side_effect = Exception("Test exception for JSON")
#     _, success_exception_json, _ = df_read_file('json', file_path_json)
#     assert success_exception_json is False
 
def test_identify_pattern_csv(spark):
    filename = "example_20240123.csv"
    result = identify_pattern_from_filename(filename)
    assert result == "example_yyyyMMdd.csv"
 
# def test_identify_pattern_zip(spark):
#     filename = "example_20240123_12_34_56.zip"
#     result = identify_pattern_from_filename(filename)
#     assert result == "example_yyyyMMdd_hh_mm_ss.zip"
 
# @pytest.mark.parametrize("separator, expected_result", [
#     (",", ["John,25,Engineer", "Alice,30,Data Scientist"]),
#     (" ", ["John 25 Engineer", "Alice 30 Data Scientist"]),
#     ("|", ["John|25|Engineer", "Alice|30|Data Scientist"]),
#     # Add more test cases with different separators
# ])    
     
# def test_concatenate_columns_convert_to_list(spark, separator, expected_result):
#     # Create a PySpark DataFrame for testing
#     data = [("John", 25, "Engineer"),
#             ("Alice", 30, "Data Scientist")]
#     columns = ["Name", "Age", "Occupation"]
#     df = spark.createDataFrame(data, columns)
 
#     # Test with different separators
#     result = concatenate_columns_convert_to_list(df, separator)
#     result_list = result[0]
#     # Add assertions based on your specific requirements
#     assert result_list == expected_result
 
#     # Additional assertions to check the type of the result
#     assert isinstance(result_list, list)
#     assert all(isinstance(item, str) for item in result_list)
 
 
 
@patch("pyspark.sql.SparkSession.builder.appName")
def test_insert_data_to_delta_table(mock_app_name):
    # Mocking the SparkSession.builder.appName method
    mock_spark_session = MagicMock()
    mock_app_name.return_value = mock_spark_session
 
    # Mock the DataFrame and Delta table name
    _ = [
        {"id_batch": "2023-12-26-financial.zip", "id_proc": "orders.csv", "proc_started_ts": "2024-01-11 10:53:44.84064"}
    ]
    df_input = MagicMock()
    df_input.write.format.return_value.option.return_value.mode.return_value.saveAsTable.return_value = MagicMock()
   
    _ = "your_bronze_table"
    _ = "extollo_catelog"