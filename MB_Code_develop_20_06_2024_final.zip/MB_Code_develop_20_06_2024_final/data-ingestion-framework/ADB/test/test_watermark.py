from datetime import datetime
from delta import DeltaTable
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,LongType,MapType
import unittest
import pytest
import json
from pyspark.sql import SparkSession
from ADB.common.watermark_utils import watermark_operations,watermark_read,create_watermark_df,watermark_upsert,Watermark,insert_error_into_watermark,merge_dataframe_into_watermark
from unittest.mock import MagicMock, Mock, patch
from pyspark.sql import DataFrame,Row


spark = SparkSession.builder.appName("test").getOrCreate()

@patch('ADB.common.watermark_utils.watermark_upsert')
@patch('ADB.common.watermark_utils.watermark_read')
@patch('ADB.common.watermark_utils.read_delta_table')
@patch('ADB.common.watermark_utils.create_watermark_df')
def test_insert_error_into_watermark(mock_create_watermark_df,mock_read_delta_table,mock_watermark_read,mock_watermark_upsert):
    spark = SparkSession.builder.appName("test").getOrCreate()

    schema = StructType([
                StructField('id_batch', StringType(), True), StructField('id_proc', StringType(), False), 
                StructField('run_dte', DateType(), False), StructField('inp_typ', StringType(), True), StructField('inp_nam', StringType(), True), 
                StructField('oper_phase', StringType(), True), StructField('tgt_nam', StringType(), True), StructField('opr_stat', StringType(), True), 
                StructField('in_cnt', LongType(), True), StructField('out_cnt', LongType(), True), StructField('ins_cnt', LongType(), True), 
                StructField('upd_cnt', LongType(), True), StructField('err_dtls', StringType(), True), 
                StructField('addnl_info', MapType(StringType(), StringType(), True), True), StructField('proc_started_ts', TimestampType(), True), 
                StructField('last_updated_ts', TimestampType(), True), StructField('id_dw_crea_user', StringType(), False), 
                StructField('id_dw_updt_user', StringType(), False)
                ])
    
    watermark_dict = {'id_batch': 'orders_2024-02-13.zip_2024-02-13T10:25:59.1749093Z',
         'id_proc': 'f_fw_orders_csv1',
        'run_dte': datetime.today(),
        'inp_typ': None,
        'inp_nam': None,
        'oper_phase': 'LANDING_TO_BRONZE',
        'tgt_nam': None,
        'opr_stat': '9',
        'in_cnt': None,
        'out_cnt': None,
        'ins_cnt': None,
        'upd_cnt': None,
        'err_dtls': 'some error details',
        'addnl_info': None,
        'proc_started_ts': datetime(2024, 2, 13, 10, 28, 46, 165808),
        'last_updated_ts': datetime(2024, 2, 13, 10, 28, 46, 165808),
        'id_dw_crea_user': 'AZUREDF',
        'id_dw_updt_user': 'AZUREDF'
        }
    
    input_data_mock = [watermark_dict]
    
    df_watermark_entry = spark.createDataFrame(input_data_mock, schema=schema)

    mock_read_delta_table.return_value = df_watermark_entry
    mock_create_watermark_df.return_value = df_watermark_entry    
    mock_watermark_upsert.return_value = None, True
    mock_watermark_read.return_value = df_watermark_entry
    mock_df = MagicMock()

    catlg_nam = mock_df.MagicMock()
    wm_tabl_nam = mock_df.MagicMock()
    error_code = mock_df.MagicMock()
    error_message = mock_df.MagicMock()

    watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = insert_error_into_watermark(catlg_nam, wm_tabl_nam, watermark_dict, error_code, error_message)

    assert watermark_insert_flag == True and watermark_insert_error == None and df_watermark_read.first().asDict() == df_watermark_insert.first().asDict()

    
@patch("ADB.common.common_utilities.merge_dataframe_into_delta")
def test_watermark_upsert_success(merge_mock, spark):
    # Define input data
    data = [("1", "Souvik"), ("2", "Manish")]
    columns = ["id", "name"]
    df_mock = spark.createDataFrame(data, columns)
    
    # Mock merge_dataframe_into_delta function
    merge_mock.return_value = True, None
    
    # Call the watermark_upsert function
    watermark_insert_error, watermark_insert_status = watermark_upsert("extollo_catelog", "schema_name.wm_tabl_nam", df_mock)
    
    # Assertions
    assert watermark_insert_error is not None
    assert watermark_insert_status is False


@patch('pyspark.sql.SparkSession.read')
def test_watermark_read_end_to_end(mock_read_spark):
    # Mock the read_delta_table function
    mock_read_spark.table.return_value = MagicMock()

    catlg_nam = 'extollo_catelog'
    wm_tabl_nam = 'schema_name.wm_tabl_nam'
    # Mock filter condition
    filter_condition = {'id_proc': 'orders.csv', 'id_batch': '2023-12-26-financial.zip', 'oper_phase': 'LANDING_TO_BRONZE'}

    # Your call to watermark_read
    result_df = watermark_read(catlg_nam, wm_tabl_nam, filter_condition)

    # Assertions based on your specific requirements
    assert isinstance(result_df, MagicMock)
    assert mock_read_spark.table.called_with(wm_tabl_nam, catlg_nam)  

@patch('pyspark.sql.SparkSession.read')
def test_create_watermark_df(mock_read_spark):
    # Mock the read_delta_table function
    mock_read_spark.return_value = MagicMock()

    catlg_nam = 'extollo_catelog'
    wm_tabl_nam = 'schema_name.wm_tabl_nam'
    watermark_data_dict = {'id_batch': 'abc.zip', 'id_proc': 'xyz.csv'}

    # Mock the expected schema
    expected_schema = StructType([
        StructField("id_batch", StringType(), True),
        StructField("id_proc", StringType(), True),
        # Add more fields as needed
    ])

    # Mock the return value of read_delta_table
    mock_read_spark.table.return_value = spark.createDataFrame([], schema=expected_schema)

    # Your call to create_watermark_df
    result_df = create_watermark_df(catlg_nam, wm_tabl_nam, watermark_data_dict)

    # Assertions based on your specific requirements
    assert isinstance(result_df, DataFrame)
    assert mock_read_spark.table.called_with(wm_tabl_nam, catlg_nam)  # Ensure read_delta_table is called with the correct arguments
    assert result_df.schema == expected_schema  # Ensure the schema matches the expected schema

    # Add more assertions based on your specific requirements
    assert result_df.count() == 1
    assert result_df.first() == Row(id_batch='abc.zip', id_proc='xyz.csv')

@patch('ADB.common.watermark_utils.watermark_upsert')
@patch('ADB.common.watermark_utils.watermark_read')
def test_watermark_operations(mock_watermark_read, mock_watermark_upsert):
    # Mocking the behavior of watermark_upsert
    mock_watermark_upsert.return_value = True

    # Mocking the behavior of watermark_read
    mock_watermark_read.return_value = MagicMock()

    catlg_nam = 'extollo_catelog'
    wm_tabl_nam = 'schema_name.wm_tabl_nam'
    df_watermark_input = spark.createDataFrame([('2023-12-26-financial.zip', 'orders.csv', '2024-01-11 10:53:44.84064')], ['id_batch', 'id_proc', 'proc_started_ts'])
    operation = 'upsert'
    filter_condition = {'id_proc': 'orders.csv', 'id_batch': '2023-12-26-financial.zip', 'oper_phase': 'LANDING_TO_BRONZE'}

    # Your call to watermark_operations for upsert
    result_upsert = watermark_operations(catlg_nam, wm_tabl_nam, df_watermark_input, operation=operation)

    # Assertions based on your specific requirements
    assert result_upsert is True
    assert mock_watermark_upsert.called_with(catlg_nam, wm_tabl_nam, df_watermark_input)

    # Your call to watermark_operations for read
    result_read = watermark_operations(catlg_nam, wm_tabl_nam, operation='read', filter_condition=filter_condition)

    # Assertions based on your specific requirements
    assert isinstance(result_read, MagicMock)
    assert mock_watermark_read.called_with(catlg_nam, wm_tabl_nam, filter_condition)


@patch("ADB.common.watermark_utils.create_watermark_df")
@patch("ADB.common.watermark_utils.watermark_operations")
def test_watermark_init_upsert(watermark_ops_mock, create_df_mock):
    # Define input data
    watermark_dict = {
        'id_batch': '123',
        'id_src_file': '456',
        'run_date': '2024-01-01',
        'oper_phase': 'PHASE',
        'oper_stat': 'STATUS',
        'proc_started_ts': '2024-01-01 00:00:00',
        'user_name': 'user',
        'inp_nam': 'input',
        'inp_typ': 'type',
        'tgt_nam': 'target',
        'in_cnt': 1,
        'out_cnt': 1,
        'ins_cnt': 1,
        'addnl_info': {'info_key': 'info_value'},
        'upd_cnt': 1,
        'err_dtls': 'error'
    }
    catlg_nam = 'extollo_catelog'
    watermark_table = 'schema_name.wm_tabl_nam'

    # Mock create_watermark_df function
    create_df_mock.return_value = Mock()
    
    # Mock watermark_operations function
    watermark_ops_mock.return_value = None, True
     
    # Initialize Watermark object
    watermark = Watermark(watermark_dict, catlg_nam, watermark_table)

    # Call watermark_init_upsert method
    watermark_insert_flag, watermark_insert_error, df_watermark_read, df_watermark_insert = watermark.watermark_init_upsert()
    print(df_watermark_read)
    print(df_watermark_insert)
    # Assertions
    assert watermark_insert_flag is True
    assert watermark_insert_error is None
    assert df_watermark_read is not None 
    assert df_watermark_insert is not None    
    

spark = SparkSession.builder.appName("test_merge").getOrCreate()

# Define sample input data for testing
input_data = [("A", 1, "2024-02-14"), ("B", 2, "2024-02-15"), ("C", 3, "2024-02-16")]
columns = ["id_batch", "id_proc", "proc_started_ts"]
input_df = spark.createDataFrame(input_data, columns)

# Define the target watermark table name for testing
target_wm_tabl_nam = "test_watermark_table"

def test_successful_merge():
    # Mocking DeltaTable and its methods
    with patch('delta.tables.DeltaTable.forName') as mock_for_name:
        with patch.object(DeltaTable, 'alias') as mock_alias:
            with patch.object(DeltaTable, 'merge') as mock_merge:
                # Set up mocks
                mock_for_name.return_value = DeltaTable
                mock_alias.return_value = DeltaTable
                mock_merge.return_value.whenMatchedUpdateAll.return_value.whenNotMatchedInsertAll.return_value.execute.return_value = None

                # Call the function being tested
                error_detail, merge_status = merge_dataframe_into_watermark(input_df, target_wm_tabl_nam)

                # Assertions
                assert merge_status is True
                assert error_detail is None

def test_unsuccessful_merge():
    # Mocking DeltaTable and its methods to simulate an error
    with patch('delta.tables.DeltaTable.forName') as mock_for_name:
        with patch.object(DeltaTable, 'alias') as mock_alias:
            with patch.object(DeltaTable, 'merge') as mock_merge:
                # Set up mocks to raise an exception
                mock_for_name.return_value = DeltaTable
                mock_alias.return_value = DeltaTable
                mock_merge.side_effect = Exception("Test error")

                # Call the function being tested
                error_detail, merge_status = merge_dataframe_into_watermark(input_df, target_wm_tabl_nam)

                # Assertions
                assert merge_status is False
                assert error_detail != "Error during merge:"                
