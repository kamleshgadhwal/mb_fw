from unittest.mock import patch, MagicMock
import pytest
from ADB.common.common_objects import get_spark,get_dbutils
 
def test_get_spark_existing_session():
    # Mock an existing SparkSession
    mock_spark_session = MagicMock()
    with patch('ADB.common.common_objects.SparkSession.getActiveSession', return_value=mock_spark_session):
        spark = get_spark()
    assert spark == mock_spark_session
 
def test_get_spark_new_session():
    # Mock non-existing SparkSession
    with patch('ADB.common.common_objects.SparkSession.getActiveSession', return_value=None):
        with patch('ADB.common.common_objects.SparkSession.builder') as mock_builder:
            mock_builder.master.return_value.getOrCreate.return_value = "mocked_spark"
            spark = get_spark()
    assert spark == "mocked_spark"

 
