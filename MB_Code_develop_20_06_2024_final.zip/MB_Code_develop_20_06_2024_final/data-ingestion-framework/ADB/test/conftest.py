from pyspark.sql import SparkSession

import pytest
from unittest.mock import Mock
import sys
import types

 
@pytest.fixture(scope="session")
def spark():
    spark = (
        SparkSession.builder.master("local[1]")
        .appName("local-tests")
        .config("spark.executor.cores", "1")
        .config("spark.executor.instances", "1")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .getOrCreate()
    )
    yield spark
    spark.stop()


module_name = 'obfuskator_rust'
obfuskator_modules = types.ModuleType(module_name)
sys.modules[module_name] = obfuskator_modules
obfuskator_modules.foo = Mock(name=module_name+'.foo')

