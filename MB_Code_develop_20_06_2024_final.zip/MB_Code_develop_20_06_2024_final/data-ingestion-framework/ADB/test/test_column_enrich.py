from unittest.mock import MagicMock, patch
from ADB.common.column_enrich import split_name,concat_strings,product_of_columns,check_col_typecasting
from datetime import datetime,date
from decimal import Decimal
from pyspark.sql.functions import col,when,substring_index,expr,lit
from pyspark.sql.types import StructType, StructField, StringType, TimestampType,DateType,DecimalType,IntegerType
import unittest
import pytest
import json
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("pytest") \
    .getOrCreate()

def test_split_name(spark):
    data = [("John,Doe", 100.0, 20.0),
            ("Jane,Smith", 200.0, 30.0)]
    columns = ["name", "orderAmount", "quantity"]
    input_df= spark.createDataFrame(data, columns)
    trgt_col_to_enrich = "split_name_output"
    fn_parameters = '{"cols":"name","delimiter":",","position":0}'

    result_df, error = split_name(input_df, trgt_col_to_enrich, fn_parameters)

    assert error is None
    assert result_df.select(trgt_col_to_enrich).collect() == [("John",), ("Jane",)]

def test_concat_strings(spark):
    
    data = [("John,Doe", 100.0, 20.0),
            ("Jane,Smith", 200.0, 30.0)]
    columns = ["name", "orderAmount", "quantity"]
    input_df= spark.createDataFrame(data, columns)
    trgt_col_to_enrich = "concat_strings_output"
    fn_parameters = "name,orderAmount"

    result_df, error = concat_strings(input_df, trgt_col_to_enrich, fn_parameters)

    assert error is None
    assert result_df.select(trgt_col_to_enrich).collect() != [("John Doe",), ("Jane Smith",)]

def test_product_of_columns(spark):
    data = [("John,Doe", 100.0, 20.0),
            ("Jane,Smith", 200.0, 30.0)]
    columns = ["name", "orderAmount", "quantity"]
    input_df= spark.createDataFrame(data, columns)
    trgt_col_to_enrich = "product_output"
    fn_parameters = "orderAmount,quantity"

    result_df, error = product_of_columns(input_df, trgt_col_to_enrich, fn_parameters)

    assert error is None
    assert result_df.select(trgt_col_to_enrich).collect() == [(2000.0,), (6000.0,)]

def test_check_col_typecasting(spark):
    data = [("John,Doe", 100.0, 20.0),
            ("Jane,Smith", 200.0, 30.0)]
    columns = ["name", "orderAmount", "quantity"]
    input_df= spark.createDataFrame(data, columns)
    columns_list = ["orderAmount", "quantity"]
    typecast_check = "float"

    status, error = check_col_typecasting(input_df, columns_list, typecast_check)

    assert status is True
    assert error is None

    # Testing with incorrect type.
    columns_list = ["name"]
    status, error = check_col_typecasting(input_df, columns_list, typecast_check)
    assert status is False
    assert error == "column name is not convertable to float"    