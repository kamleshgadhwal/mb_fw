from unittest.mock import MagicMock, Mock, patch,call
import pytest
from ADB.common.notification_utils import generate_required_notifications,send_email,generate_required_notifications_schema_evolution,generate_required_notifications_bad_records,get_api_failure_retry_count,generate_api_failure_notification,generate_missing_files_notification,generate_pipeline_failure_notification,check_file_size,generate_pipeline_failure_notification_api_eligibility,generate_pipeline_failure_notification_zip_eligibility
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,current_date
from pyspark.sql.types import StringType,DateType,StructField,StructType
from datetime import datetime
import os

@patch('pyspark.sql.SparkSession.read')
@patch('pyspark.sql.SparkSession.read')
def test_generate_required_notifications(read_mock,spark):
    # Sample data for df_email_notif
    data_email_notif = [
        ("notification_type","domain","info","1","email@example.com"),
        ("notification_type","domain","info","2","another@example.com")
    ]
    columns_email_notif = ["notif_typ","inp_domain","msg_typ","msg_tmplt_id","recpnt_email_addr_list"]
    df_email_notif = spark.createDataFrame(data_email_notif, schema=columns_email_notif)
    df_email_notif.show()
    # Sample data for df_email_tmplts
    data_email_tmplts = [
        ("1", "template1","desc","params1"),
        ("2", "template2","desc_final","params2")
    ]
    columns_email_tmplts = ["id", "email_tmplt","desc","params"]
    df_email_tmplts = spark.createDataFrame(data_email_tmplts, schema=columns_email_tmplts)
    df_email_tmplts.show()
    df_joined = df_email_notif.join(df_email_tmplts, col("msg_tmplt_id") == col("id"), "inner") \
                            .select("notif_typ", 
                                    "recpnt_email_addr_list", 
                                    "email_tmplt") \
                            .filter((col("inp_domain") == "domain") & (col("notif_typ") == "notification_type"))
    df_joined.show() 
    result_list = df_joined.collect()
    print(result_list)
  # Convert each row to a dictionary
    list_of_dicts = [row.asDict() for row in result_list]
    print(list_of_dicts)
    read_mock.table.return_value = df_email_notif
    read_mock.table.return_value = df_email_tmplts
    assert generate_required_notifications("notification_type", "domain") == list_of_dicts

@patch('ADB.common.notification_utils.get_dbutils')
@patch('smtplib.SMTP')
@patch('smtplib.SMTP.starttls')
@patch('smtplib.SMTP.login')
@patch('smtplib.SMTP.sendmail')
def test_send_email(mock_sendmail, mock_login, mock_starttls, mock_smtp, mock_get_dbutils):
    # Mocking SMTP server details
    mock_get_dbutils.return_value.secrets.get.side_effect = lambda scope, key: {
        'smtp-user': 'smtp_user',
        'smtp-password': 'smtp_pwd'
    }[key]
 
    # Test sending email
    send_email("Test Subject", "Test Body", "test@example.com")
    
    # Assertions
    mock_smtp.assert_called_once_with('mail-relay.emea.daimler.com', 25)
    assert mock_starttls.call_count != 1
    assert mock_login.call_count != 1
    assert mock_sendmail.call_count != 1

@pytest.fixture
def create_small_file(tmp_path):
    file_path = tmp_path / "small_file.txt"
    with open(file_path, "w") as f:
        f.write("Small file content")
    return str(file_path)

@pytest.fixture
def create_large_file(tmp_path):
    file_path = tmp_path / "large_file.txt"
    with open(file_path, "wb") as f:
        f.write(os.urandom(6 * 1024 * 1024))  # Creating a file of size > 5MB
    return str(file_path)

def test_check_file_size_with_small_file(create_small_file):
    assert check_file_size(create_small_file) is True

def test_check_file_size_with_large_file(create_large_file):
    assert check_file_size(create_large_file) is False

def test_check_file_size_with_invalid_file():
    assert check_file_size(None) is False
    assert check_file_size("") is False
       
@patch('ADB.common.notification_utils.get_extra_missing_cols_between_landing_and_bronze')
@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_required_notifications_schema_evolution(send_email_mock, generate_required_notifications_mock, get_extra_missing_cols_between_landing_and_bronze_mock):
    # Define the return value for get_extra_missing_cols_between_landing_and_bronze
    get_extra_missing_cols_between_landing_and_bronze_mock.return_value = [], []
    
    # Define the return value for generate_required_notifications
    generate_required_notifications_mock.return_value = [{'recpnt_email_addr_list': ['email@example.com'], 'email_tmplt': {'subject': 'Test Subject', 'email_body': 'Test email body'}}]
    success, message = generate_required_notifications_schema_evolution("mocked_bronze_table_name", ["col1", "col2"], "inp_domain", "filename")
    assert success == True
    assert message == "No extra and missing columns"

@patch('ADB.common.notification_utils.get_extra_missing_cols_between_landing_and_bronze')
@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_required_notifications_schema_evolution_exception(send_email_mock, generate_required_notifications_mock, get_extra_missing_cols_between_landing_and_bronze_mock):
    # Mock the exception scenario
    generate_required_notifications_mock.side_effect = Exception('Test exception')
    
    # Call the function being tested
    success, _ = generate_required_notifications_schema_evolution("mocked_bronze_table_name", ["col1", "col2"], "inp_domain", "filename")
    
    # Assertions
    assert success is False


# Import the function being tested


@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
@patch('ADB.common.notification_utils.check_file_size')
def test_generate_required_notifications_bad_records(check_file_size_mock, send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = [{'recpnt_email_addr_list': ['email@example.com'], 'email_tmplt': {'subject': 'Test Subject', 'email_body': 'Test email body'}}]
    
    # Mock check_file_size to return False, simulating file size check failure
    check_file_size_mock.return_value = False

    # Call the function under test
    success, message = generate_required_notifications_bad_records("inp_domain", "filename", 100, 20, "bad_record_path")
    
    # Assertions
    assert not success
    assert message.startswith("Error generating required notifications for bad records:")

@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
@patch('ADB.common.notification_utils.check_file_size')
def test_generate_required_notifications_bad_records_exception(check_file_size_mock, send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = [{'recpnt_email_addr_list': ['email@example.com'], 'email_tmplt': {'subject': 'Test Subject', 'email_body': 'Test email body'}}]
    
    # Mock check_file_size to raise an exception
    check_file_size_mock.side_effect = Exception("File size check failed")

    # Call the function under test
    success, message = generate_required_notifications_bad_records("inp_domain", "filename", 100, 20, "bad_record_path")

    # Assertions
    assert not success
    assert message.startswith("Error generating required notifications for bad records:")


def test_get_api_failure_retry_count():
    # Define the values for id_src_file and oper_phase
    id_src_file_value = "id_src_file_value"
    oper_phase_value = "oper_phase_value"

    spark = SparkSession.builder.appName("test").getOrCreate()

    # Define the schema for the DataFrame
    schema = StructType([
        StructField("oper_phase", StringType(), True),
        StructField("id_proc", StringType(), True),
        StructField("run_dte", DateType(), True)  # Ensure 'run_dte' is defined as DateType
    ])

    # Create a sample DataFrame with a single row
    data = [(oper_phase_value, id_src_file_value, datetime.now().date())]
    df_watermark_mock = spark.createDataFrame(data, schema)

    # Mock the read_delta_table function
    with patch("pyspark.sql.SparkSession.read") as mock_read_delta_table:
        # Set the return value of the mock function to the sample DataFrame
        mock_read_delta_table.return_value = df_watermark_mock

        # Case 1: Exception case when df_watermark_filtered.count() raises an exception
        with patch("pyspark.sql.DataFrame.count") as mock_count:
            mock_count.side_effect = Exception("Simulated count exception")
            retry_count, message = get_api_failure_retry_count(id_src_file_value, oper_phase_value)
            assert retry_count is None
            assert "Error get retry count for API Failure" in message

        # Case 2: Exception case when df_watermark_filtered.orderBy() raises an exception
        with patch("pyspark.sql.DataFrame.orderBy") as mock_order_by:
            mock_order_by.side_effect = Exception("Simulated order by exception")
            retry_count, message = get_api_failure_retry_count(id_src_file_value, oper_phase_value)
            assert retry_count is None
            assert "Error get retry count for API Failure" in message

        # Case 3: Exception case when accessing watermark_latest_record raises an exception
        with patch("pyspark.sql.DataFrame.collect") as mock_collect:
            mock_collect.return_value = [None]  # Simulate empty result for watermark_latest_record
            retry_count, message = get_api_failure_retry_count(id_src_file_value, oper_phase_value)
            assert retry_count is None
            assert "Error get retry count for API Failure" in message




@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_api_failure_notification(send_email_mock, generate_required_notifications_mock):
    # Case 1: Successful notification generation
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'], 
        'email_tmplt': {
            'subject': 'Test Subject', 
            'email_body': 'Test email body'
        }
    }]
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

    # Case 2: No emails generated
    generate_required_notifications_mock.return_value = []  # Empty list returned
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

    # Case 3: Exception in generate_required_notifications
    generate_required_notifications_mock.side_effect = Exception("Mocked exception")
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

    # Case 4: Exception in send_email
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'], 
        'email_tmplt': {
            'subject': 'Test Subject', 
            'email_body': 'Test email body'
        }
    }]
    send_email_mock.side_effect = Exception("Mocked exception in sending email")
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

    # Case 5: Exception in email template evaluation
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'], 
        'email_tmplt': "Invalid email template"  # Invalid email template
    }]
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

    # Case 6: Exception in send_email with multiple recipients
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email1@example.com', 'email2@example.com'], 
        'email_tmplt': {
            'subject': 'Test Subject', 
            'email_body': 'Test email body'
        }
    }]
    send_email_mock.side_effect = Exception("Mocked exception in sending email to multiple recipients")
    success, _ = generate_api_failure_notification(3, "filename", "domain")
    assert success is False

@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
 
   
def test_generate_missing_files_notification(send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = []
 
    # Call the function under test
    success, _ = generate_missing_files_notification("2024-03-15T10:00:00Z", ["filename1", "filename2", "filename3"], "domain")
    assert success is False
    
    # Mock generate_required_notifications to return a list of email details
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': {
            'subject': 'Test Subject',
            'email_body': 'Test email body'
        }
    }]
 
    # Call the function under test again
    success, _ = generate_missing_files_notification("2024-03-15T10:00:00Z", ["filename1", "filename2", "filename3"], "domain")
    assert 1==1
    # Case 2: Exception in generate_required_notifications
    generate_required_notifications_mock.side_effect = Exception("Mocked exception")
    success, _ = generate_missing_files_notification("2024-03-15T10:00:00Z", ["filename1", "filename2", "filename3"], "domain")
    assert success is False
 
    # Case 3: Exception in email template evaluation
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': "Invalid email template"
    }]
    success, _ = generate_missing_files_notification("2024-03-15T10:00:00Z", ["filename1", "filename2", "filename3"], "domain")
    assert success is False
 
    # Case 4: Exception in send_email
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': {
            'subject': 'Test Subject',
            'email_body': 'Test email body'
        }
    }]
    send_email_mock.side_effect = Exception("Mocked exception in sending email")
    success, _ = generate_missing_files_notification("2024-03-15T10:00:00Z", ["filename1", "filename2", "filename3"], "domain")
    assert success is False

@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_pipeline_failure_notification(send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = []

    # Call the function under test
    success, _ = generate_pipeline_failure_notification(["error1", "error2"], "pipeline_runid", "pipeline_name", "pipeline_trigger_time")
    assert success is False
    
    # Mock generate_required_notifications to return a list of email details
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': {
            'subject': 'Test Subject',
            'email_body': 'Test email body'
        }
    }]

    # Call the function under test again
    success, _ = generate_pipeline_failure_notification(["error1", "error2"], "pipeline_runid", "pipeline_name", "pipeline_trigger_time")
    assert 1==1 
@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_pipeline_failure_notification_api_eligibility(send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = []

    # Call the function under test
    success, _ = generate_pipeline_failure_notification_api_eligibility( "pipeline_runid", "pipeline_name", "pipeline_trigger_time", "activity_name")
    assert success is False
    

    # Mock generate_required_notifications to return a list of email details
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': {
            'subject': 'Test Subject',
            'email_body': 'Test email body'
        }
    }]

    # Call the function under test again
    success, _ = generate_pipeline_failure_notification_api_eligibility( "pipeline_runid", "pipeline_name", "pipeline_trigger_time", "activity_name")
    assert 1==1      

@patch('ADB.common.notification_utils.generate_required_notifications')
@patch('ADB.common.notification_utils.send_email')
def test_generate_pipeline_failure_notification_zip_eligibility(send_email_mock, generate_required_notifications_mock):
    # Mock return value for generate_required_notifications
    generate_required_notifications_mock.return_value = []

    # Call the function under test
    success, _ = generate_pipeline_failure_notification_zip_eligibility( "pipeline_runid", "pipeline_name", "pipeline_trigger_time", "activity_name")
    assert success is False
    

    # Mock generate_required_notifications to return a list of email details
    generate_required_notifications_mock.return_value = [{
        'recpnt_email_addr_list': ['email@example.com'],
        'email_tmplt': {
            'subject': 'Test Subject',
            'email_body': 'Test email body'
        }
    }]

    # Call the function under test again
    success, _ = generate_pipeline_failure_notification_zip_eligibility( "pipeline_runid", "pipeline_name", "pipeline_trigger_time", "activity_name")

    assert 1==1
