# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from pyspark.sql.functions import col
from ADB.common.common_utilities import read_delta_table
from ADB.common.metadata_operations import filter_dataframe,framwork_cstom_error
from ADB.common.file_consitency_utility import identify_pattern_from_filename,concatenate_columns_convert_to_list

# COMMAND ----------

dbutils.widgets.text("filename","")
dbutils.widgets.text("filepath","")
filename = dbutils.widgets.get("filename")
filepath = dbutils.widgets.get("filepath")

# COMMAND ----------

list_concat_cols=[
		"ftb_oneapi_response_api_historical~1~/Framework/layer_build/execute_layer_bronze_populate",
		"ftb_oneapi_response_api_historical~2~/Framework/layer_build/execute_layer_silver_populate"
	]

if list_concat_cols==False:
  error_message = 'Concatenated list of columns is empty'
  raise framwork_cstom_error(error_message)

# COMMAND ----------

# DBTITLE 1,Exit notebook
dbutils.notebook.exit(list_concat_cols)
