# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from pyspark.sql.functions import col, udf  
from pyspark.sql.types import BooleanType

# COMMAND ----------

returnValue = {
'addnl_info': {'nb': '/Framework/tirebuild_historical_processing/tirebuild_api_nb_historical'}, 
'id_src_file': 'ftb_oneapi_response_api_historical', 
'nam_src_file': 'oneapi_yyyyMMdd.json', 
'src_addr_spec': 'API', 
'file_arvl_freq': '0 0  * * *', 
'ldg_path_extollo': '/mnt/adls-vehicle-swt/TIRE BUILD/historical/', 
'domn_area': 'OneAPI'
}

# COMMAND ----------

dbutils.notebook.exit(returnValue)
