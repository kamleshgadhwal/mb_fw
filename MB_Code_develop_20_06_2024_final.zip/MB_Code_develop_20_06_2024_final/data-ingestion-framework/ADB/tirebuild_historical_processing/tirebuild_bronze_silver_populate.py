# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------


from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType, LongType, BooleanType
from ADB.common.custom_json_handling_functions.tirebuild_utils import explode_with_null, explode_without_null,column_mapping
from ADB.common.config import OPER_PHASE_BRONZE_TO_SILVER,OPER_STAT_DICT,INFORMATION_SCHEMA_TABLE, MAPPING_TABLE_NAME,SILVER_AUDIT_COLUMNS,BRONZE_AUDIT_COLUMNS,catlg_nam,wm_tabl_nam,LAYER_TABLE_NAME,OPER_PHASE_LANDING_TO_BRONZE,COLUMN_ENRICH_TABLE_NAME,DEPENDENCY_TABLE_NAME
from ADB.common.metadata_operations import get_bad_dup_records,get_good_dup_records,column_casting,insert_audit_columns,rename_columns_using_mapping_table,latest_bronze_data_using_watermark, get_silver_schema_records, get_col_enrich_list, get_enrich_col, final_col_enrich,custom_json_handling,final_upload_csv_to_volume,move_temp_file,insert_watermark_with_error,framwork_cstom_error
from ADB.common.schema_validation import check_schema_validation
from ADB.common.common_utilities import custom_merge_data_into_delta

import os


# COMMAND ----------

dbutils.widgets.text("file_name", "/default/file/path", "File Name")

# COMMAND ----------

file_name = dbutils.widgets.get("file_name")

# COMMAND ----------

abs_filepath = '/mnt/adls-vehicle-swt/TIRE BUILD/historical/'+file_name

# COMMAND ----------

try:
    df = spark.read.option("multiline", "true") \
        .json(abs_filepath)
except Exception as e:
    print(e)

# COMMAND ----------

df = df.select(F.to_json("results").alias("results"))

# COMMAND ----------

df = df.withColumnRenamed('results','json_string')

# COMMAND ----------

df= df.withColumn("rundate",F.current_date())
df= df.withColumn("created_timestamp",F.current_timestamp())

# COMMAND ----------


def insert_data_to_delta_table(df,catalog_name,bronze_table_name):
   
  """
  merge the dataframe into bronze delta table.

Input:
    --df : dataframe to insert into delta table
    - bronze_table_name: bronze table in which we need to insert the data.
Returns:
    - 
"""  
  try:
    df.write.format("delta").option("mergeSchema", "true").mode("append").saveAsTable(f'`{catalog_name}`.'+bronze_table_name)
    return True,None
  except Exception as e:
    print(f"Error during write_to_delta_table: {str(e)}")
    return False, str(e)

# COMMAND ----------

catalog_name=os.environ.get("CATALOG_NAME")
bronze_table_name='`xto-us-12_veh-brz`.`tire_bld_src`'
insert_status, insert_error = insert_data_to_delta_table(df,catalog_name,bronze_table_name)


# COMMAND ----------

if not insert_status:
  dbutils.notebook.exit("Tirebuild Historical Data did not save successfully in bronze table",insert_error)

# COMMAND ----------

json_schema = StructType([
        StructField("bm6", StringType(), True),
        StructField("exFactory", StructType([
            StructField("error", StructType([
                StructField("errorId", LongType(), True),
                StructField("message", StringType(), True),
                StructField("errorList", StringType(), True)  # Assuming errorList is StringType, update as necessary
            ]), True),
            StructField("tirePairs", ArrayType(StructType([
                StructField("tireFA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True),
                StructField("tireRA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True)
            ]), True)),
            StructField("warnings", ArrayType(StructType([
                StructField("warningId", LongType(), True),
                StructField("message", StringType(), True)
            ])), True)
        ]), True),
        StructField("finOrVin", StringType(), True),
        StructField("modelSeries", StringType(), True),
        StructField("originalVisPlant", StringType(), True),
        StructField("plant", StringType(), True),
        StructField("rrk", StructType([
            StructField("error", StructType([
                StructField("errorId", LongType(), True),
                StructField("message", StringType(), True),
                StructField("errorList", StringType(), True)  # Assuming errorList is StringType, update as necessary
            ]), True),
            StructField("tirePairs", ArrayType(StructType([
                StructField("tireFA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True),
                StructField("tireRA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True)
            ]), True)),
            StructField("warnings", ArrayType(StructType([
                StructField("warningId", LongType(), True),
                StructField("message", StringType(), True)
            ])), True)
        ]), True),
        StructField("visFin", StringType(), True),
        StructField("visVin", StringType(), True)
    ])
array_json_schema = ArrayType(json_schema)

# COMMAND ----------

df_flatten_json = df.withColumn("json_string", F.from_json(df["json_string"], array_json_schema))

# COMMAND ----------

df_flatten_json = explode_without_null(df_flatten_json, "json_string")

# COMMAND ----------

column_mapping_dict = {
        "ID_USA_VIN": "json_string.finOrVin",
        "NUM_MODL_SER": "json_string.modelSeries",
        "CDE_BAUM": "json_string.bm6",
        "ID_ERR": "json_string.exFactory.error.errorId",
        "DES_ERR_MSG": "json_string.exFactory.error.message",
        "NAM_ERR_LST": "json_string.exFactory.error.errorList",
        "tirePairs": "json_string.exFactory.tirePairs",
        "warnings": "json_string.exFactory.warnings"
    }

# COMMAND ----------

df_flatten_json = column_mapping(df_flatten_json, column_mapping_dict)

# COMMAND ----------

df_flatten_json = explode_with_null(df_flatten_json, "tirePairs")

# COMMAND ----------

df_flatten_json = explode_with_null(df_flatten_json, "warnings")

# COMMAND ----------

veh_dtl_column_mapping = {
        "ID_USA_VIN": "ID_USA_VIN",
        "NUM_MODL_SER": "NUM_MODL_SER",
        "CDE_BAUM": "CDE_BAUM",
        "ID_ERR": "ID_ERR",
        "DES_ERR_MSG": "DES_ERR_MSG",
        "NAM_ERR_LST": "NAM_ERR_LST",
        "ID_WRN": "warnings.warningId",
        "DES_WRN_MSG": "warnings.message",
        "NUM_FA_GER_PART": "tirePairs.tireFA.asnr",
        "NAM_FA_DSGNTN": "tirePairs.tireFA.designation",
        "NUM_FA_DIM_SIZE": "tirePairs.tireFA.dimension",
        "NUM_FA_LOAD_IDX": "tirePairs.tireFA.loadIndex",
        "NUM_FA_SPD_IDX": "tirePairs.tireFA.speedIndex",
        "NUM_FA_SUPLR_PART": "tirePairs.tireFA.supplierPartNumber",
        "NUM_FA_SUPLR_SKU": "tirePairs.tireFA.ean",
        "NAM_FA_SEAS": "tirePairs.tireFA.season",
        "IND_FA_MERC_ORIGNL": "tirePairs.tireFA.moTag",
        "IND_FA_RUN_FLAT": "tirePairs.tireFA.isRunflat",
        "IND_FA_SOUND_INSULTN": "tirePairs.tireFA.hasFoamInlay",
        "NAM_FA_VEND": "tirePairs.tireFA.vendor",
        "NUM_FA_SIDE_TIRE_SIZE": "tirePairs.tireFA.profile",
        "NUM_RA_GER_PART": "tirePairs.tireRA.asnr",
        "NAM_RA_DSGNTN": "tirePairs.tireRA.designation",
        "NUM_RA_DIM_SIZE": "tirePairs.tireRA.dimension",
        "NUM_RA_LOAD_IDX": "tirePairs.tireRA.loadIndex",
        "NUM_RA_SPD_IDX": "tirePairs.tireRA.speedIndex",
        "NUM_RA_SUPLR_PART": "tirePairs.tireRA.supplierPartNumber",
        "NUM_RA_SUPLR_SKU": "tirePairs.tireRA.ean",
        "NAM_RA_SEAS": "tirePairs.tireRA.season",
        "IND_RA_MERC_ORIGNL": "tirePairs.tireRA.moTag",
        "IND_RA_RUN_FLAT": "tirePairs.tireRA.isRunflat",
        "IND_RA_SOUND_INSULTN": "tirePairs.tireRA.hasFoamInlay",
        "NAM_RA_VEND": "tirePairs.tireRA.vendor",
        "NUM_RA_SIDE_TIRE_SIZE": "tirePairs.tireRA.profile",
    }

# COMMAND ----------

df_flatten_json = column_mapping(df_flatten_json, veh_dtl_column_mapping)

# COMMAND ----------

df_flatten_json = df_flatten_json.filter(F.col('ID_USA_VIN').isNotNull())

# COMMAND ----------

df_flatten_json = df_flatten_json.dropDuplicates(['ID_USA_VIN'])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_FA_TIRE_WDTH", F.split(F.col("NUM_FA_DIM_SIZE"), "/")[0])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_FA_ASPT_RTIO",
                                                 F.split(F.split(F.col("NUM_FA_DIM_SIZE"), "/")[1], ' ')[0])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_FA_RIM_DIAMTR",
                                                 F.split(F.split(F.col("NUM_FA_DIM_SIZE"), "/")[1], 'R')[1])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_RA_TIRE_WDTH", F.split(F.col("NUM_RA_DIM_SIZE"), "/")[0])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_RA_ASPT_RTIO",
                                                 F.split(F.split(F.col("NUM_RA_DIM_SIZE"), "/")[1], ' ')[0])

# COMMAND ----------

df_flatten_json = df_flatten_json.withColumn("NUM_RA_RIM_DIAMTR",
                                                 F.split(F.split(F.col("NUM_RA_DIM_SIZE"), "/")[1], 'R')[1])

# COMMAND ----------

tgt_nam = 'xto-us-12_veh-slv.tire_bld_veh_dtl'

# COMMAND ----------

df_bronze_drop,typecast_dict , silver_schema_records_flag,silver_schema_records_error = get_silver_schema_records(df_flatten_json, catlg_nam,tgt_nam, INFORMATION_SCHEMA_TABLE, SILVER_AUDIT_COLUMNS,BRONZE_AUDIT_COLUMNS)

# COMMAND ----------

addnl_info = {"merge_joining_cols":"ID_USA_VIN","custom_json_handling":"true","custom_json_functionname":"custom_json_handling_tirebuild.get_flatten_json"}

# COMMAND ----------

df_good_records_dup , good_dup_records_flag, good_dup_records_errr= get_good_dup_records(df_bronze_drop, addnl_info)

# COMMAND ----------

df_bad_records_dup = get_bad_dup_records(df_bronze_drop, df_good_records_dup)

# COMMAND ----------

lm_filter_row = {
 'tgt_nam': '`xto-us-12_veh-slv`.tire_bld_veh_dtl',
 'addnl_info': {'merge_joining_cols': 'ID_USA_VIN',
  'custom_json_handling': 'true',
  'custom_json_functionname': 'custom_json_handling_tirebuild.get_flatten_json'}
 }

# COMMAND ----------

df_good_records_dup = df_good_records_dup.withColumn(
    "DES_WRN_MSG",
    F.when(F.length(F.col("DES_WRN_MSG")) >= 500, F.substring(F.col("DES_WRN_MSG"), 1, 500))
    .otherwise(F.col("DES_WRN_MSG"))
)

# COMMAND ----------

df_good_records_dup = df_good_records_dup.withColumn(
    "NUM_FA_SPD_IDX",
    F.when(F.length(F.col("NUM_FA_SPD_IDX")) >= 5, F.substring(F.col("NUM_FA_SPD_IDX"), 1, 5))
    .otherwise(F.col("NUM_FA_SPD_IDX"))
)

# COMMAND ----------

df_good_records_dup = df_good_records_dup.withColumn(
    "NUM_RA_SPD_IDX",
    F.when(F.length(F.col("NUM_RA_SPD_IDX")) >= 5, F.substring(F.col("NUM_RA_SPD_IDX"), 1, 5))
    .otherwise(F.col("NUM_RA_SPD_IDX"))
)

# COMMAND ----------

merge_error, merge_stats,df_final = custom_merge_data_into_delta(catlg_nam,df_good_records_dup, lm_filter_row, BRONZE_AUDIT_COLUMNS)

# COMMAND ----------

if merge_stats.get('merge_status') == False:
  print(merge_error)
