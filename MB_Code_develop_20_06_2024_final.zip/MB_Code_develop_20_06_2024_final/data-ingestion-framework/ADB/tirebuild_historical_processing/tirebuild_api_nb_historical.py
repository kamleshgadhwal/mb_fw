# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

import os
from ADB.common.common_objects import get_spark,get_dbutils
from ADB.tirebuild_historical_processing.api_config_transform_historical import get_api_config,get_auth_data,get_vin_list,generate_header,time,get_load_query,save_api_response_historical,create_adw_connection,execute_queries_for_extract,get_api_response_batch


# COMMAND ----------



# COMMAND ----------


landing_historical_path = "dbfs:/mnt/adls-vehicle-swt/TIRE BUILD/historical/"
dbutils = get_dbutils()
api_config_dict=get_api_config(dbutils)

# COMMAND ----------


data={'client_id':api_config_dict.get('client_id'),'client_secret':api_config_dict.get('client_secret'),'grant_type':api_config_dict.get('grant_type')}
auth_data=get_auth_data(api_config_dict.get('auth_url'),data)
access_token=auth_data.get("access_token")
headers=generate_header(access_token)
expire_time=auth_data.get("expires_in")
current_time = time.time()
token_expire_time=expire_time+current_time

# COMMAND ----------

dbutils.widgets.text("start_date","yyyy-mm-dd")
start_date = dbutils.widgets.get("start_date")

# COMMAND ----------

dbutils.widgets.text("end_date","yyyy-mm-dd")
end_date = dbutils.widgets.get("end_date")

# COMMAND ----------

dbutils.widgets.text("input_text", "100000", "Batch Size")
batch_size = int(dbutils.widgets.get("input_text"))

# COMMAND ----------

dbutils.widgets.text("input_time", "600", "time_interval")
time_interval = int(dbutils.widgets.get("input_time"))

# COMMAND ----------

historical_query=get_load_query("historical")
historical_query=historical_query.format(start_date,end_date)
jdbc_url, connection_properties=create_adw_connection(dbutils)
historical_data_df=execute_queries_for_extract(jdbc_url,connection_properties,historical_query)

# COMMAND ----------

historical_query

# COMMAND ----------

vins_data_list=get_vin_list(historical_data_df,"historical")

# COMMAND ----------

if len(vins_data_list) == 0:
  exit_msg = "No records found for {0}".format(end_date)
  returnValue={'Exit Status': exit_msg}
  dbutils.notebook.exit(returnValue)

# COMMAND ----------

api_response_generator=get_api_response_batch(api_config_dict,data,headers,token_expire_time,time_interval,vins_data_list,batch_size)

# COMMAND ----------

for api_data in api_response_generator:
  api_response=api_data[0]
  file_name = save_api_response_historical(api_response,landing_historical_path,end_date,dbutils)

# COMMAND ----------



# COMMAND ----------

returnValue={'status': 'Succeeded','filename':file_name}
dbutils.notebook.exit(returnValue)
