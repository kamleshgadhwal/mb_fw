import requests
import urllib3
import json
from ADB.common.common_objects import get_spark
urllib3.disable_warnings()
import time
import logging
from pyspark.sql import functions as F
from datetime import datetime
import os

spark = get_spark()

def create_adw_connection(dbutils):
    jdbc_hostname = dbutils.secrets.get(scope = 'daps-kv',key = 'salesops-jdbcHostname')
    jdbc_database = dbutils.secrets.get(scope = 'daps-kv',key = 'salesops-jdbcDatabase')
    jdbc_port     = 1433
    jdbc_username = dbutils.secrets.get(scope = 'daps-kv',key = 'VistaDBUser')
    jdbc_password = dbutils.secrets.get(scope = 'daps-kv',key = 'VistaDBpwd')
    jdbc_url      = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbc_hostname, jdbc_port, jdbc_database)
    connection_properties = { "user" : jdbc_username,"password" : jdbc_password,"driver"   : "com.microsoft.sqlserver.jdbc.SQLServerDriver" }
    return jdbc_url, connection_properties

def execute_queries_for_extract(jdbc_url,connection_properties,query):
    result_df = spark.read.jdbc(url=jdbc_url, table=f"({query}) AS adw_table",properties=connection_properties)
    return result_df

# COMMAND ----------

def get_load_query(flag):
  if flag=="historical":
    query="select ID_FIN_VIN,DTE_MODL_YR from ADW_VISTA_EDW.VEHICLE WHERE DTE_MODL_YR IS NOT NULL AND TRY_CAST(DTE_MODL_YR AS INT) IS NOT NULL and ID_FIN_VIN IS NOT NULL and DTE_ACTL_PRODN >= '{0}' and DTE_ACTL_PRODN <= '{1}'"
  else:
    query="select ID_USA_VIN,DTE_EFF,CDE_EVENT from ADW_VISTA_EDW.SWT_VEH_HIST where ID_USA_VIN is not null and CDE_EVENT IN ('ZFVP','ZVPN','ZLPN','ZLVP') and  datediff(day,DTE_EFF,'{0}') = 1"
  return query



# COMMAND ----------


def get_api_config(dbutils):
    api_config_dict = {}
    api_config_dict['client_id']=dbutils.secrets.get(scope = 'daps-kv',key = 'ecs4dq-client-id')
    api_config_dict['client_secret']=dbutils.secrets.get(scope = 'daps-kv',key = 'ecs4dq-client-secret')
    api_config_dict['grant_type'] = "client_credentials"
    api_config_dict['auth_url'] = dbutils.secrets.get(scope = 'daps-kv',key = 'ecs4dq-auth-url')
    api_config_dict["api_base_url"] = dbutils.secrets.get(scope = 'daps-kv',key = 'ecs4dq-api-base-url')
    return api_config_dict


# COMMAND ----------

def get_auth_data(auth_url, data):
    auth_response = requests.post(auth_url, data)
    auth_data = auth_response.json()
    return auth_data


# COMMAND ----------

def generate_header(access_token):
    headers = {"Authorization": f"Bearer {access_token}",
               'Content-type': 'application/json',
               'Connection': 'keep-alive',
               'Accept': '*/*',
               'Accept-Encoding': 'gzip, deflate, br'}
    return headers


# COMMAND ----------

def get_payload(vins):
    payload = {"finOrVin": vins}
    payload = json.dumps(payload)
    return payload


# COMMAND ----------

def fetch_get_response(api_config_dict, vin, data, headers, token_expire_time):
    try:
        base_url = api_config_dict.get("api_base_url")
        auth_url = api_config_dict.get("auth_url")
        if is_token_expired(token_expire_time):
            auth_response = requests.post(auth_url, data=data)
            auth_data = auth_response.json()
            access_token = auth_data.get("access_token")
            updated_header = generate_header(access_token)
            api_response = requests.get(base_url + "/single/" + vin, headers=updated_header,verify=False)
            api_data = api_response.json()
        else:
            api_response = requests.get(base_url + "/single/" + vin, headers=headers,verify=False)
            api_data = api_response.json()
        return api_data

    except Exception as e:
      logging.exception(e)
      raise e


# COMMAND ----------

def fetch_job_id(api_config_dict, vins_list, data, headers, token_expire_time):
    try:
        payload = get_payload(vins_list)
        base_url = api_config_dict.get("api_base_url")
        auth_url = api_config_dict.get("auth_url")
        if is_token_expired(token_expire_time):
            auth_response = requests.post(auth_url, data=data)
            auth_data = auth_response.json()
            access_token = auth_data.get("access_token")
            updated_header = generate_header(access_token)
            api_response = requests.post(base_url + "/batch?uc=exfactory", data=payload, headers=updated_header,
                                         verify=False)
            api_data = api_response.json()

        else:
            api_response = requests.post(base_url + "/batch?uc=exfactory", data=payload, headers=headers,verify=False)
            api_data = api_response.json()

        job_id = str(api_data.get("id"))
        return job_id
    except Exception as e:
      logging.exception(e)
      raise e


# COMMAND ----------

def fetch_jobid_response(api_config_dict,job_id,data,headers,token_expire_time):
  try:
    base_url=api_config_dict.get("api_base_url")
    api_url=base_url+"/batch/{0}/download".format(job_id)
    auth_url=api_config_dict.get("auth_url")
    if is_token_expired(token_expire_time):
      auth_response = requests.post(auth_url, data=data)
      auth_data = auth_response.json()
      access_token = auth_data.get("access_token")
      updated_header=generate_header(access_token)
      json_response=requests.get(api_url,headers=updated_header,verify=False)
      json_data = json_response.json()
    else:
      json_response=requests.get(api_url,headers=headers,verify=False)
      json_data = json_response.json()
    return json_data
  except Exception as e:
    logging.exception(e)
    raise e


# COMMAND ----------

def get_vin_list(df,run_type):
  try:
    if run_type.lower()=="historical":
      key_col="ID_FIN_VIN"
    elif run_type.lower()=="incremental":
      key_col="ID_USA_VIN"
    else:
      key_col="ID_USA_VIN"
    df = df.dropDuplicates([key_col])
    array_vin_rdd = df.select(key_col).collect()
    array_vin = [row[key_col] for row in array_vin_rdd]
    return array_vin
  except Exception as e:
    logging.exception(e)
    raise e

# COMMAND ----------

def is_token_expired(token_expiry):
    current_time = time.time()
    return current_time > token_expiry

def poll_api_server(api_config_dict,job_id,data,headers,token_expire_time,time_interval):
  status_dict={}
  base_url=api_config_dict.get("api_base_url")
  api_url=base_url+"/batch/{0}/status".format(job_id)
  auth_url=api_config_dict.get("auth_url")
  counter=0
  current_datetime = datetime.now()
  start_time=current_datetime.strftime("%Y-%m-%d %H:%M:%S")
  while True:
    try:
      if is_token_expired(token_expire_time):
        auth_response = requests.post(auth_url, data=data)
        auth_data = auth_response.json()
        access_token = auth_data.get("access_token")
        updated_header=generate_header(access_token)
        job_response = requests.get(api_url,headers=updated_header,verify=False)
        job_status_response = job_response.json()
        current_datetime = datetime.now()
      else:
        job_response = requests.get(api_url,headers=headers,verify=False)
        job_status_response = job_response.json()
        current_datetime = datetime.now()
      if job_status_response.get("done")==True:
        status_dict["job_processing"]="Completed"
        status_dict["job_id"]=job_id
        end_time = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
        status_dict["job_start_time"]=start_time
        status_dict["job_end_time"]=end_time
        status_dict["total_polled_second"]=counter*time_interval
        return status_dict
    except Exception as e:
      logging.exception("Failed to connect to the server.")
      raise e
    time.sleep(time_interval)
    counter=counter+1

def is_token_expired(token_expiration_time):
    current_time = time.time()
    return current_time > token_expiration_time


def get_current_datetime():
  current_date = datetime.now()
  formatted_date = current_date.strftime('%Y%m%d')
  return formatted_date

def get_run_date():
  date = datetime.now()
  formatted_date = date.strftime("%Y-%m-%d")
  return formatted_date

def write_json_to_file(dbfs_file_path, data,dbutils):
  json_content = json.dumps(data)
  dbutils.fs.put(dbfs_file_path, json_content, overwrite=True)

def create_folder(folder_path,dbutils):
  child_folder_path = folder_path
  dbutils.fs.mkdirs(child_folder_path) 
    

def get_api_response_batch(api_config_dict,data,headers,token_expire_time,time_interval,vins_data_list,batch_size):
  for i in range(0, len(vins_data_list), batch_size):
    vin_subset_list = vins_data_list[i:i+batch_size]
    job_id=fetch_job_id(api_config_dict,vin_subset_list,data,headers,token_expire_time)
    job_response=poll_api_server(api_config_dict,job_id,data,headers,token_expire_time,time_interval)
    if(job_response.get("job_processing"))=="Completed":
      api_response= fetch_jobid_response(api_config_dict,job_id,data,headers,token_expire_time)
      yield api_response,job_response


# COMMAND ----------

def save_api_response_historical(api_response,landing_storage_path,end_date,dbutils):
  end_date_arr=end_date.split("-")
  formatted_end_date=end_date_arr[0]+end_date_arr[1]+end_date_arr[2]
  folder_path=os.path.join(landing_storage_path)
  create_folder(folder_path,dbutils)
  api_file_name="oneapi_"+formatted_end_date+".json"
  api_json_path = os.path.join(folder_path, api_file_name)
  write_json_to_file(api_json_path, api_response,dbutils)
  return api_file_name