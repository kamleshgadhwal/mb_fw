from ADB.common.common_objects import get_spark
from pyspark.sql import DataFrame
from pyspark.sql.types import StructField, StructType
from datetime import datetime, date


spark = get_spark()

def custom_merge_data_into_delta(catlg_nam:str,source_dataframe:DataFrame, lm_filter_row:dict, audit_columns:list=[])->tuple:
    """
    Merge a DataFrame into a Delta table.

    Input:
        - input_dataframe: PySpark DataFrame to be merged into the Delta table.
        - target_delta_table: target delta table name
        - merge_columns: columns to be used in joining in a lists

    Returns:
        - error: Gives us error details.
        - stats: Stats regarding merging.
    """
    from delta.tables import DeltaTable
    from pyspark.sql.functions import lit,col
    from datetime import datetime

    error = None
    merge_stats = {}
    merge_stats['merge_status'] = False

    try:
      target_delta_table = catlg_nam+'.'+lm_filter_row.get('tgt_nam')
      additional_info = lm_filter_row.get('addnl_info')

      if additional_info == None:
        error = 'Additional information is not found'
        return error,merge_stats,None
      
      else:
        if additional_info.get('merge_joining_cols') == None:
          error = 'Merge keys are not found'
          return error,merge_stats,None
        
        else:
          merge_keys_list = additional_info['merge_joining_cols'].split(',')

    except Exception as e:
      error = str(e)
      return error,merge_stats,None

    try:
      target_name = 'target_table'
      raw_name = 'source_table'
      created_timestamp = datetime.now()
      source_dataframe = source_dataframe.drop(*audit_columns)

      merge_dict = {f'{target_name}.{i}':f'{raw_name}.{i}'for i in source_dataframe.columns}

      when_match_audit_cols = {f'{target_name}.rundate':f'{target_name}.rundate',
                              f'{target_name}.created_timestamp':f'{target_name}.created_timestamp',
                              f'{target_name}.updated_timestamp':lit(created_timestamp)}
      
      when_notmatch_audit_cols = {f'{target_name}.rundate':lit(datetime.today()),
                                  f'{target_name}.created_timestamp':lit(created_timestamp),
                                  f'{target_name}.updated_timestamp':lit(created_timestamp)}

      when_match_dict = merge_dict.copy()
      when_notmatch_dict = merge_dict.copy()
      when_match_dict.update(when_match_audit_cols)
      when_notmatch_dict.update(when_notmatch_audit_cols)

      join_condition = " AND ".join([f"{raw_name}.{col} = {target_name}.{col}" for col in merge_keys_list])

      tgt_delta_tab = DeltaTable.forName(spark, target_delta_table)

      tgt_delta_tab.alias(target_name).merge(
          source_dataframe.alias(raw_name),
          join_condition
      ).whenMatchedUpdate(set = when_match_dict).whenNotMatchedInsert(values = when_notmatch_dict).execute()

      merge_stats = merge_status(target_delta_table)
      merge_stats['merge_status'] = True

      df_update_target = tgt_delta_tab.toDF().filter(col('updated_timestamp')==created_timestamp)

      return error, merge_stats, df_update_target

    except Exception as e:
        error = f"Error during merge: {str(e)}"
        merge_stats = {}
        merge_stats['merge_status'] = False

        return error, merge_stats, None

def merge_dataframe_into_delta(input_dataframe, target_delta_table, merge_columns):
    """
    Merge a DataFrame into a Delta table.

    Input:
        - input_dataframe: PySpark DataFrame to be merged into the Delta table.
        - target_delta_table: target delta table name
        - merge_columns: columns to be used in joining in a lists

    Returns:
        - error: Gives us error details.
        - stats: Stats regarding merging.
    """
    from delta.tables import DeltaTable
    from pyspark.sql import SparkSession, functions as f

    error = None

    try:
        columns = merge_columns
        join_condition = " AND ".join([f"src.{col} = tgt.{col}" for col in columns])

        src_df = input_dataframe
        tgt_delta_tab = DeltaTable.forName(spark, target_delta_table)

        tgt_delta_tab.alias("tgt").merge(
            src_df.alias("src"),
            join_condition
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        merge_stats = merge_status(target_delta_table)
        merge_stats['merge_status'] = True

        return error, merge_stats

    except Exception as e:
        error = f"Error during merge: {str(e)}"
        merge_stats = {}
        merge_stats['merge_status'] = False

        return error, merge_stats


def read_delta_table(table_name:str,catlg_nam:str)->DataFrame:
  """
    This function reads the delta table .
  
    Input:
    - table_name -> name of the table to be read
    - catlg_nam -> catalog name of the table to read
     Returns:
    - readed delta table object.
    """
  try:
    return spark.read.table(f'`{catlg_nam}`.'+table_name)
  except Exception as e:
    print ('Error:',str(e))

def merge_status(target_delta_table):
  """
    This function gives the merge status .
  
    Input:
    - table_name -> target_delta_table
     Returns:
    - merge status.
    """
  return spark.sql(f"describe history {target_delta_table} limit 1").select("operationMetrics").collect()[0]["operationMetrics"]