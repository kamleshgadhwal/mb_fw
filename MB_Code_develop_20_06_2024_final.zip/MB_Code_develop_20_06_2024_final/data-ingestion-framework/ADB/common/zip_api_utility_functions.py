from datetime import datetime,timedelta
from croniter import croniter,CroniterBadCronError
from pyspark.sql.functions import col, udf
from pyspark.sql.types import BooleanType
from datetime import datetime
import pytz
from pyspark.sql import DataFrame

from ADB.common.common_utilities import spark, read_delta_table

# COMMAND ----------
 
def read_filtered_table(df,file_typ):
    """
    This function filter the dataframe based on file type.

    Input:
    - df -> dataframe to be filtered
    - file_typ -> type of the file
     Returns:
    - dataframe after the filter
    """
    df = df.filter(col("file_typ") == file_typ)
    return df

# COMMAND ----------

def filter_watermark_data(log_df, run_date):
    """
    This function filter the dataframe based on run date.

    Input:
    - log_df -> dataframe to be filtered
    - run_date -> based on run date
     Returns:
    - dataframe after the filter based on run date
    """
    return log_df.where(
        (col("opr_stat") == '1') & (col("run_dte") == run_date) & (col("oper_phase") == "api_copy")
    )

# COMMAND ----------


def join_watermark_and_filemaster(df_filemaster_api, df_filtered_watermark_data):
    return df_filemaster_api.join(df_filtered_watermark_data,  col("id_src_file") == col("id_proc"), how="left_anti")
    

# COMMAND ----------

def process_api_file(df_filemaster_api, current_date,water_mark_table,catlg_nam:str):
    """
    This function process the api file to get the final api(json) files to be picked from file master to process.

    Input:
    - df_filemaster_api ->  filemaster dataframe
    - current_date -> dataframe with watermark data
    -water_mark_table - watermark table
    -catlg_nam ->catalog name
     Returns:
    - dataframe final api dataframe
    """
    df_watermark_data = read_delta_table(water_mark_table,catlg_nam)
    df_filtered_watermark_data = filter_watermark_data(df_watermark_data, current_date)
    df_final_api_data = join_watermark_and_filemaster(df_filemaster_api, df_filtered_watermark_data)
    return df_final_api_data

# COMMAND ----------

def get_cron_schedule_datetime(cron_expression, current_datetime):
    """
    This function gets the scheduled cron expression.

    Input:
    - cron_expression ->  cron_expression
    - current_datetime -> current_datetime
     Returns:
    - cron expression 
    """
    cron = croniter(cron_expression, current_datetime)
    return cron.get_prev(datetime)

# COMMAND ----------

def get_current_date():
    """
    This function gets current date .
    Returns:
    - current date
    """
    est_timezone = pytz.timezone('America/New_York')  # Eastern Standard Time (EST)
    est_time = datetime.now(est_timezone)
    return est_time.date()

# COMMAND ----------

def get_current_datetime():
    """
    This function gets current date time .
    Returns:
    - current date time
    """
    est_timezone = pytz.timezone('America/New_York')  # Eastern Standard Time (EST)
    est_time = datetime.now(est_timezone)
    return est_time

# COMMAND ----------

def adjust_current_datetime(current_datetime, prev_schedule_datetime):
    """
    This function to adjest the current date time .
    Input -
     -current_datetime
     -prev_schedule_datetime
    Returns:
    - adjusted current date_time 
    """
    if current_datetime.time() == prev_schedule_datetime.time():
        current_datetime += timedelta(minutes=1)
        return current_datetime, True
    return current_datetime, False

# COMMAND ----------

def check_cron_schedule(cron_expression):
    """
    This function checks the crn schedule based on provided cron expression.
    Input -
     -cron_expression
    Returns:
    - cron expression schedule
    """

    if cron_expression is None or cron_expression.lower() == "null":
        return True

    try:
        current_datetime = get_current_datetime()
        
        prev_schedule_datetime = get_cron_schedule_datetime(cron_expression, current_datetime)

        current_datetime, adjusted = adjust_current_datetime(current_datetime, prev_schedule_datetime)
        if adjusted:
            prev_schedule_datetime = get_cron_schedule_datetime(cron_expression, current_datetime)

        return current_datetime.date() == prev_schedule_datetime.date() and current_datetime.time() >= prev_schedule_datetime.time()

    except CroniterBadCronError:
        # Handle invalid cron expression error
        print("Invalid cron expression provided.")
        return False


# COMMAND ----------

def get_active_zip_details(df_filtered_zip_details):
    """
    This function gets the active zip file details.
    Input -
     -df_filtered_zip_details
    Returns:
    - active zip identifiers in dict format
    """
    active_zip_identifiers=df_filtered_zip_details.select("id_src_file", "nam_src_file", "ldg_path_extollo","src_addr_spec","domn_area").distinct().collect()
    return [row.asDict() for row in active_zip_identifiers]

# COMMAND ----------
check_cron_schedule_udf = udf(check_cron_schedule, BooleanType())

def active_api_details(df_filtered_apis):
    """
    This function gets the active api file details.
    Input -
     -df_filtered_apis
    Returns:
    - active api identifiers in dict format
    """
    active_api_values = df_filtered_apis.filter(col('file_typ') == 'json').select('addnl_info','id_src_file','nam_src_file','src_addr_spec','file_arvl_freq','ldg_path_extollo','domn_area').collect()
    output=[]
    for row in active_api_values:
        flag = check_cron_schedule(row.asDict()['file_arvl_freq']) 
        if flag:
            output.append(row.asDict())
    return output

# COMMAND ----------

def update_dates_in_dict_list(dict_list):
    """
    This function updates the dates in active zip/api dict list.
    Input -
     -dict_list
    Returns:
    - dict_list with updated dates.
    """

    current_year = str(get_current_datetime().year)
    current_month = str(get_current_datetime().month).zfill(2)
    current_date = str(get_current_datetime().day).zfill(2)
    
    for entry in dict_list:
        entry['ldg_path_extollo'] = entry['ldg_path_extollo'].replace('yyyy-MM-dd', f'{current_year}-{current_month}-{current_date}')
        entry['src_addr_spec'] = entry['src_addr_spec'].replace('yyyy', current_year).replace('MM', current_month).replace('dd', current_date)
        entry['nam_src_file'] = entry['nam_src_file'].replace('yyyy', current_year).replace('mm', current_month).replace('dd', current_date)
    return dict_list


# COMMAND ----------

from pyspark.sql.functions import col
from delta.tables import DeltaTable


def merge_delta_table(spark, delta_table_name, new_entry_df):
    """
    This function merge the new dataframe entries in delta table.
    Input -
     -delta_table_name - delta table in which need to merge the data.
     -new_entry_df - datafarme to be merged.
    Returns:

    """
    delta_table = DeltaTable.forName(spark, delta_table_name)
    delta_table.alias("target").merge(new_entry_df.alias("source"),
                                    "target.run_date = source.run_date AND target.extract_identifier = source.extract_identifier"
                                    ).whenMatchedUpdate(set={"status": col("source.status"),
                                                              "start_ts": col("source.start_ts"),
                                                              "last_updated_ts": col("source.last_updated_ts"),
                                                              "error_details": col("source.error_details"),
                                                              "file_name":col("source.file_name"),
                                                              "zip_success":col("source.zip_success")}
                                                       ).whenNotMatchedInsert(values={
        "run_date": col("source.run_date"),
        "ddb_request": col("source.ddb_request"),
        "extract_identifier": col("source.extract_identifier"),
        "status": col("source.status"),
        "start_ts": col("source.start_ts"),
        "last_updated_ts": col("source.last_updated_ts"),
        "error_details": col("source.error_details")
    }).execute()


# COMMAND ----------