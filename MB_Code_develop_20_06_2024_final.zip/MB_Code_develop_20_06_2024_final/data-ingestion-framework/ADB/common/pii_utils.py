from pyspark.sql.functions import udf,col,from_json,lower
from pyspark.sql.types import StringType
import obfuskator_rust
import os
from ADB.common.common_utilities import read_delta_table
from ADB.common.config import LAYER_TABLE_NAME,catlg_nam,RSA_KEY_PATH,COLUMN_TAGS_TABLE_NAME
from ADB.common.file_consitency_utility import df_read_file
from ADB.common.metadata_operations import framwork_cstom_error

# #domain specific path
RSA_KEY_PATH = '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/'

def get_rsa_key_file(domain = '',extension = 'pem'):
  """
    Retrieves the path of the RSA key file for a given domain.

    Input:
        domain (str): The domain for which the RSA key file is needed.
                      Defaults to an empty string.
        extension (str): The extension of the RSA key file.
                         Defaults to 'pem'.

    Returns:
        str: The path of the RSA key file for the specified domain.
             Returns None if no RSA key file is found.
  """
  file_path = RSA_KEY_PATH
  if domain != '':
    file_path = RSA_KEY_PATH+'/'+domain+'/'
  files = os.listdir(file_path)
  files_with_extension = [file for file in files if file.endswith(extension)]
  if len(files_with_extension)==0:
    return None
  return file_path+files_with_extension[0]

def encrypt_rsa_deterministic(input):
  """
  Encrypts the input data using RSA encryption in a deterministic manner.

  Input:
      input (bytes): The input data to be encrypted.

  Returns:
      bytes: The encrypted data.
  """
  key_path = get_rsa_key_file()
  pseudonymize_private_key = obfuskator_rust.rsa.PrivateKey.load_from_file(key_path,"pkcs1","pem")
  public_key = pseudonymize_private_key.public_key
  if (not input):
    return input
  else:
    return public_key.encrypt_deterministic(input)
    
def decrypt_rsa_deterministic(input):
    """
    Decrypts the input data using RSA decryption in a deterministic manner.

    Input:
        input (bytes): The input data to be decrypted.

    Returns:
        bytes: The decrypted data.
    """
    try:
      key_path = get_rsa_key_file()
      pseudonymize_private_key = obfuskator_rust.rsa.PrivateKey.load_from_file(key_path, "pkcs1", "pem")
      privatekey = pseudonymize_private_key
      return privatekey.decrypt(input)
    except Exception as e:
      print("Error occurred during decryption:", e)
      return None

def create_encrypted_dataframe(df_source,pii_column_list):
  """
    Encrypts personally identifiable information (PII) columns in a DataFrame using RSA deterministic encryption.

    Input:
        df_source (DataFrame): Source DataFrame containing PII columns.
        pii_column_list (list): List of column names containing PII to be encrypted.

    Returns:
        DataFrame: New DataFrame with PII columns encrypted.

    """
  
  try:
      rsa_encrypt_deterministic = udf(encrypt_rsa_deterministic, StringType())
      for column_name in pii_column_list:
          df_source = df_source.withColumn(column_name, rsa_encrypt_deterministic(df_source[column_name]))
      return df_source
  except Exception as e:
      print("Error occurred during DataFrame encryption:", e)
      return None
  
def create_decrypted_dataframe(df_source,pii_column_list):
  """
    Decrypts personally identifiable information (PII) columns in a DataFrame using RSA deterministic decryption.

    Input:
        df_source (DataFrame): Source DataFrame containing encrypted PII columns.
        pii_column_list (list): List of column names containing encrypted PII to be decrypted.

    Returns:
        DataFrame: New DataFrame with encrypted PII columns decrypted.

    """
  
  try:
      rsa_decrypt_deterministic = udf(decrypt_rsa_deterministic, StringType())
      for column_name in pii_column_list:
          df_source = df_source.withColumn(column_name, rsa_decrypt_deterministic(df_source[column_name]))
      return df_source
  except Exception as e:
      print("Error occurred during DataFrame decryption:", e)
      return None

def get_pii_columns_list(table_name):
  """
    Retrieves a list of Personally Identifiable Information (PII) columns for a given table.

    Input:
        catlg_nam (str): The catalog name where the table resides.
        table_name (str): The name of the table.

    Returns:
        list: A list of PII column names for the specified table.
    """
  try:
    df_columns_tags = read_delta_table(COLUMN_TAGS_TABLE_NAME, catlg_nam)
    df_columns_tags = df_columns_tags.filter((col('table_name') == table_name) & (lower(col('tag_name')) == 'pii'))
    pii_columns_list = [row['column_name'] for row in df_columns_tags.collect()]
    if len(pii_columns_list)==0:
       raise framwork_cstom_error('Empty pii columns list')
    return pii_columns_list
  except Exception as e:
      print("Error occurred while retrieving PII columns list:", e)
      return []


#placeholder for the function
def gets_encrypt_file_columns_list():
  #method reads the encryption metadata table, check if the file needs to be encrypted if yes, then fetch the columns list
  #sample encrytion metadata table
  # parent_entry | child_entry | column_list      | additional_info
  # zip1         | file1       | col1,col2        | type : source overwrite
  # zip1         | file2       | col3,col4,col5   | type : source overwrite
  pass

def encrypt_file_data(filepath,file_type,columns_list):
  """
    Encrypts personally identifiable information (PII) columns in a file.

    Input:
        filepath (str): Path to the file to be encrypted.
        columns_list (list): List of column names containing PII to be encrypted.

    Returns:
        tuple: A tuple containing the following elements:
            - DataFrame or None: Encrypted DataFrame if successful, None if unsuccessful.
            - bool: True if encryption is successful, False otherwise.
            - str: Success message if successful, error message if unsuccessful.

    """
  try:
    df_file, df_create_status, read_error = df_read_file(file_type, filepath)
    if not df_create_status:
        return None, False, read_error
    df_encrypted = create_encrypted_dataframe(df_file, columns_list)
    if df_encrypted:
        return df_encrypted, True, 'Success'
    else:
        raise framwork_cstom_error('Unable to encrypt the data')
  except Exception as e:
    return None, False, f'Error occurred during file encryption: {str(e)}'

def check_encryption_flag(table_name):
  """
    Checks if a Target layer table contains Personally Identifiable Information (PII) data.

    Input:
        catlg_nam (str): The catalog name where the table resides.
        table_name (str): The name of the Bronze layer table.

    Returns:
        str: 'true' if the Bronze layer table contains PII data, 'false' otherwise.
  """
  try:
    df_lyr_mstr = read_delta_table(LAYER_TABLE_NAME, catlg_nam)
    df_lyr_mstr = df_lyr_mstr.filter(col('tgt_nam') == table_name).first()
    addnl_info = df_lyr_mstr['addnl_info']
    if 'encryption' not in addnl_info:
       raise framwork_cstom_error('Encryption flag not present')
    return addnl_info['encryption']
  except Exception as e:
    print(e)
    return 'false'

def move_temp_part_file(temp_file_path, filename):
  """
  Moves a temporary file from a temporary location to a final destination.
  Parameters:
  temp_file_path (str): The temporary path where the file is currently located.
  filename (str): The desired filename for the file at its final destination.
  Returns:
  tuple: A tuple containing a boolean indicating the success of the operation
  and the final path of the moved file.
  """
  from ADB.common.common_objects import get_dbutils
  dbutils = get_dbutils()
  try:
      # List files in the temporary directory
      files = dbutils.fs.ls(temp_file_path)

      # # Define the final path where the file will be moved
      final_path = temp_file_path.split('.')[0] + '.csv'
      print(final_path)

      # Get the path of the part file (assuming the file is partitioned)
      part_file = [file.path for file in files if file.name.startswith("part-")]

      # If part file is not found, raise an error
      if not part_file:
          raise FileNotFoundError("Part file not found in the temporary directory.")

      # Set the temporary full path to the found part file
      temp_full_path = part_file[0]
      print(temp_full_path)

      # Move the file to its final destination
      dbutils.fs.mv(temp_full_path, final_path)

        #remove orignal file

      # Remove the temporary directory
      dbutils.fs.rm(temp_file_path, recurse=True)

      # Return success status and the final path
      return True, final_path

  except Exception as e:
      # Handle any errors occurred during the process
      return False, str(e)
