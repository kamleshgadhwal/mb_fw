from pyspark.sql.functions import col, lit,max
from ADB.common.common_utilities import spark

 
def is_file_readable(file_path, header=True, num_lines_to_read=5 , file_type='csv'):
    """
    Checking for a file readability . 

    Input:
        - file_path: path of the file to be read.
        - header: file header availability
        - num_lines_to_read: no of lines to read from the file
        -file_type : type of the file to be read

    Returns:
        - True/False status based on readable status
    """
    try:
        if(file_type=='delimited'):
            if(spark.read.option("header", str(header)).csv(file_path).limit(num_lines_to_read).count()>0):
                return True,None
            else:
                return False,None
        elif(file_type=='json'):
             if(spark.read.option("multiLine",True).json(file_path).limit(num_lines_to_read).count()>0):
                return True, None
             else:
                return False, None      
        else:
            return False,None
    except Exception as e:
        print(f"Error reading file: {e}")
        return False, str(e)
              

# COMMAND ----------

def df_read_file(file_type, filepath, file_typ):
  
  """
   Reading the file and craete a Datafrme from it .

  Input:
      --file_type : type of the file to be read
      - file_path: path of the file to be read.
  Returns:
      - Dataframe - returns the dataframe after reading the file CSV/JSON
  """
  try:
    if file_type == 'delimited' and file_typ=='csv':
      df = spark.read.csv(filepath, header=True)
    elif file_type == 'delimited' and file_typ=='txt':
        df = spark.read.csv(filepath, sep='|',header=True)
    elif file_type == 'json':
      df = spark.read.option("multiLine",True).json(filepath)
      df=df.selectExpr(f"to_json({df.columns[0]}) as json_string")
    else:
        return None,False,"File Type is not in correct format , please use delimited or json file type"
    return df,True,None
  except Exception as e:
      return None,False,f"Error during read file df: {str(e)}"

# COMMAND ----------

def insert_data_to_delta_table(df, bronze_table_name,catlg_nam):
   
  """
  merge the dataframe into bronze delta table.

Input:
    --df : dataframe to insert into delta table
    - bronze_table_name: bronze table in which we need to insert the data.
Returns:
    - 
"""  
  try:
    df.write.format("delta").option("mergeSchema", "true").mode("append").saveAsTable(f'`{catlg_nam}`.'+bronze_table_name)
    return True,None
  except Exception as e:
    print(f"Error during write_to_delta_table: {str(e)}")
    return False, str(e)

# COMMAND ----------

def identify_pattern_from_filename(filename):
    """
    This function identifies the pattern of the file using the file name using RE.

    Input:
    - filename -> name of the file for which the pattern needs to be identified.
     Returns:
    - result pattern of the file using filename
    """
    import re
    # Define the pattern using a regular expression

    extn = filename.split('.')[-1]

    if extn == 'json' or extn == 'csv' or extn == 'txt':
      pattern = re.compile(r'([a-zA-Z_$]+)_(\d{8})\.\w+')
    elif extn == 'zip':
        pattern = re.compile(r'([a-zA-Z_$]+)_(\d{4})-(\d{2})-(\d{2})\.\w+')

    match = pattern.match(filename)

    if match and (extn == 'json' or extn == 'csv' or extn == 'txt'):
        # Extract matched groups
        prefix, _ = match.groups()

        # Construct the result pattern
        result_pattern = f"{prefix}_yyyyMMdd{'.' + filename.split('.')[-1] if '.' in filename else ''}"
        return result_pattern

    if match and extn == 'zip':
        # Extract matched groups
        prefix, _, _,_ = match.groups()

        # Construct the result pattern
        result_pattern = f"{prefix}_yyyy-MM-dd{'.' + filename.split('.')[-1] if '.' in filename else ''}"
        return result_pattern

    return None

# COMMAND ----------

def concatenate_columns_convert_to_list(df, separator):
    """
    Concatenate all columns in a PySpark DataFrame into a single column with a specific separator

    Input:
    - df: PySpark DataFrame
    - separator: Separator to use when concatenating the columns

    Returns:
    - New PySpark DataFrame with a single column containing concatenated values
    """
    try:
        from pyspark.sql.functions import concat_ws
        # Get the list of column names
        columns = df.columns

        # Concatenate all columns into a single column using concat_ws function
        concatenated_df = df.withColumn("Concatenated_Column", concat_ws(separator, *columns)).select("Concatenated_Column")
        concatenated_column_list = [i['Concatenated_Column'] for i in concatenated_df.select("Concatenated_Column").collect()]

        return concatenated_column_list, True , None
    except Exception as ex:
        None, False, f"error duing the concatanete the columns {str(ex)}"
