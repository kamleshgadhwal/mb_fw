from ADB.common.config import catlg_nam, wm_tabl_nam
from ADB.common.watermark_utils import watermark_operations
from datetime import datetime
import re
from pyspark.sql.functions import to_timestamp,col,lit



def compare_last_updated_ts_with_watermark(last_updated_ts_zip, zip_file_id, zip_file_name , catlg_nam, wm_tabl_nam):
    datetime_format = "%Y-%m-%d %H:%M:%S"
    
    try:
        last_updated_ts_zip = datetime.strptime(last_updated_ts_zip,"%Y-%m-%dT%H:%M:%S%z").strftime(datetime_format)
        run_date=datetime.strptime(re.search(r'\d{4}-\d{2}-\d{2}', zip_file_name).group(), "%Y-%m-%d").date() 

        wm_condition = {'id_proc': zip_file_id, 'oper_phase': 'zip_copy', 'opr_stat': '1','run_dte':run_date}

        df_wm_zip_copy = watermark_operations(catlg_nam, wm_tabl_nam, filter_condition=wm_condition, operation='read')

        compare_status = True
        if df_wm_zip_copy is not None and df_wm_zip_copy.select(col("addnl_info")["zip_last_updated_ts"]).collect()[0][0] is not None:
            success_zip_last_updated_ts = df_wm_zip_copy.select(col("addnl_info")["zip_last_updated_ts"]).collect()[0][0]
            if datetime.strptime(last_updated_ts_zip, datetime_format) > datetime.strptime(success_zip_last_updated_ts, datetime_format):
                compare_status = True
            else:
                compare_status = False
            print("Extracted value:", success_zip_last_updated_ts)

    except Exception as e:
        print("An error occurred:", str(e))
        

    return compare_status
