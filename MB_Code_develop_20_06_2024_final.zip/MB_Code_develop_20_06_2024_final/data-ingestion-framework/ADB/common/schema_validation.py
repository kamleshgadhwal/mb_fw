from pyspark.sql.functions import col, create_map, lit, when, array, to_date , to_timestamp, expr
from pyspark.sql.types import IntegerType, ArrayType, StringType, MapType, DecimalType, BooleanType, LongType, FloatType, ShortType, DoubleType
from pyspark.sql import DataFrame

# COMMAND ----------

def schema_validation_spark_dict(typecast_dict,timestamp_format,date_format)->dict:
  """
  This function creates a dictionary after applying type casting which are found in the infromation schema dict.

  Input:
    - typecast_dict: A dictionary which has columns information from information schema table and related to its silver table.
    - date_format: You can pass desired date format for date related type casting.
    - date_format: You can pass desired timestamp format for timestamp related type casting.

  Returns:
    - schema_withcol_dict: It returns a dictionary which has type casting instructions.
  """

  schema_withcol_dict={}
  for i,j in typecast_dict.items():
    if i == 'updated_timestamp':
      continue

    if j == 'INT':
      p = col(i).cast(IntegerType())
    elif j == 'TIMESTAMP':
      p = to_timestamp(col(i), format=timestamp_format)
    elif j == 'DATE':
      p = to_date(col(i), format=date_format)
    elif j == 'DECIMAL':
      p = col(i).cast(DecimalType())
    elif j == 'BOOLEAN':
      p = col(i).cast(BooleanType())
    elif j == 'LONG':
      p = col(i).cast(LongType())
    elif j == 'FLOAT':
      p = col(i).cast(FloatType())
    elif j == 'DOUBLE':
      p = col(i).cast(DoubleType())
    elif j == 'CHAR':
      p = col(i).cast(StringType())
    elif j == 'VARCHAR':
      p = col(i).cast(StringType())
    else:
      p = col(i).cast(j)

    a = create_map(lit('type_check_value'),when(p.isNotNull(),1).otherwise(when(p.isNull() & col(i).isNull(),1).otherwise(0)))
    b = create_map(lit(i),when(p.isNull(),col(i).cast(StringType())))
    schema_withcol_dict['is_'+i] = array(a,b)
  
  return schema_withcol_dict

# COMMAND ----------

def check_schema_validation(df:DataFrame,typecast_dict:dict,timestamp_format,date_format):
  """
  This function validates bronze table schema are compatible to its silver table schema or not. Also, bifircate bronze table records into good or bad records.  

  Input:
    - df: Bronze table dataframe.
    - typecast_dict: A dictionary which has columns information from information schema table and related to its silver table.

  Returns:
    - df_good_records_schema: It returns a compatible dataframe for silver layer ingestion.
    - df_bad_records_schema: It returns a non-compatible dataframe.
    - error: It returns error details if any.
  """
  error = None
  try:
    schema_validation_dict = schema_validation_spark_dict(typecast_dict,timestamp_format,date_format)
    schema_validation_list = list(schema_validation_dict.keys())
    expression = "+".join([i+'[0]'+str(['type_check_value']) for i in schema_validation_list])
    df_schema_validation = df.withColumns(schema_validation_dict).withColumn('num_good_records',expr(expression))
    all_quality_tmp_cols = array([when(col(x)[1][x[3:]].isNotNull()==True,col(x)[1]) for x in schema_validation_list])

    df_bad_records_schema = df_schema_validation.filter(col('num_good_records')<len(schema_validation_dict.keys()))\
      .withColumn('all_reason_records',all_quality_tmp_cols)\
        .withColumn('corrupt_records', expr('filter(all_reason_records, x -> x is not null)'))\
          .drop(*list(schema_validation_dict.keys()))\
            .drop(*[col('num_good_records'),col('all_reason_records')])\
              .withColumn('drop_reason_category',lit('Schema Validation'))

    df_good_records_schema = df_schema_validation.filter(col('num_good_records')==len(schema_validation_dict.keys()))\
      .drop(*list(schema_validation_dict.keys()))\
        .drop(*[col('num_good_records')])
    
    return df_good_records_schema,df_bad_records_schema,error

  except Exception as e:
    error = 'Error while schema validation : ' + str(e)
    print(error)
    return None,None,error


  
