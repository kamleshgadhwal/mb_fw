import json
from pyspark.sql.functions import col,lit, max, array
from pyspark.sql.functions import expr
from pyspark.sql import DataFrame
from pyspark.sql.types import StructField, StructType
from datetime import datetime
from ADB.common.common_utilities import spark, read_delta_table

def insert_error_into_watermark(catlg_nam:str,watermark_table:str, watermark_dict:dict,error_code,error_message:str):
  """
  Merge a error dictionary into watermark table using Watermark object.

  Input:
  - catlg_nam: Unity catelog name.
  - watermark_table: Watermark table name.
  - watermark_dict: A dictionary you want to insert into watermark table.
  - error_code: Enter a error code.
  - error_message: Enter a error message.

  Returns:
    - df: It returns a dataframe after adding the n numbers of targted column.
    - error: It 
  """
  
  watermark_dict['oper_stat'] = error_code
  watermark_dict['err_dtls'] = error_message

  o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=watermark_table)
  watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()
  return watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert

def merge_dataframe_into_watermark(input_dataframe:DataFrame, wm_tabl_nam:str):
  """
  Merge a watermark dataFrame into a Watermark table.

  Input:
      - input_dataframe: Watermark DataFrame to be merged into the Watermark delta table.
      - wm_tabl_nam: Watermark table name.

  Returns:
      - error_detail: It returns error details if any.
      - merge_status: A boolean which indicates a record has been mergred or not into watermark table.
  """
  from delta.tables import DeltaTable
  from pyspark.sql import SparkSession, functions as f

  error_detail = None

  try:      
    join_columns = ['id_batch','id_proc','proc_started_ts']
    join_filter_columns = ['id_batch','id_proc']
    join_filter_columns = input_dataframe.select(join_filter_columns).first().asDict()

    join_condition_1 = " AND ".join([f"src.{col} = tgt.{col}" for col in join_columns])
    join_condition_2 = " AND ".join([f"tgt.{col} = '{join_filter_columns.get(col)}'" for col in join_filter_columns])
    join_condition = join_condition_1 + ' AND ' + join_condition_2

    src_df = input_dataframe
    tgt_delta_tab = DeltaTable.forName(spark, wm_tabl_nam)

    tgt_delta_tab.alias("tgt").merge(
        src_df.alias("src"),
        join_condition
    ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    return error_detail,True

  except Exception as e:
    error_detail = f"Error during merge: {str(e)}"
    return error_detail,False

def watermark_upsert(catlg_nam:str, target_table_name:str, df_input:DataFrame):
  """
  This function update and insert records into watermark table.

  Input:
    - catlg_nam: catlg_nam
    - target_table_name: Watermark table name.
    - df_input: A dataframe which needs to upsert data into watermark table.

    eg) catlg_nam = 'extollo_catelog'
        target_table_name = 'schema_name.wm_tabl_nam'
        df_input =  +------------------------+----------+-------------------------+
                    |id_batch                |id_proc   |proc_started_ts          |
                    +------------------------+----------+-------------------------+
                    |2023-12-26-financial.zip|orders.csv|2024-01-11 10:53:44.84064|
                    +------------------------+----------+-------------------------+

  Returns:
    - watermark_insert_status: A boolean which indicates a record has been upserted or not into watermark table.
    - watermark_insert_error: It returns error details if any.
  """
  watermark_insert_status = False
  try:
    target_table_name = catlg_nam + '.' + target_table_name
    watermark_insert_error,watermark_insert_status = merge_dataframe_into_watermark(df_input, wm_tabl_nam = target_table_name)
    return watermark_insert_error, watermark_insert_status
  except Exception as e:
    print('Error upserting data into table : ', str(e))
    watermark_insert_error = 'Error upserting data into table : ', str(e)
    return watermark_insert_error, watermark_insert_status

def create_watermark_df(catlg_nam:str, wm_tabl_nam:str,watermark_data_dict:dict)->DataFrame:
  """
  This function creates a watermark dataframe using a dictionary.

  Input:
    - catlg_nam: catlg_nam
    - wm_tabl_nam: Watermark table name.
    - watermark_data_dict: This is a dictionary which has watermark records in the form of <key,value>=<column,records>.

    eg: catlg_nam = 'extollo_catelog'
        wm_tabl_nam = 'schema_name.wm_tabl_nam'
        watermark_data_dict = {'id_batch':'abc.zip','id_proc':'xyz.csv'}

  Returns:
    - It returns a dataframe using dictionary.
  """
  df_watermark = read_delta_table(wm_tabl_nam,catlg_nam)
  real_table_schema = df_watermark.schema
  real_schema_dtypes= {i.name:i.dataType for i in real_table_schema}
  real_schema_nullable= {i.name:i.nullable for i in real_table_schema}
  filter_schema = [StructField(i,real_schema_dtypes[i],real_schema_nullable[i]) for i in watermark_data_dict.keys() if i in real_schema_dtypes.keys()]
  missing_columns = [i for i in real_table_schema if i.name not in watermark_data_dict.keys()]
  missing_values = [None for _ in missing_columns]
  watermark_data = [tuple(list(watermark_data_dict.values()) + missing_values)]  
  watermark_schema = filter_schema + missing_columns
  df = spark.createDataFrame(watermark_data,StructType(watermark_schema))
  
  return df

def watermark_read(catlg_nam:str, wm_tabl_nam:str,filter_condition:dict={})->DataFrame:
  """
  This function which reads a dataframe using filter condition dictionary.

  Input:
    - catlg_nam: catlg_nam
    - wm_tabl_nam: Watermark table name.
    - filter_condition: This is a dictionary which has filter columns and its value in the form of <key,value>=<column,records>.

    eg: catlg_nam = 'extollo_catelog'
        wm_tabl_nam = 'schema_name.wm_tabl_nam'
        filter_condition = {'id_proc': 'orders.csv', 'id_batch': '2023-12-26-financial.zip', 'oper_phase': 'LANDING_TO_BRONZE'}

  Returns:
      - It returns a dataframe after applying the filter using dictionary.
  """
  filter_condition_keys = filter_condition.keys()
  
  if len(filter_condition_keys) == 0:
    return read_delta_table(wm_tabl_nam,catlg_nam)
  
  if len(filter_condition_keys) > 0:
    df = read_delta_table(wm_tabl_nam,catlg_nam)
    for i in filter_condition.items():
      df = df.filter(df[i[0]] == i[1])
    return df

def watermark_operations(catlg_nam:str,
                        wm_tabl_nam:str,
                        df_watermark_input:DataFrame=spark.createDataFrame([()]),
                        operation:str='upsert',
                        filter_condition:dict={}
                         ):
  """
  This function upsert records into watermark table or reads watermark table using some filter condition.

  Input:
    - catlg_nam: catlg_nam
    - wm_tabl_nam: Watermark table name.
    - df_watermark_input: A dataframe which needs to upsert data into watermark table.
    - operation: Type of operation you wan to perform. 
    - filter_condition: This is a dictionary which has filter columns and its value in the form of <key,value>=<column,records>.

    eg) catlg_nam = 'extollo_catelog'
        wm_tabl_nam = 'schema_name.wm_tabl_nam'
        df_watermark_input =  +------------------------+----------+-------------------------+
                              |id_batch                |id_proc   |proc_started_ts          |
                              +------------------------+----------+-------------------------+
                              |2023-12-26-financial.zip|orders.csv|2024-01-11 10:53:44.84064|
                              +------------------------+----------+-------------------------+
        operation = 'read'
        filter_condition = {'id_proc': 'orders.csv', 'id_batch': '2023-12-26-financial.zip', 'oper_phase': 'LANDING_TO_BRONZE'} 

  Returns:
    - A boolean which indicates a record has been upserted or not into watermark table.
  """

  if operation == 'upsert':
    return watermark_upsert(catlg_nam, wm_tabl_nam, df_watermark_input)

  if operation == 'read':
    return watermark_read(catlg_nam, wm_tabl_nam,filter_condition)

class Watermark():
  def __init__(self, watermark_dict:dict,catlg_nam:str,watermark_table:str):
    self.catlg_nam = catlg_nam
    self.watermark_dict = watermark_dict
    self.watermark_table = watermark_table
  
  def get_watermark_init_dict(self):
    """
    This function maps the local watermark dict to required watermark dictionary.

    Input:
      - watermark_dict: It uses watermark dictionary class attribute which has watermark related informations. 

    Returns:
      - It returns a dictionary after mappping. 
    """

    watermark_insert_dict = {}
    watermark_insert_dict['id_batch'] = self.watermark_dict.get('id_batch')
    watermark_insert_dict['id_proc'] = self.watermark_dict.get('id_src_file')
    watermark_insert_dict['run_dte'] = self.watermark_dict.get('run_date')
    watermark_insert_dict['oper_phase'] = self.watermark_dict.get('oper_phase')
    watermark_insert_dict['opr_stat'] = self.watermark_dict.get('oper_stat')
    watermark_insert_dict['proc_started_ts'] = self.watermark_dict.get('proc_started_ts')
    watermark_insert_dict['last_updated_ts'] = self.watermark_dict.get('proc_started_ts')
    watermark_insert_dict['id_dw_crea_user'] = self.watermark_dict.get('user_name')
    watermark_insert_dict['id_dw_updt_user'] = self.watermark_dict.get('user_name')
    watermark_insert_dict['inp_nam'] = self.watermark_dict.get('inp_nam')
    watermark_insert_dict['inp_typ'] = self.watermark_dict.get('inp_typ')
    watermark_insert_dict['tgt_nam'] = self.watermark_dict.get('tgt_nam')
    watermark_insert_dict['in_cnt'] = self.watermark_dict.get('in_cnt')
    watermark_insert_dict['out_cnt'] = self.watermark_dict.get('out_cnt')
    watermark_insert_dict['ins_cnt'] = self.watermark_dict.get('ins_cnt')
    watermark_insert_dict['addnl_info'] = self.watermark_dict.get('addnl_info')
    watermark_insert_dict['upd_cnt'] = self.watermark_dict.get('upd_cnt')
    watermark_insert_dict['err_dtls'] = self.watermark_dict.get('err_dtls')

    if self.watermark_dict.get('oper_stat') != 5:
      watermark_insert_dict['last_updated_ts'] = datetime.now()

    return watermark_insert_dict


  def watermark_init_upsert(self):
    """
    This function merge the records into watermark table using a users watermark dictionary.

    Input:
      - watermark_dict: It uses watermark dictionary class attribute which has watermark related informations. 

    Returns:
      - watermark_insert_flag: It returns a boolean status if data is inserted successfully or not.
      - watermark_insert_error:  It returns an error details if any.
      - df_watermark_read: It returns a watermark records after insertion.
      - df_watermark_insert: It returns a dataframe for all inserted records 
    """

    self.watermark_insert_dict = self.get_watermark_init_dict()
    df_watermark_insert = create_watermark_df(self.catlg_nam, self.watermark_table, self.watermark_insert_dict)
    watermark_insert_error, watermark_insert_flag = watermark_operations(self.catlg_nam, self.watermark_table, df_watermark_insert,operation='upsert')
    condition = {'id_proc': self.watermark_dict.get('id_src_file'),'id_batch': self.watermark_dict.get('id_batch'),'proc_started_ts':self.watermark_dict.get('proc_started_ts')}
    df_watermark_read = watermark_operations(self.catlg_nam, self.watermark_table, filter_condition=condition, operation='read')
    return watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert

