from pyspark.sql import DataFrame
from pyspark.sql.functions import expr, col, when, sum, split, concat_ws
import json

def split_name(df:DataFrame, trgt_col_to_enrich:str,fn_parameters:str):
  """
  This function splits the string column using a separator.

  Input:
    - input_dataframe: PySpark DataFrame where you need to perform this function.
    - trgt_col_to_enrich: Column name you will get the output in the dataframe.
    - fn_parameters: JSON String paramater which has atleast three arguments 
          -> cols: On which column you will perform this function.
          -> delimiter: How you want to split the string.
          -> position: After splitting the string, which position of string you want.  

  Returns:
    - df: It returns a dataframe after adding a target column.
    - error: It returns error details if any.
  """
  error = None 
 
  kwargs_dict = json.loads(fn_parameters)
  col_name = kwargs_dict.get('cols')
  delimiter =  kwargs_dict.get('delimiter')
  position =  int(kwargs_dict.get('position'))

  df = df.withColumn(trgt_col_to_enrich,split(col_name,delimiter).getItem(position))
  return df,error

def concat_strings(df:DataFrame, trgt_col_to_enrich:str,fn_parameters:str):
  """
  Concatenates multiple input string columns together into a single string column, using the default separator.

  Input:
    - input_dataframe: PySpark DataFrame where you need to perform this function.
    - trgt_col_to_enrich: Column name you will get the output in the dataframe.
    - fn_parameters: String paramater which has input columns with a comma seperator.

  Returns:
    - df: It returns a dataframe after adding a target column.
    - error: It returns error details if any.
  """
  error = None

  seperator=' '
  fn_parameters = fn_parameters.split(',')
  df = df.withColumn(trgt_col_to_enrich,concat_ws(seperator,*fn_parameters))
  return df,error

def product_of_columns(df:DataFrame, trgt_col_to_enrich:str,fn_parameters:str):
  """
  Muplication of numeric columns and gives us product of numbers.

  Input:
    - input_dataframe: PySpark DataFrame where you need to perform this function.
    - trgt_col_to_enrich: Column name you will get the output in the dataframe.
    - fn_parameters: String paramater which has input columns with a comma seperator.

  Returns:
    - df: It returns a dataframe after adding a target column.
    - error: It returns error details if any.
  """
  error = None
  typecast_check = 'float'

  fn_parameters = fn_parameters.split(',')
  tc_status,tc_error = check_col_typecasting(df, fn_parameters, typecast_check)
  if tc_status==False:
    return None,tc_error

  expression = "*".join([i for i in fn_parameters])
  df = df.withColumn(trgt_col_to_enrich,expr(expression))
  return df,error

def check_col_typecasting(df:DataFrame,columns_list:list, typecast_check:str):

  """
  This function checks whether your column from columns_list is convertable to a targeted column data type.

  Input:
    - input_dataframe: PySpark DataFrame where you need to perform this function.
    - columns_list: List of columns on which we are planning to perform this function.
    - typecast_check: Desired data type. 

  Returns:
    - Status: Gives us boolean, when all the columns pass or fail.
    - error: It returns error details if any.
  """
  error = None

  for i in columns_list:
    df_not_null = df.filter(col(i).isNotNull())
    df_conversion_count = df_not_null.select(sum(when(col(i).cast(typecast_check).isNotNull(),1).otherwise(0)).alias('conversion_count'))
    conversion_count = df_conversion_count.select('conversion_count').first().asDict().get('conversion_count')

    if conversion_count == 0:
      error = f'column {i} is not convertable to {typecast_check}'
      return False,error
  
  return True,error