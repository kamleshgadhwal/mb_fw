def get_job(dbutils):
    '''Returns the JobId of a notebook. Since this element does not exist if the notebook is run from the interactive workspace, returns -1 if not found'''
    try:
        job = int(dbutils.notebook.entry_point.getDbutils().notebook().getContext().jobId().get())
    except Exception:
        job = -1
 
    return job

def get_audit_user(dbutils):
    '''If run in an interactive workspace, returns the User ID of the run. If run through Data Factory, returns "AZUREDF"'''
    job = get_job(dbutils)
 
    if job > 0:
        audit_user = 'AZUREDF'
    else:
        user_email = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
        audit_user = user_email.split('@')[0].upper()
 
    return audit_user