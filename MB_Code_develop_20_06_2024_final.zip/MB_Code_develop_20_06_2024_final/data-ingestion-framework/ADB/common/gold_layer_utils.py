import requests
from pyspark.sql.functions import col, max, lit
from pyspark.sql import DataFrame
from ADB.common.common_objects import get_spark
from ADB.common.common_utilities import spark, read_delta_table
from pyspark.sql.types import TimestampType, StructType, StructField, DateType, StringType, BooleanType

def run_notebook(notebook_list,dbutils):
    """
    This function submits notebooks to a Databricks cluster for execution.
    Parameters:
        - notebook_list (list): List of dictionaries containing notebook information,
          each dictionary having keys 'notebook_path' and 'parameters'.
    Returns:
        None
    """
    # get necessary info of cluster
    DATABRICKS_TOKEN, cluster_id,api_endpoint = get_cluster_info(dbutils)

    # Request headers
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json",
    }

    for data in notebook_list:
        # Request payload
        payload = {
            "run_name": "Notebook Run - " + data['notebook_path'].split('/')[-1],
            "existing_cluster_id": cluster_id,
            "notebook_task": {
                "notebook_path": data['notebook_path']
            },
        }
        # Submit the run
        response = requests.post(api_endpoint, headers=headers, json=payload)

        # Check the response
        if response.ok:
            run_id = response.json().get("run_id")
            print(f"Notebook run submitted successfully. Run ID: {run_id}")
        else:
            print(f"Error submitting notebook run. Status code: {response.status_code}, Response: {response.text}")

def get_cluster_info(dbutils):
    """
    This function returns the cluster information.
    Returns:
        - dict: returns cluster information
    """
    spark=get_spark()
    WORKSPACE_URL = spark.conf.get("spark.databricks.workspaceUrl")
    DATABRICKS_WORKSPACE_URL=f"https://{WORKSPACE_URL}"
    DATABRICKS_TOKEN = dbutils.secrets.get('daps-kv','pid7bb5-adb-token')
    cluster_id = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
    api_endpoint = f"{DATABRICKS_WORKSPACE_URL}/api/2.1/jobs/runs/submit"
    return DATABRICKS_TOKEN, cluster_id,api_endpoint

def execute_gold_layer(t_d_metadata,src_name,dbutils):
    """
    This function executes the gold layer processing for a given source table.
    Parameters:
        - t_d_metadata (DataFrame): Layer master dataframe
        - lyr_mstr_df (DataFrame): Layer master dataframe
        - src_name (str): Name of the source table
    Returns:
        None
    """
    try:
        # finding direct successor list
        t_d_metadata_filtered_tgt = t_d_metadata.filter(t_d_metadata.src_nam == src_name)
        df_prcs_nbk_path = t_d_metadata_filtered_tgt.select(col("addnl_info")["prcs_nbk"].alias('prcs_nbk_path'))
        if df_prcs_nbk_path.count() > 0:
            notebook_list = [
                {
                    "notebook_path": row["prcs_nbk_path"]
                }
                for row in df_prcs_nbk_path.collect()
            ]
            run_notebook(notebook_list,dbutils)
        else:
            print("no successor")
    except Exception as e:
        print(f"Error in execute_gold_layer: {str(e)}")

def resolve_dependency_watermark(successor_name:str, t_d_metadata:DataFrame, watermark_df:DataFrame)->tuple:
    """
    This function checks whether the given dependency list of tables are completed and the successor table is not yet loaded.
    Parameters:
        - successor_name (str): Name of the successor (target) table
        - t_d_metadata (DataFrame): Dependency table dataframe.
        - watermark_df (DataFrame): Watermark table dataframe.
    Returns:
        - tuple: 
            - final_dependency_flag : A boolean status whether a given target table is ready to be processed further or not.
            - final_df : A Dataframe which have all details about dependencies of successor.
            - list : List of all dependency tables for a gold layer table(successor). 
    """

    try:
      dependency_list = (t_d_metadata.filter(col("tgt_tbl_nam")==successor_name)\
          .select("src_nam").distinct().collect())
      dependency_list = [row["src_nam"] for row in dependency_list]
      suc_max_updated_ts = None
      suc_max_updated_df = watermark_df.filter((col('tgt_nam')==successor_name) & (col('opr_stat')=='1'))
      if suc_max_updated_df.count() != 0:
        suc_max_updated_ts = suc_max_updated_df.groupBy("tgt_nam", "opr_stat").agg(max("proc_started_ts").alias('max_started_ts')).first()['max_started_ts']

      schema = StructType([
            StructField('id_batch', StringType(), True), 
            StructField('tgt_nam', StringType(), True),
            StructField('opr_stat', StringType(), True),
            StructField('run_dte', DateType(), True), 
            StructField('proc_started_ts', TimestampType(), True),
            StructField('dependency_flag', BooleanType(), True)
          ]
        )

      final_df = spark.createDataFrame([],schema=schema)

      final_dependency_flag = True

      for dep in dependency_list:
        dependency_flag = True

        filter_df = watermark_df.filter(col('tgt_nam') == dep).groupBy("tgt_nam", "opr_stat").agg(max("proc_started_ts").alias('max_started_ts'))

        if filter_df.count() == 0:
          dependency_flag = False
          final_dependency_flag = False
          data = [(None,dep,None,None,None,dependency_flag)]
          curr_final_df = spark.createDataFrame(data,schema=schema)
          final_df = final_df.union(curr_final_df)
          continue

        opr_status = filter_df.first()['opr_stat']
        dep_max_updated_ts = filter_df.first()['max_started_ts']

        if opr_status == '1' and suc_max_updated_ts is not None and suc_max_updated_ts < dep_max_updated_ts:
          print ("dependency flag ::",dependency_flag)
        elif opr_status == '1' and suc_max_updated_ts is None:
          print ("dependency flag ::",dependency_flag)
        else:
          dependency_flag = False
          final_dependency_flag = False

        filter_dict = filter_df.first().asDict()
        curr_final_df = watermark_df.filter(
          (col('tgt_nam') == filter_dict['tgt_nam']) & (col('opr_stat') == filter_dict['opr_stat'])  & (col('proc_started_ts') == lit(filter_dict['max_started_ts']).cast(TimestampType()))
        )
        curr_final_df = curr_final_df.select('id_batch','tgt_nam','opr_stat','run_dte','proc_started_ts')
        curr_final_df = curr_final_df.withColumn('dependency_flag',lit(dependency_flag))

        final_df = final_df.union(curr_final_df)
      
      return final_dependency_flag, final_df, dependency_list

    except Exception as e:
      print(f"Error in resolve_dependency_watermark: {str(e)}")
      final_dependency_flag = False
      return final_dependency_flag, final_df, dependency_list

def get_gold_watermark_init_dict(dependency_status:bool,dependency_df:DataFrame,dependency_list:list,gold_table_name:str, user_name:str)->dict:
  """
  This function gives us watermark dictionary after getting resolving dependecies informations.
  Parameters:
      - dependency_status: A boolean status whether a given target table is ready to be processed further or not.
      - dependency_df: A Dataframe which have all details about dependencies of successor.
      - dependency_list: List of all dependency tables for a gold layer table(successor). 
      - gold_table_name: Name of the successor (target) table.
      - user_name: Current user name who runs the notebook.
  Returns:
      - It returns a dict which has all required information for watermark entry: 
  """
  from ADB.common.config import OPER_PHASE_SILVER_TO_GOLD,OPER_STAT_DICT
  from datetime import datetime

  dependency_count = dependency_df.filter(col('dependency_flag')).count()
  dependency_list_str = ','.join(dependency_list)
  watermark_dict = {}
  proc_started_ts = datetime.now()

  if dependency_count > 0:
    watermark_src_dict = dependency_df.filter(col('dependency_flag')).orderBy(col('proc_started_ts').desc()).first().asDict()
    watermark_dict['id_batch'] = watermark_src_dict['id_batch']
  else:
    watermark_dict['id_batch'] = None

  if dependency_status:
    watermark_dict['oper_stat'] = OPER_STAT_DICT.get('init')
  else:
    watermark_dict['oper_stat'] = OPER_STAT_DICT.get('conditional_skip')
    watermark_dict['err_dtls'] = 'Gold Layer Dependency not satisfied'
    if dependency_count == 0:
      watermark_dict['addnl_info'] = {
        'msg':'All the dependencies not satisfied',
        'Not satisfied dependency tables' :  dependency_list_str
      }
    else:
      par_dependency_list_str = [ row['tgt_nam'] for row in dependency_df.filter(col('dependency_flag') == False).select('tgt_nam').collect()]
      par_dependency_list_str = ','.join(par_dependency_list_str)
      watermark_dict['addnl_info'] = {
        'msg':'Dependency partically satisfied',
        'Not satisfied dependency tables' : par_dependency_list_str
      }
    
  watermark_dict['run_date'] = proc_started_ts.date()
  watermark_dict['proc_started_ts'] = proc_started_ts
  watermark_dict['tgt_nam'] = gold_table_name
  watermark_dict['id_src_file'] = gold_table_name
  watermark_dict['oper_phase'] = OPER_PHASE_SILVER_TO_GOLD
  watermark_dict['inp_typ'] = "delta"
  watermark_dict['inp_nam'] = dependency_list_str
  watermark_dict['user_name'] = user_name

  return watermark_dict

def final_gold_lyr_watermark_dict(gold_lyr_tbl:str, user_name:str, dependency_tbl:str,watermark_tbl:str):
    """
    This function gives us watermark dictionary using resolving dependecies informations and metadata tables.
    Parameters:
        - gold_lyr_tbl: Name of the successor (target) table.
        - user_name: Current user name who runs the notebook.
        - dependency_tbl - Dependency delta metadata tablename.
        - watermark_tbl - Watermark delta tablename.
    Returns:
        - It returns a dict which has all required information for watermark entry: 
    """

    from ADB.common.config import catlg_nam
    catalog_name = catlg_nam
    t_d_metadata = read_delta_table(dependency_tbl,catalog_name)
    watermark_df = read_delta_table(watermark_tbl,catalog_name)
    dependency_status,dependency_df,dependency_list = resolve_dependency_watermark(gold_lyr_tbl,t_d_metadata,watermark_df)
    watermark_dict = get_gold_watermark_init_dict(dependency_status,dependency_df,dependency_list,gold_lyr_tbl,user_name)

    return watermark_dict