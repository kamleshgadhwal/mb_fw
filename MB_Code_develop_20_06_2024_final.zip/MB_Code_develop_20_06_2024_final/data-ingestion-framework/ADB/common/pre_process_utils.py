
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType, IntegerType, DateType, MapType
from pyspark.sql.functions import concat_ws, explode , col
import zipfile
import io
from ADB.common.common_utilities import spark,DataFrame
from ADB.common.watermark_utils import watermark_operations

# COMMAND ----------

def get_latest_wm_zip_details(catlg_nam:str, watermark_table:str, df_metadata: DataFrame,watermark_dict: dict) -> DataFrame:
    """
    This function gets the latest zip details from watermark log .

    Input:
    - catlg_nam -> catlg_nam
    - watermark_table -> watermark_table
    -df_metadata -> dataframe of meta data of zip file.
    -watermark_dict -> watermark_dict

     Returns:
    - data frame with zip files to be unzip  
    """
    try:
        condition = {
            "id_proc": watermark_dict.get("id_src_file"),
            # "id_batch": watermark_dict.get("id_batch"),
            "oper_phase": watermark_dict.get("oper_phase"),
            "opr_stat": 1,
            "run_dte": watermark_dict.get("run_date"),
        }
        df_w = watermark_operations(
            catlg_nam, watermark_table, filter_condition=condition, operation="read"
        )
        df_w_last_row = df_w.orderBy(col("last_updated_ts").desc()).limit(1)

        if df_w_last_row.isEmpty():
            df_to_be_unzip = df_metadata
        else:
            df_w_last_row_map = explode_map_column(df_w_last_row, "addnl_info")
            df_w_last_row_map_mc = df_w_last_row_map.select(
                "file_name", "concatenated_meta_columns"
            )
            df_to_be_unzip = df_metadata.exceptAll(df_w_last_row_map_mc)
        return df_to_be_unzip,True ,None
    except Exception as ex:
        return None,False,f"error while getting the unzip files list{str(ex)}"

def extract_specific_file(lm_filter_row:dict,filename:str, df_to_be_unzip:DataFrame ) :
    """
    This function extracts the specific file to be unzip .

    Input:
    - lm_filter_row -> layer master filetered row
    - filename -> zip file name to unzip
    -df_to_be_unzip -> data farme to be unzip.

     Returns:
    - no of files extracted, files unzipped , list of extracted files  
    """
    try:
        staging_landing_path = lm_filter_row.get('src_loc')
        target_landing_path = lm_filter_row.get('tgt_nam')
        zip_file_path = staging_landing_path + filename
        extract_path = target_landing_path

        i=0
        files_unzipped = None
        list_extracted_file=[]
        for row in df_to_be_unzip.collect():
            #need to make a iteratore for success files and need to send with runoutput
            # print("row: ",row, "    file_name:", row.file_name, "    concatenated_meta_columns:", row.concatenated_meta_columns)
            dict_file_extracted={'filename':row.file_name,'filepath':extract_path}
            list_extracted_file.append(dict_file_extracted)
            _=extract_specific_file_from_zip(zip_file_path, row.file_name, extract_path)
            if i == 0:
                files_unzipped = row.file_name
            else:
                files_unzipped = files_unzipped + ',' + row.file_name
            i+=1
            
        total_file_extracted = i  

        return total_file_extracted, files_unzipped, list_extracted_file,True, None
    except Exception as ex:
        None,None,None,False,f"Error duning the extracting the specific files{str(ex)}"

# function to modify the string values based on configured dict

def string_value_modifier(input_string, key_val_dict):
    """
    This function modify the string value based on key_val dictionary .

    Input:
    - input_string -> input_string to modify
    - key_val_dict -> key - val dict

     Returns:
    - string after modify
    """
    for key, value in key_val_dict.items():
        input_string = input_string.replace(key, value)
    return input_string

def get_zip_file_metadata(zip_file_path):
    """
    read a zip file and create a dataframe from zip file metadata

    Input:
        - zip file path
    Return:
        - concatenated_metadata_df
    """
    try:
        from datetime import datetime
        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            file_list = zip_ref.infolist()
            metadata_list = []

            for file_info in file_list:
                file_name = file_info.filename
                modification_time = datetime(*file_info.date_time)
                file_size = file_info.file_size

                metadata_list.append((file_name,modification_time,file_size))
        
        
        meta_schema = StructType([
        StructField("file_name", StringType(), True),
        StructField("modification_time", TimestampType(), True),
        StructField("file_size", LongType(), True)
        ])
        
        metadata_df = spark.createDataFrame(metadata_list,meta_schema)
        cancat_cols = ["modification_time","file_size"]
        separator = ','
        concatenated_metadata_df = metadata_df.withColumn("concatenated_meta_columns", concat_ws(separator, *cancat_cols)).select("file_name","concatenated_meta_columns")
        zip_dict = {row["file_name"]:row["concatenated_meta_columns"] for row in concatenated_metadata_df.collect()}
        return concatenated_metadata_df,zip_dict , True , None
    except Exception as ex:
        None,None,False,f"error during get Zip file metadata{str(ex)}"

def explode_map_column(df, map_column_name):
    """
    Explode a DataFrame column of type MapType into separate columns for keys and values.

    Input:
    - df: PySpark DataFrame
    - map_column_name: Name of the column containing MapType values

    Returns:
    - New PySpark DataFrame with separate columns for map keys and values
    """
    # Use explode to create separate rows for each key-value pair
    exploded_df = df.select(map_column_name, explode(map_column_name).alias("file_name","concatenated_meta_columns"))
    #display(exploded_df)
    
    return exploded_df

def extract_specific_file_from_zip(zip_file_path, extract_file_name, extract_path):    
    """
    Extract a file from ZIP and place it into a path

    Input:
        - zip_file_path: complete file path of zip file
        - extract_file_name: file to be extracted from zip
        - extract_path: path where file to be extracted

    Returns:
        - status: A string indicating the extract status       
    """
    try:
        # Read the ZIP file as a binary file
        zip_file_content = spark.read.format("binaryFile").load(zip_file_path).first()[3]

        # Use zipfile module to extract the specific file
        with zipfile.ZipFile(io.BytesIO(zip_file_content), 'r') as zip_ref:
            # Extract the specific file to the desired location
            zip_ref.extract(extract_file_name, extract_path)
        
        #need to populate on Success
        status=(f"Successfully extracted {extract_file_name} to {extract_path} from {zip_file_path}")

    except Exception as e:
        status=(f"Error extracting {extract_file_name} to {extract_path} from {zip_file_path}: {str(e)}")
        
    return status