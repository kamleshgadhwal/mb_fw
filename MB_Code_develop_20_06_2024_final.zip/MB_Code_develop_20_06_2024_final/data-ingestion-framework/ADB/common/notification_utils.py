from pyspark.sql.functions import col,current_date
from ADB.common.common_utilities import spark,DataFrame,read_delta_table
from ADB.common.config import catlg_nam,NOTIFICATION_DETAILS_TABLE_NAME,NOTIFICATION_TEMPLATE_TABLE_NAME,SENDER_EMAIL,EMAIL_FROM,wm_tabl_nam,RETRY_COUNT,PIPELINE_ZIP_TYP,PIPELINE_API_TYP,PIPELINE_FAILURE_TYP,MISSING_FILE_TYP,API_FAILURE_TYP,DATA_QUALITY_TYP,SCHEMA_EVOLUTION_TYP,INPUT_DOMAIN
from ADB.common.common_objects import get_dbutils
from ADB.common.metadata_operations import get_extra_missing_cols_between_landing_and_bronze,framwork_cstom_error
import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
import os

no_mail_sent_value="No email information to sent mail !"
mail_sent_success_value="Successfully sent email"

def check_file_size(file_path):
    # Get the size of the file in bytes
    if file_path is None or file_path == "":
        return False
    file_size = os.path.getsize(file_path)
    # Convert bytes to megabytes
    file_size_mb = file_size / (1024 * 1024)
    return file_size_mb < 5  

def generate_required_notifications(notif_typ,inp_domain):
  """
    Generates required notifications based on notification type and input domain.

    Input:
        notif_typ (str): Notification type.
        inp_domain (str): Input domain.

    Returns:
        list: List of dictionaries containing notification details.
    """

  tablename_notif = f'{catlg_nam}.{NOTIFICATION_DETAILS_TABLE_NAME}'
  tablename_tmplts = f'{catlg_nam}.{NOTIFICATION_TEMPLATE_TABLE_NAME}'

  df_email_notif = spark.read.table(tablename_notif)
  df_email_tmplts = spark.read.table(tablename_tmplts)
  df_joined = df_email_notif.join(df_email_tmplts, col("msg_tmplt_id") == col("id"), "inner") \
                            .select("notif_typ", 
                                    "recpnt_email_addr_list", 
                                    "email_tmplt") \
                            .filter((col("domain") == inp_domain) & (col("notif_typ") == notif_typ))

  # Collect DataFrame rows and convert them into a list of dictionaries
  result_list = df_joined.collect()

  # Convert each row to a dictionary
  list_of_dicts = [row.asDict() for row in result_list]
  return list_of_dicts

def send_email(subject, email_body, recipients,attachment_path="",attachment_flag=False):
  # Step 1 - Fetch SMTP server details
  dbutils = get_dbutils()
  SMTP_AUTH_USER = dbutils.secrets.get(scope='daps-kv', key='smtp-user')
  SMTP_AUTH_PWD = dbutils.secrets.get(scope='daps-kv', key='smtp-password')
  SMTP_HOST_NAME = "mail-relay.emea.daimler.com"
  SMTP_PORT = 25

  # Step 2 - Send email for input details
  # Email content
  sender = SENDER_EMAIL
  receivers_to = recipients.split(",") 
  context = ssl.create_default_context()
  message = MIMEMultipart("alternative")
  message["Subject"] = subject
  message["From"] = EMAIL_FROM
  message["Sender"] = sender
  message["To"] = recipients

  # Construct HTML email body
  html = f"""<html><body><p>{email_body}</p></body></html>"""
  part1 = MIMEText(html, "html")
  message.attach(part1)

  if attachment_flag:
    attachment_filename = attachment_path.split('/')[-1]
    # Open the file to be sent
    with open(attachment_path, "rb") as attachment:
        # Add file as application/octet-stream
        part2 = MIMEBase("application", "octet-stream")
        part2.set_payload(attachment.read())

    # Encode file in ASCII characters to send via email
    encoders.encode_base64(part2)

    # Add header as key/value pair to attachment part
    part2.add_header(
    "Content-Disposition",
    f"attachment; filename= {attachment_filename}",
    )

    # Add attachment to message and convert message to string
    message.attach(part2)

  # Send email using SMTP
  with smtplib.SMTP(SMTP_HOST_NAME, SMTP_PORT) as server:
      server.ehlo()
      server.starttls(context=context)
      server.ehlo()
      server.login(SMTP_AUTH_USER, SMTP_AUTH_PWD)
      server.sendmail(sender, receivers_to, message.as_string())
    

def generate_required_notifications_schema_evolution(bronze_table_name, source_columns, inp_domain, filename):
    """
    Generates required notifications for schema evolution.

    Input:
        bronze_table_name (str): Name of the bronze table.
        source_columns (list): List of source columns.
        inp_domain (str): Input domain.
        filename (str): Name of the file.

    Returns:
        Tuple: True/False indicating success, and message.
    """

    try:
        extra_cols, missing_cols = get_extra_missing_cols_between_landing_and_bronze(bronze_table_name,source_columns)
        if len(extra_cols)==0 and len(missing_cols)==0:
            return True,"No extra and missing columns"
        list_of_dicts = generate_required_notifications(SCHEMA_EVOLUTION_TYP, INPUT_DOMAIN)
        if len(list_of_dicts)==0:
            raise framwork_cstom_error(no_mail_sent_value)
        current_date = datetime.now().date()
        for record in list_of_dicts:
            recpnt_email_addr_list = record['recpnt_email_addr_list']
            email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
            subject = email_tmplt['subject']
            email_body = email_tmplt['email_body']
            send_email(subject, email_body, recpnt_email_addr_list)
        return True,mail_sent_success_value
    except Exception as e:
        error_message = "Error generating required notifications for schema evolution:" + str(e)
        return False,error_message

def generate_required_notifications_bad_records(inp_domain, filename, input_count, rejected_count, bad_record_path):
    """
    Generates required notifications for bad records.

    Input:
        inp_domain (str): Input domain.
        filename (str): Name of the file.
        input_count (int): Count of input records.
        rejected_count (int): Count of rejected records.
        bad_record_path (str): Path to bad records.

    Returns:
        Tuple: True/False indicating success, and message.
    """

    try:
        if bad_record_path != "" and check_file_size(bad_record_path):
            attachment_body = "Please find attached file"
            attachment_flag = True
        else:
            attachment_body = "File is greater than 5MB"
            attachment_flag = False
        current_date = datetime.now().date()
        list_of_dicts = generate_required_notifications(DATA_QUALITY_TYP, INPUT_DOMAIN)
        if len(list_of_dicts)==0:
            raise framwork_cstom_error(no_mail_sent_value)
        for record in list_of_dicts:
            recpnt_email_addr_list = record['recpnt_email_addr_list']
            email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
            subject = email_tmplt['subject']
            email_body = email_tmplt['email_body']
            send_email(subject, email_body, recpnt_email_addr_list,bad_record_path,attachment_flag)
        return True,mail_sent_success_value
    except Exception as e:
        error_message = "Error generating required notifications for bad records:" + str(e)
        return False,error_message

def get_api_failure_retry_count(id_src_file,oper_phase):
    try:
        df_watermark = read_delta_table(wm_tabl_nam,catlg_nam)
        df_watermark_filtered = df_watermark.filter((col("oper_phase") == oper_phase) & 
                                                (col("id_proc") == id_src_file) & 
                                                (col("run_dte") == current_date()))
        retry_count = 0
        if df_watermark_filtered and df_watermark_filtered.count()>0:
            watermark_latest_record = df_watermark_filtered.orderBy(col("proc_started_ts").desc()).select("addnl_info").collect()[0].asDict()["addnl_info"]
            retry_count = int(watermark_latest_record.get("retry_count")) + RETRY_COUNT
        else:
            retry_count = RETRY_COUNT
        return retry_count,"Successfull"
    except Exception as e:
        error_message = "Error get retry count for API Failure:" + str(e)
        return None,error_message


def generate_api_failure_notification(retry_count,filename,domain):
  try:
    list_of_email_details = generate_required_notifications(API_FAILURE_TYP,INPUT_DOMAIN)
    if len(list_of_email_details)==0:
            raise framwork_cstom_error(no_mail_sent_value)
    current_date = datetime.now().date()
    for record in list_of_email_details:
        recpnt_email_addr_list = record['recpnt_email_addr_list']
        email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
        subject = email_tmplt['subject']
        email_body = email_tmplt['email_body']
        send_email(subject, email_body, recpnt_email_addr_list)
    return True,mail_sent_success_value
  except Exception as e:
      error_message = "Error generating required notifications for API Failure:" + str(e)
      return False,error_message


def generate_missing_files_notification(trigger_time,missing_files,domain):
  try:
    list_of_email_details = generate_required_notifications(MISSING_FILE_TYP,INPUT_DOMAIN)
    if len(list_of_email_details)==0:
            raise framwork_cstom_error(no_mail_sent_value)
    current_date = datetime.now().date()
    for record in list_of_email_details:
        recpnt_email_addr_list = record['recpnt_email_addr_list']      
        email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
        print(email_tmplt)
        subject = email_tmplt['subject']
        email_body = email_tmplt['email_body']
        send_email(subject, email_body, recpnt_email_addr_list)
    return True,mail_sent_success_value
  except Exception as e:
      error_message = "Error generating required notifications for Missing Files:" + str(e)
      print(error_message)
      return False,error_message  
  
def generate_pipeline_failure_notification(error_list,pipeline_runid,pipeline_name,pipeline_trigger_time):
  try:
    list_of_email_details = generate_required_notifications(PIPELINE_FAILURE_TYP,INPUT_DOMAIN)
    if len(list_of_email_details)==0:
            raise framwork_cstom_error(no_mail_sent_value)
    current_date = datetime.now().date()
    for record in list_of_email_details:
        recpnt_email_addr_list = record['recpnt_email_addr_list']      
        email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
        print(email_tmplt)
        print(f"Pipeline run ID:{pipeline_runid},Pipeline Name :{pipeline_name},Pipeline Trigger Time :{pipeline_trigger_time},Error List :{error_list},Current_date :{current_date}")
        subject = email_tmplt['subject']
        email_body = email_tmplt['email_body']
        send_email(subject, email_body, recpnt_email_addr_list)
    return True,mail_sent_success_value
  except Exception as e:
      error_message = "Error generating required notifications for pieline failures:" + str(e)
      print(error_message)
      return False,error_message   
  
def generate_pipeline_failure_notification_api_eligibility(pipeline_runid,pipeline_name,pipeline_trigger_time,activity_name):
  try:
    list_of_email_details = generate_required_notifications(PIPELINE_API_TYP,INPUT_DOMAIN)
    if len(list_of_email_details)==0:
            raise framwork_cstom_error(no_mail_sent_value)
    current_date = datetime.now().date()
    for record in list_of_email_details:
        recpnt_email_addr_list = record['recpnt_email_addr_list']      
        email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
        print(f"Pipeline run ID:{pipeline_runid},Pipeline Name :{pipeline_name},Pipeline Trigger Time :{pipeline_trigger_time},Current_date :{current_date},Activity_name : {activity_name}")
        subject = email_tmplt['subject']
        email_body = email_tmplt['email_body']
        send_email(subject, email_body, recpnt_email_addr_list)
    return True,mail_sent_success_value
  except Exception as e:
      error_message = "Error generating required notifications for pieline failures due to API eligibility error:" + str(e)
      print(error_message)
      return False,error_message  
  
def generate_pipeline_failure_notification_zip_eligibility(pipeline_runid,pipeline_name,pipeline_trigger_time,activity_name):
  try:
    list_of_email_details = generate_required_notifications(PIPELINE_ZIP_TYP,INPUT_DOMAIN)
    if len(list_of_email_details)==0:
            raise framwork_cstom_error(no_mail_sent_value)
    current_date = datetime.now().date()
    for record in list_of_email_details:
        recpnt_email_addr_list = record['recpnt_email_addr_list']      
        email_tmplt = eval(record['email_tmplt'].replace('\n', ''))
        print(email_tmplt)
        print(f"Pipeline run ID:{pipeline_runid},Pipeline Name :{pipeline_name},Pipeline Trigger Time :{pipeline_trigger_time},Current_date :{current_date},Activity_name : {activity_name}")
        subject = email_tmplt['subject']
        email_body = email_tmplt['email_body']
        send_email(subject, email_body, recpnt_email_addr_list)
    return True,mail_sent_success_value
  except Exception as e:
      error_message = "Error generating required notifications for pieline failures due to zip eligibility error:" + str(e)
      print(error_message)
      return False,error_message    
  