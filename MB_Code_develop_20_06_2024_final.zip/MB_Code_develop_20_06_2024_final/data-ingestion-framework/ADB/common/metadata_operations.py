from pyspark.sql.functions import current_timestamp,col, lit,max, array, expr, when,substring, substring, to_date, to_timestamp
from delta.tables import DeltaTable
from enum import Enum
import re
from pyspark.sql.types import StructType,StructField, DateType, LongType,TimestampType, ArrayType, MapType, StringType
from datetime import datetime, date
from pyspark.sql import DataFrame
from ADB.common.config import OPER_STAT_DICT,BRONZE_AUDIT_COLUMNS,catlg_nam,catlg_nam,wm_tabl_nam
from ADB.common.common_utilities import read_delta_table,spark
from ADB.common.watermark_utils import watermark_read, watermark_operations, Watermark, insert_error_into_watermark
 
# COMMAND -----------

def get_inf_schm_dict(table_name:str,schema_name:str,df_information_schema:DataFrame)->dict:
  """
    This function gets the information schema tables from Unity catalog.
    Input:
    - table_name -> table name 
    - schema_name -> schema name
    -df_information_schema -> information_schema dataframe

     Returns:
    - typecasted dictionary
    """
  schema_name=schema_check_and_modify(schema_name)
  inf_sch_col_list = df_information_schema.filter((col('table_name')==table_name) & (col('table_schema')==schema_name) ).select(col('column_name'),col('data_type')).collect()
  typecast_dict = {row['column_name'].lower():row['data_type'] for row in inf_sch_col_list}

  return typecast_dict

def schema_check_and_modify(schema_name:str):
  """
    This function modify the schema name when schema name starts with ` and ends with `.
    Input:
    - schema_name -> name of schema to modify
     Returns:
    - modified schema name
    """
  if schema_name[0]=='`':
    schema_name=schema_name[1:]
    schema_name=schema_name[:-1]
  return schema_name


# COMMAND ----------

def drop_columns_inf_sch(table_name:str,schema_name:str,df_information_schema:DataFrame,df_bronze:DataFrame)->DataFrame:
  """
    This function compares and drop the extra columns based on the information schema from Unity catalog.
    Input:
    - table_name -> table name 
    - schema_name -> schema name
    -df_information_schema -> information_schema dataframe
    df_bronze -> dataframe for hwihc columns needs to be compared

     Returns:
    - dataframe after dropping the extra columns
    """
  schema_name=schema_check_and_modify(schema_name)
  inf_sch_col_list = df_information_schema.filter((col('table_name')==table_name) & (col('table_schema')==schema_name) ).select(col('column_name'),col('data_type')).collect()
  silver_col_list = [row['column_name'] for row in inf_sch_col_list]
  bronze_col_list = df_bronze.columns
  drop_col_list = list(set(bronze_col_list) - set(silver_col_list))
  df_bronze_drop = df_bronze.drop(*drop_col_list)
  return df_bronze_drop

# COMMAND ----------

def get_dbutils_widgets(dbutils,layer=''):
  """
    This function returns the values of widgets based on the layers.
    Input:
    - dbutils -> dbutils 
    - layer -> layer
     Returns:
    - dictionary for the widgets for the layers
    """

  if layer == 'landing':
    dbutils.widgets.text("filename","")
    dbutils.widgets.text("filepath","")
    dbutils.widgets.text("id_batch","")
    dbutils.widgets.text("id_src_file","")
    dbutils.widgets.text("domn_area","")

    filename = dbutils.widgets.get("filename")
    filepath = dbutils.widgets.get("filepath")
    id_batch = dbutils.widgets.get("id_batch")
    id_src_file = dbutils.widgets.get("id_src_file")
    lvl_lyr = 0
    domn_area = dbutils.widgets.get("domn_area")
  
  elif layer == 'pre-processing':
    dbutils.widgets.text("operating_phase","")
    dbutils.widgets.text("copy_status","")
    dbutils.widgets.text("id_batch","")
    dbutils.widgets.text("id_src_file","")
    dbutils.widgets.text("domn_area","")
    dbutils.widgets.text("nam_src_file","")

    oper_phase = dbutils.widgets.get("operating_phase")
    oper_stat = dbutils.widgets.get("copy_status")
    id_batch = dbutils.widgets.get("id_batch")
    id_src_file = dbutils.widgets.get("id_src_file")
    domn_area = dbutils.widgets.get("domn_area")
    nam_src_file = dbutils.widgets.get("nam_src_file")

    widget_list= [[id_src_file,oper_phase,oper_stat,id_batch,domn_area,nam_src_file],['id_src_file','oper_phase','oper_stat','id_batch','domn_area','nam_src_file']]
    return dict(zip(widget_list[1],widget_list[0]))
   
  else:
    dbutils.widgets.text("id_src_file","")
    dbutils.widgets.text("lvl_lyr","")
    dbutils.widgets.text("filename","")
    dbutils.widgets.text("filepath","")
    dbutils.widgets.text("id_batch","")
    dbutils.widgets.text("domn_area","")

    id_src_file = dbutils.widgets.get("id_src_file")
    lvl_lyr = int(dbutils.widgets.get("lvl_lyr"))
    filename = dbutils.widgets.get("filename")
    filepath = dbutils.widgets.get("filepath")
    id_batch = dbutils.widgets.get("id_batch")
    domn_area = dbutils.widgets.get("domn_area")

  widget_list= [[id_src_file,lvl_lyr,filename,filepath,id_batch,domn_area],['id_src_file','lvl_lyr','filename','filepath','id_batch','domn_area']]

  return dict(zip(widget_list[1],widget_list[0]))

# COMMAND ----------

def get_good_dup_records(df_main:DataFrame,additional_info_lyr_mstr)->DataFrame:
  """
    This function drops the duplication from the dataframe.
    Input:
    - df_main -> dataframe from the duplicates needs to removed. 
    - additional_info_lyr_mstr -> additional infor from layer master table 
     Returns:
    - dataframe after dropping the duplicates.
    """
  try:
    if additional_info_lyr_mstr == None:
      drop_columns = None
    else:
      if additional_info_lyr_mstr.get('merge_joining_cols') != None:
        drop_columns = additional_info_lyr_mstr['merge_joining_cols'].split(',')
      else:
        drop_columns = None
    
    return df_main.dropDuplicates(drop_columns),True , None
  except Exception as ex:
    None , False , f"error during get dupliacted records {str(ex)}"

def get_bad_dup_records(df_main:DataFrame, df_good_records:DataFrame)->DataFrame:
  """
    This function created a dataframe with duplicate bad records.
    Input:
    - df_main -> dataframe from the duplicates bad records needs to collected. 
    - df_good_records -> dataframe with the good records 
     Returns:
    - dataframe with duplicates records with the dropping category.
    """
  return df_main.exceptAll(df_good_records).withColumns({'corrupt_records':lit(None).cast(ArrayType(MapType(StringType(),StringType()))),'drop_reason_category':lit('Duplicate')})

# COMMAND ----------

def insert_audit_columns(catlg_nam:str , silver_table_name:str,additional_info:dict,df:DataFrame,audit_columns:list)->DataFrame:
  """
    This function insert the audit columns.
    Input:
    - catlg_nam ->name of catalog.
    - silver_table_name -> silver table with the audit columns needs to added.
    - additional_info -> additional information if anything required.
    -df -> dataframe where audiit columns needs to drop
    -audit_columns -> list of audit columns
     Returns:
    - dataframe with audit columns.
    """
  df_silver_table = read_delta_table(silver_table_name,catlg_nam)
  df = df.drop(*audit_columns)
  
  if additional_info == None:
    join_conditions = None 
  else:
    if additional_info.get('merge_joining_cols') == None:
      join_conditions = None
    else:
      join_conditions = additional_info['merge_joining_cols'].split(',')

  created_timestamp = datetime.now()
  
  tmp_df = df.alias('left-table').join(df_silver_table.alias('right-table'),[df[i] == df_silver_table[i] for i in join_conditions],"left")
  df_final = tmp_df.select('left-table.*',\
    when(df_silver_table[audit_columns[0]].isNull(),date.today()).otherwise(df_silver_table[audit_columns[0]]).alias('rundate'),\
      when(df_silver_table[audit_columns[1]].isNull(),created_timestamp).otherwise(df_silver_table[audit_columns[1]]).alias('created_timestamp'))\
        .dropDuplicates().withColumn('updated_timestamp',lit(created_timestamp))

  return df_final
 
# COMMAND ----------

def filter_dataframe(delta_df, filter_dict):
    """
    filter a input dataframe with a condition json provided

    Input:
        - df on which filter to be applied
        - filter condition dictionary
    Return:
        - output df
    """
    from pyspark.sql.functions import col
    filter_conditions = []

    for column, filter_info in filter_dict.items():
        operator = filter_info.get("operator")
        ref_value = filter_info.get("ref_value")

        if operator and ref_value:
            if operator == "==":
                filter_conditions.append(col(column) == ref_value)
            elif operator == ">":
                filter_conditions.append(col(column) > ref_value)
            elif operator == ">=":
                filter_conditions.append(col(column) >= ref_value)
            elif operator == "<":
                filter_conditions.append(col(column) < ref_value)
            elif operator == "!=":
                filter_conditions.append(col(column) != ref_value)
    
    if filter_conditions:
        combined_conditions = filter_conditions[0]
        for condition in filter_conditions[1:]:
            combined_conditions = combined_conditions & condition
        return delta_df.filter(combined_conditions)
    else:
        return delta_df


# COMMAND ----------

class column_rename():
    """
    this function rename the columns if required.

    Input:
    Return:
        - output after rename the columns
    """
    def __init__(self, df_meta: DataFrame, df_target: DataFrame, mapping_id:int):
        self.df_meta = df_meta
        self.df_target = df_target
        self.colrename_col = 'is_colname_same'
        self.src_col = 'src_col'
        self.tgt_col = 'tgt_col'
        self.mapping_id = 'id_mapping'
        self.df_trans_map = self.df_meta.filter(col(self.mapping_id)==mapping_id).withColumn(self.colrename_col,when(col(self.src_col)==col(self.tgt_col),True).otherwise(False))

    def col_rename(self, column_dict: dict) -> DataFrame:
        if len(column_dict)>0:
            self.df_target = self.df_target.select([col(f"`{c}`" if '.' in c else c).alias(column_dict.get(c, c)) for c in self.df_target.columns])
        return self.df_target
    
    def get_columnrenamed_dict(self):
        self.column_dict = dict([(row[self.src_col],row[self.tgt_col]) for row in self.df_trans_map.filter(col(self.colrename_col) == False ).select(col(self.src_col),col(self.tgt_col)).collect()])
        return self.column_dict

    def column_rename_final(self) -> DataFrame:
        self.column_dict = self.get_columnrenamed_dict()
        self.df_target = self.col_rename(self.column_dict)

        return self.df_target

# COMMAND ----------

def column_casting(df_target: DataFrame, typecast_dict: dict,timestamp_format:str,date_format:str) -> DataFrame:
    """
    this function makes column typecasting from bronze to silver.

    Input:
    -df_target - target dataframe for column typecast.
    -typecast_dict - dictionary for coumns typecast info
    -date_format
    -timestamp_format
    Return:
        - datafarme after the column casting
    """
    try:
      if len(typecast_dict)>0 :
        conversion_list = []
        for field in df_target.schema.fields:
          if typecast_dict.get(field.name.lower(), field.dataType) == 'DATE':
            conversion_list.append(to_date(field.name.lower(), format=date_format).alias(field.name.lower()))
          
          elif typecast_dict.get(field.name.lower(), field.dataType) == 'TIMESTAMP':
            conversion_list.append(to_timestamp(field.name.lower(), format=timestamp_format).alias(field.name.lower()))
          else:
            conversion_list.append(col(field.name.lower()).cast(typecast_dict.get(field.name.lower(), field.dataType)))

        df_target = df_target.select(conversion_list)
      return df_target,True,None
    except Exception as ex:
      return None,False , f"Error During Column Casting {str(ex)}"


# COMMAND ----------

def get_master_details_with_filter(catlg_nam:str, table_name:str,filter_condition:dict={})->DataFrame:
  """
    this function gets the layer master details for perticular layer.

    Input:
    -catlg_nam - catlg_nam.
    -table_name - table_name.
    -filter_condition - filtering condition with layer master.
  
    Return:
        - filtered row from layer master
    """
  try:
    read_table_with_condition = watermark_read
    df_filter_layer_master = read_table_with_condition(catlg_nam, table_name, filter_condition)
    
    if df_filter_layer_master.count() > 0:
        lm_filter_row = df_filter_layer_master.first().asDict()
        return lm_filter_row, True , None
    else:
      return {}, False , 'No data found in data layer'

  except Exception as ex:
    print(f"An error occurred: {ex}")
    return {}, False , "error while reading the layer master " + str(ex)

# COMMAND ----------

def latest_bronze_data_using_watermark(catlg_nam:str, watermark_table:str, bronze_table:str, condition:dict={}) ->DataFrame :
  """
    this function gets latest records using the watermark logs.

    Input:
    -catlg_nam - catlg_nam.
    -watermark_table - watermark_table.
    -bronze_table - bronze_table name.
    -condition - condition dictionary to filter the bronze table data
  
    Return:
        - df bronze for bronze layer
    """
  try:

    df = watermark_operations(catlg_nam, watermark_table, filter_condition=condition, operation='read')
    max_proc_started_ts = df.select(max('proc_started_ts').alias('max_proc_started_ts')).first()[0]

    df_bronze = read_delta_table(bronze_table,catlg_nam)

    filter_cond_dict = {}
    filter_proc_started_ts_dict = {"operator" : ">=", "ref_value" : max_proc_started_ts}
    filter_cond_dict['created_timestamp'] = filter_proc_started_ts_dict
    df_bronze = filter_dataframe(df_bronze, filter_cond_dict)
    return df_bronze,True , None
  
  except Exception as ex:
    return None , False , f"error during while get latest bronze data using watermark {str(ex)}"


# COMMAND ------------

def final_upload_csv_to_volume(df:DataFrame,watermark_dict:dict,folder_name:str,volume_position:int,date_position:int,time_position:int,sub_folder:str=None,mode='append'):
  """
    this function uploads the bad records csv file to volumne path.

    Input:
    -df - dataframe from the bad records csv will be loaded.
    -watermark_dict - watermark_dict.
    -folder_name - folder name where csv needs to uploaded.
    -volume_position - condition dictionary to filter the bronze table data
    -date_position
    -time_position
    -sub_folder - sub folder if any
    -mode - append mode 
  
    Return:
        - bad records csv file upload status , bad records path
    """
  volume_path = volume_path_extractor(watermark_dict,path_position=volume_position)
  current_folder_name = current_folder_extractor(watermark_dict,date_position=date_position,time_position=time_position)
  bad_records_upload_status,bad_records_path  = upload_csv_into_volume(df, watermark_dict,volume_path,folder_name,current_folder_name,sub_folder,mode)

  return bad_records_upload_status,bad_records_path 

def upload_csv_into_volume(df:DataFrame,watermark_dict:dict,volume_path:str,folder_name:str,current_date_folder:str,sub_folder:str=None,mode='append'):
  """
    this function uploads the bad records csv file to volumne path absed on current date wise.

    Input:
    -df - dataframe from the bad records csv will be loaded.
    -watermark_dict - watermark_dict.
    -current_date_folder - folder name where csv needs to uploaded.
    -sub_folder - sub folder if any
    -mode - append mode 
  
    Return:
        - status and file path
    """
  try:
    filename = watermark_dict.get('filename')
    temp_folder = ''
    if folder_name == 'bad_records':
      temp_folder = '/temp'
    if sub_folder is None or sub_folder == '':
      file_path = f'{volume_path}/{folder_name}/{current_date_folder}/{filename}'+temp_folder
    else:
      file_path = f'{volume_path}/{folder_name}/{current_date_folder}/{sub_folder}/{filename}'+temp_folder
    
    if df.count() == 0:
      return False,file_path
    
    df = df.select([col(i).cast(StringType()) for i in df.columns])
    df.coalesce(1).write.option("header",True).mode(mode).csv(file_path)
    return True,file_path
  except Exception as e:
    print('Error while uploading data into Volume : ',str(e))
    return False,file_path

def move_temp_file(temp_path, filename):
  """
  Moves a temporary file from a temporary location to a final destination.
  Parameters:
  temp_path (str): The temporary path where the file is currently located.
  filename (str): The desired filename for the file at its final destination.
  Returns:
  tuple: A tuple containing a boolean indicating the success of the operation
  and the final path of the moved file.
  """
  from ADB.common.common_objects import get_dbutils
  dbutils = get_dbutils()
  try:
      # List files in the temporary directory
      files = dbutils.fs.ls(temp_path)

      # Define the final path where the file will be moved
      final_path = temp_path.split('/temp')[0] + '/' + filename

      # Get the path of the part file (assuming the file is partitioned)
      part_file = [file.path for file in files if file.name.startswith("part-")]

      # If part file is not found, raise an error
      if not part_file:
          raise FileNotFoundError("Part file not found in the temporary directory.")

      # Set the temporary full path to the found part file
      temp_full_path = part_file[0]

      # Move the file to its final destination
      dbutils.fs.mv(temp_full_path, final_path)

      # Remove the temporary directory
      dbutils.fs.rm(temp_path, recurse=True)

      # Return success status and the final path
      return True, final_path

  except Exception as e:
      # Handle any errors occurred during the process
      return False, str(e)
  
def volume_path_extractor(watermark_dict:dict,path_position:int):
  """
    this function extract the volumne path.

    Input:
    -watermark_dict - watermark_dict.
    -path_position - 

    Return:
        - joined volume path 
    """
  return '/'.join(watermark_dict.get('filepath').split('/')[:path_position])

def current_folder_extractor(watermark_dict:dict,date_position:int,time_position:int):
  """
    this function extract the current folder abed on date and time.

    Input:
    -watermark_dict - watermark_dict.
    -date_position - 
    -time_position-

    Return:
        - joined date and time folder names
    """
  date_folder_name = watermark_dict.get('filepath').split('/')[date_position]
  time_folder_name = watermark_dict.get('filepath').split('/')[time_position]

  return f'{date_folder_name}/{time_folder_name}'

def get_upload_extra_missing_cols(df:DataFrame, catlg_nam:str,watermark_table:str,information_schema_table:str,layer_table,mapping_table:str,col_enrich_table:str,audit_columns:list, watermark_dict:dict):
  """
    this function gets the extra and missing columns if any from bronze to silver.

    Input:
    -df - watermark_dict.
    -catlg_nam - 
    -watermark_table-
    -information_schema_table
    -layer_table
    -mapping_table
    -col_enrich_table
    -audit_columns
    -watermark_dict
    -dbutils

    Return:
        - flagged records dataframe and upload status
    """
  try:
    from ADB.common.common_utilities import read_delta_table
    condition = {'id_src_file': watermark_dict.get('id_src_file'), 'lvl_lyr': 2}
    lm_filter_row, lm_flag ,_= get_master_details_with_filter(catlg_nam, layer_table, condition)

    if lm_flag:
      silver_table_name = lm_filter_row.get('tgt_nam')
      lm_addnl_info = lm_filter_row.get('addnl_info')
      lm_mapping_id = lm_filter_row.get('mapping_id')

    else:
      error_message = 'No data found in Layer Master : ' + str(condition)
      _, _, _, _ = insert_error_into_watermark(catlg_nam, watermark_table, watermark_dict,
                                                 OPER_STAT_DICT.get('error'), error_message)
      raise framwork_cstom_error(error_message)

    schema_name_inf_sch = silver_table_name.split('.')[0].lower()
    table_name_inf_sch = silver_table_name.split('.')[1].lower()
    df_information_schema = read_delta_table(information_schema_table, catlg_nam)
    df_information_schema = df_information_schema.filter(~col('column_name').isin(audit_columns))

    silver_col_list = list(get_inf_schm_dict(table_name_inf_sch, schema_name_inf_sch, df_information_schema).keys())
    df_mapping_table = read_delta_table(mapping_table, catlg_nam)
    ob = column_rename(df_mapping_table, df, mapping_id=lm_mapping_id)

    df_col_enrich_table = read_delta_table(col_enrich_table, catlg_nam)
    col_enrich_list = [i['trgt_col_to_enrich'] for i in
                       df_col_enrich_table.filter(col('id_mapping') == lm_mapping_id).select(
                           'trgt_col_to_enrich').collect()]

    df_landing_rename = ob.column_rename_final()
    landing_col_list = [element.lower() for element in df_landing_rename.columns]

    rundate = datetime.strptime(re.search(r'\d{8}', watermark_dict.get('filename')).group(), '%Y%m%d').date()
               
    created_timestamp = datetime.now()

    extra_cols_in_bronze = list(set(landing_col_list) - set(silver_col_list))
    cols_missing_in_bronze = list(set(silver_col_list) - set(landing_col_list) - set(col_enrich_list))

    extra_cols_join_cols = lm_addnl_info['merge_joining_cols'].split(',') + extra_cols_in_bronze

    upload_status = False
    extra_cols_flag = False
    missing_cols_flag = False
    df_bad_records = spark.createDataFrame([()])

    volume_path = volume_path_extractor(watermark_dict, path_position=5)
    current_folder_name = current_folder_extractor(watermark_dict, date_position=6, time_position=7)

    if len(extra_cols_in_bronze) > 0:

      extra_reason = ','.join(extra_cols_in_bronze)
      df_bad_records_extra_cols = df.select(extra_cols_join_cols).withColumns(
            {'rundate': lit(rundate), 'created_timestamp': lit(created_timestamp)}).withColumns(
            {'extra_columns': lit(extra_reason)})
      extra_cols_flag = True

    if len(cols_missing_in_bronze) > 0:
      missing_reason = ','.join(cols_missing_in_bronze)
      joining_keys = lm_addnl_info['merge_joining_cols'].split(',')
      df_bad_records_missing_cols = df.select(joining_keys).withColumns(
            {'rundate': lit(rundate), 'created_timestamp': lit(created_timestamp)}).withColumns(
            {'missing_columns': lit(missing_reason)})
      missing_cols_flag = True

    if extra_cols_flag and missing_cols_flag:
      df_bad_records = df_bad_records_extra_cols.withColumns({'missing_columns': lit(missing_reason)})
    elif extra_cols_flag:
      df_bad_records = df_bad_records_extra_cols.withColumns({'missing_columns': lit('')})
    elif missing_cols_flag:
      df_bad_records = df_bad_records_missing_cols.withColumns({'extra_columns': lit('')})

    if extra_cols_flag or missing_cols_flag:
      upload_status, _ = upload_csv_into_volume(df_bad_records, watermark_dict, volume_path, 'flagged_records',
                                                  current_folder_name, mode='append')

    return upload_status,True,None

  except Exception as ex:
    return False,False, f"Error during gets the extra and missing columns if any from bronze to silver{str(ex)}"


# COMMAND ----------

def get_silver_schema_records(df:DataFrame, catlg_nam:str,silver_table_name:str, information_schema_table:str, silver_audit_columns:list,bronze_audit_columns:list):
  """
    this function extract silver schema records.

    Input:
    -df - dataframe.
    -catlg_nam - 
    -silver_table_name-
    -information_schema_table
    -silver_audit_columns
    -bronze_audit_columns

    Return:
        - dataframe bronze and typecast dictionary.
    """
  try:  
    schema_name_inf_sch = silver_table_name.split('.')[0]
    table_name_inf_sch = silver_table_name.split('.')[1]
    df_information_schema = read_delta_table(information_schema_table,catlg_nam)
    df_information_schema = df_information_schema.filter(~col('column_name').isin(silver_audit_columns))

    typecast_dict = get_inf_schm_dict(table_name_inf_sch,schema_name_inf_sch,df_information_schema)

    df_bronze_drop = drop_columns_inf_sch(table_name_inf_sch,schema_name_inf_sch,df_information_schema,df)
    df_bronze_drop = df_bronze_drop.drop(*bronze_audit_columns)
  

    return df_bronze_drop, typecast_dict , True , None
  except Exception as ex:
    return None,None,False,f"Error during get Silver Schema records:{str(ex)}"

# COMMAND ----------

def custom_json_handling(custome_json_handling_funcname:str,df_bronze_rename:DataFrame):
  """
    this function handles the custom json bronze records.

    Input:
    -custome_json_handling_funcname - function name of custom json handling.
    -df_bronze_rename - dataframe with the json record

    Return:
        - dataframe after the flatten the json records.
    """
  try:
    custom_json_modulename=custome_json_handling_funcname.split('.')[0]
    custome_json_functionname = custome_json_handling_funcname.split('.')[1]
    dynamic_lib_import=f"from ADB.common.custom_json_handling_functions.{custom_json_modulename} import {custome_json_functionname}"
    exec(dynamic_lib_import)
    df_bronze_rename=locals()[custome_json_functionname](df_bronze_rename)
    return df_bronze_rename,True , None
  except Exception as e:
    None,False ,f"Error during custom json handling: {str(e)}"

# COMMAND ---------------------

def rename_columns_using_mapping_table(df:DataFrame, catlg_nam:str, mapping_table:str,mapping_id ):
  """
    this function rename the columns names uisng the mapping table.

    Input:
    -df - dataframe for column rename.
    -catlg_nam - catalog name.
    -mapping_table - mapping table name.
    -mapping_id - mapping id from the mapping table.

    Return:
        - dataframe after the column rename.
    """
  try:  
    df_mapping_table= read_delta_table(mapping_table,catlg_nam)
    ob = column_rename(df_mapping_table,df,mapping_id=mapping_id)
    df_bronze_rename = ob.column_rename_final()

    return df_bronze_rename,True , None
  except Exception as ex:
    return None, False ,f"error during column rename using mapping table {str(ex)}"


def remove_zipfile(dbutils, zip_path:str)->tuple:
  """
  This function deletes a zip file from a Catelog volume.

  Input:
    - dbutils: This module provides various utilities for users to interact with the rest of Databricks.
    - zip_path: Unity Catelog volume file path.

  Returns:
    - delete_status: It return a status in boolean whether a file is delete successfully or not.
    - error: It returns error details if any.
  """
  
  error = None
  try:
    rm_status = dbutils.fs.rm(zip_path)
    return error, rm_status
  except Exception as e:
    error = str(e)
    return error, False
  
def get_col_enrich_list(catlg_nam:str, col_enrich_table:str, layer_master_row:dict)->list:
  """
  This function gives us list of all the columns which need to enrich using enrich_table and its id_mapping value. 

  Input:
    - catlg_nam: Unity catelog name.
    - col_enrich_table: Column enrich table name with schema.
    - layer_master_row: Layer master details in dictionary where id_mapping details are present. 

  Returns:
    - col_enrich_list: It returns a list of all the columns which need to enrich.
  """

  df_col_enrich_table= read_delta_table(col_enrich_table,catlg_nam)
  col_enrich_list = [i['trgt_col_to_enrich'] for i in df_col_enrich_table.filter(col('id_mapping')==layer_master_row.get('mapping_id')).select('trgt_col_to_enrich').collect()]

  return col_enrich_list

def get_enrich_col(catlg_nam:str, col_enrich_table:str, df:DataFrame ,target_col_enrich:str,lm_filter_row:dict):
  """
  This function gets the information from the col_enrich table and apply desired function for a particular targeted column. And returns a dataframe after adding this targted column.

  Input:
    - catlg_nam: Unity catelog name.
    - col_enrich_table: Column enrich table name with schema.
    - df: On which dataframe, you need to perform this function.
    - target_col_enrich: Column which you need to add in dataframe.
    - layer_master_row: Layer master details in dictionary where id_mapping details are present. 

  Returns:
    - df: It returns a dataframe after adding the targted column.
    - error: It returns error details if any.
  """

  from ADB.common.column_enrich import split_name, concat_strings, product_of_columns
  df_col_enrich_table = read_delta_table(col_enrich_table,catlg_nam)

  df_col_enrich_filter = df_col_enrich_table.filter(col('id_mapping')==lm_filter_row.get('mapping_id'))
  col_enrich_row = df_col_enrich_filter.filter(col('trgt_col_to_enrich')==target_col_enrich).select('enrich_proc_spec').first().asDict()
  enrich_proc_spec = col_enrich_row.get('enrich_proc_spec')

  fn_name = enrich_proc_spec.get('ce_name')
  fn_parameters = enrich_proc_spec.get('ce_parameters')

  df,error = locals()[fn_name](df,target_col_enrich,fn_parameters)

  return df,error

def final_col_enrich(df:DataFrame,catlg_nam:str,column_enrich_table:str, layer_master_row:dict):
  """
  This function gets the information from the col_enrich table and apply desired function for a particular targeted column.
  This function iterates get_enrich_col fnction over a column item present in enrich list and returns a dataframe after adding these targted columns.

  Input:
    - df: On which dataframe, you need to perform this function.
    - catlg_nam: Unity catelog name.
    - column_enrich_table: Column enrich table name with schema.
    - layer_master_row: Layer master details in dictionary where id_mapping details are present. 

  Returns:
    - df: It returns a dataframe after adding the n numbers of targted column.
    - error: It returns error details if any.
  """
  col_enrich_list = get_col_enrich_list(catlg_nam, column_enrich_table, layer_master_row)
  col_enrich_error = None
  for target_col_enrich in col_enrich_list:
    df,col_enrich_error = get_enrich_col(catlg_nam,column_enrich_table,df,target_col_enrich,layer_master_row)

    if col_enrich_error:
      return None, col_enrich_error
    
  return df, col_enrich_error

def get_extra_missing_cols_between_landing_and_bronze(bronze_table_name, source_columns):
  """
    this function gets the extra and missing columns between landing and bronze.
    Input:
    -bronze_table_name - bronze table name.
    -source_columns - sourse columns in bronze layer.
    Return:
        - list of extra columns and missing columns
    """

  # Assuming these constants are defined elsewhere in your code
  df_bronze_table = read_delta_table(bronze_table_name, catlg_nam)
  df_bronze_table = df_bronze_table.drop(*BRONZE_AUDIT_COLUMNS)

  # Convert lists to sets for easier comparison
  source_set = set(source_columns)
  target_set = set(df_bronze_table.columns)

  # Identify columns present in source but not in target
  extra_in_source = source_set - target_set

  # Identify columns present in target but not in source
  missing_in_source = target_set - source_set

  return list(extra_in_source), list(missing_in_source)

class framwork_cstom_error(Exception):

    """Exception raised when there is error in notebooks.
    Attributes:
        message -- explanation of the error
    """

    def __init__(self,message):
        self.message = message
        super().__init__(self.message)

def insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, error_status,error_message):
  _,_,_,_ = insert_error_into_watermark(catlg_nam, wm_tabl_nam, watermark_dict, error_status,error_message)
  raise framwork_cstom_error(error_message)
        