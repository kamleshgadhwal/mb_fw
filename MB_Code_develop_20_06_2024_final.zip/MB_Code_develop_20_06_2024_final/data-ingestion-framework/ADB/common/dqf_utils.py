from pyspark.sql.functions import col, monotonically_increasing_id, lit, upper, regexp_extract, collect_list,concat_ws, to_json, from_json, row_number, create_map, lower, when
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import MapType,StringType, StructField, StructType, LongType, IntegerType, TimestampType
from ADB.common.common_objects import get_spark
from ADB.common.common_utilities import read_delta_table

spark = get_spark()
  
def write_df_to_delta(df:DataFrame,table_name:str, mode:str , catalog_name:str)->tuple:
  """
  This function writes dataframe into a delta table.
  Input:
    - input_dataframe: PySpark DataFrame which you need to ingest into delta table.
    - table_name: Delta Table name along with schema name. Example - 'test_framework_schema.table_name'
    - mode: Append or Overwrite mode.
    - catalog_name - Your desired catalog_name.
  Returns:
    - status_of_insertion: It returns a boolean status.
    - error: It returns error details if any.
  """

  error = None
  try:
    df1 = read_delta_table(table_name, catalog_name)

    if df1 == None:
      error = 'Table not exists'
      return False, error
    
    df.write.format("delta").mode(mode).saveAsTable(f'{catalog_name}.{table_name}')

    return True, error
  except Exception as e:
    error = str(e)
    return False, error

def get_rule_config_join_df(df_col_config:DataFrame,df_rule:DataFrame,config_id_obj:str)->DataFrame:
  """
  This function get data after joining of two dataframes (dq_col_config and dq_rule).

  Input:
    - df_col_config: dq_col_config metadata delta table dataframe.
    - df_rule: dq_rule metadata delta table dataframe
    - config_id_obj: tablename or table_id on which you are applying DQF.
  Returns:
    - Dataframe: It returns a DataFrame after joining.
  """

  df_filter_config = df_col_config.filter(col('id_obj')==config_id_obj).select('col_nam','kwargs_lst','id_rule')
  df_rule_config_join = df_filter_config.alias('col_config').join(df_rule.alias('rule'),col('col_config.id_rule')==col('rule.id_rule'),'inner')
  df_rule_config_join_final = df_rule_config_join.select('col_config.id_rule','col_config.col_nam','col_config.kwargs_lst','rule.rule_nam','rule.rule_args')

  df_agg = df_rule_config_join_final.groupby('id_rule','rule_nam','rule_args',to_json(col('kwargs_lst')).alias('kwargs')).agg(concat_ws(',', collect_list('col_nam')).alias('col_nam'))
  df_agg = df_agg.withColumn('kwargs_lst',from_json(col("kwargs"),MapType(StringType(),StringType()))).drop('kwargs')

  return df_agg
  
def get_config_row(row:dict)->dict:
  """
  This function adding some relavent information into input dictionary.

  Input:
    - row: Row extract after joining of dq_rule and dq_col_config
  Returns:
    - dictionary: It returns a dictionary after some processing.
  """
    
  kwargs = {'columns':row['col_nam'].split(',')}

  if row['rule_args']:
    if set(row['rule_args'].split(',')) == set(list(row['kwargs_lst'].keys())):
      kwargs.update(row['kwargs_lst'])
      return {'type':row['rule_nam'],'kwargs':kwargs}
    else:
      return {}
  else:
    return {'type':row['rule_nam'],'kwargs':kwargs}
  
def get_final_config(df_rule_config_join:DataFrame, profile_name:str = 'FRAMEWORK', data_profiling:str='full', system_name:str='TEST')->dict:
  """
  This function return config dictionary after using dq_rule and dq_col_config metadata delta tables.

  Input:
    - df_rule_config_join: Dataframe after joining of two dataframes (dq_col_config and dq_rule)
    - profile_name: This is hard coded value which will be using for genarating dynamic config
    - data_profiling: This is hard coded value which will be using for genarating dynamic config
    - system_name: This is hard coded value which will be using for genarating dynamic config

  Returns:
    - dictionary: It returns a config dictionary.
  """

  final_config_list = []
  for row in df_rule_config_join.collect():
    config_row = get_config_row(row.asDict())
    if config_row == {}:
      continue

    final_config_list.append(config_row)

  config = {
      "profile_name": profile_name,
      "data_profiling": data_profiling, 
      "system_name": system_name,
      "checks":final_config_list
  }

  return config

def get_failed_records_df(dfq_results:list)->DataFrame:
  """
  This function returns bad records using DQF class output.

  Input:
    - dfq_results: An output which comes after applying DQF. 

  Returns:
    - DataFrame: It creates a dataframe using output list.
  """
  df_failed_records = None
  for i in range(0,len(dfq_results)):
    if dfq_results[i]['type'] == 'check_custom_function' and dfq_results[i].get('display_name'):
      check_type = dfq_results[i].get('display_name')
    else:
      check_type = dfq_results[i]['type']
    for k in dfq_results[i]["failed_data"]:
      df_tmp = k['dataframe'].withColumns({'check_type':lit(check_type),'for_column':lit(k['for_column'])})
      if df_failed_records:
        df_failed_records = df_failed_records.unionAll(df_tmp)
      else:
        df_failed_records = df_tmp
  return df_failed_records

def get_row_id(df:DataFrame, dqf_col_seq_nam:str='dqf_col_seq_nam')->DataFrame:
  """
  This function will add a row_id as a column.

  Input:
    - df: Any Pyspark Dataframe. 
    - dqf_col_seq_nam: row_id column name. 

  Returns:
    - DataFrame: It returns a dataframe after adding row_id column.
  """

  source_df = df
  window_spec = Window.orderBy(source_df.columns)
  source_df = source_df.withColumn(dqf_col_seq_nam, row_number().over(window_spec))
  return source_df

def get_aggregate_dfq_report(check_dqf_obj:object,id_obj:str,dqf_col_seq_nam:str,df_failed_records:DataFrame,current_ts:object,bad_rcd_path:str='/some/path',current_user:str='USSHAHI')->DataFrame:
  """
  This function returns aggregated data using DQF results.

  Input:
    - check_dqf_obj: DQf result object. 
    - id_obj: Table name on which you are applying DQF. 
    - dqf_col_seq_nam: row_id column name. 
    - df_failed_records: Bad record dataframe. 
    - current_ts: current timestamp. 
    - bad_rcd_path: Path where you have to put bad records detailed delta files. 
    - current_user: Current user who runs this script. 

  Returns:
    - DataFrame: It creates a dataframe using output list.
  """

  row = check_dqf_obj.df_profile_results.first()
  id_rslt = row['profile_run_id']
  run_dte = row['time']
  obj_id = id_obj
  obj_desc = 'Framework_layer_build'
  tot_rcd = row['row_count']

  bad_rcd_df = df_failed_records.dropDuplicates([dqf_col_seq_nam])
  bad_rcd = bad_rcd_df.count()
  
  good_rcd = tot_rcd - bad_rcd
  dts_dw_crea = current_ts
  id_dw_crea_user = current_user
  dts_dw_updt = dts_dw_crea
  id_dw_updt_user = id_dw_crea_user

  data = [(id_rslt,run_dte,obj_id,obj_desc,tot_rcd,good_rcd,bad_rcd,bad_rcd_path,dts_dw_crea,id_dw_crea_user,dts_dw_updt,id_dw_updt_user)]

  columns = StructType(
    [
      StructField('id_rslt', StringType(), True), 
      StructField('run_dte', TimestampType(), True), 
      StructField('obj_id', StringType(), False),
      StructField('obj_des', StringType(), False),
      StructField('tot_rcd', IntegerType(), True), 
      StructField('good_rcd', IntegerType(), True),
      StructField('bad_rcd', IntegerType(), True),
      StructField('bad_rcd_path', StringType(), True),
      StructField('dts_dw_crea', TimestampType(), False),
      StructField('id_dw_crea_user', StringType(), False),
      StructField('dts_dw_updt', TimestampType(), False),
      StructField('id_dw_updt_user', StringType(), False)
      ]
    )

  df_agg = spark.createDataFrame(data, schema=columns)

  return df_agg

def get_check_fail_df(check_dqf_obj:object,df_rule:DataFrame,current_ts:object,current_user:str='USSHAHI')->DataFrame:
  """
  This function returns bad record row detail after using DQF results.

  Input:
    - check_dqf_obj: DQf result object. 
    - df_rule: dq_rule metadata delta table dataframe.
    - current_ts: current timestamp.
    - current_user: Current user who runs this script.  
   
  Returns:
    - DataFrame: It creates a dataframe using DQF results.
  """  
  df_tmp = check_dqf_obj.df_check_results.filter(col('result')=='fail').alias('main').join(df_rule.select('id_rule','rule_nam').alias('df_conf'),[upper(col('main.check_name'))==upper(col('df_conf.rule_nam'))],'inner')

  df_tmp = df_tmp.withColumn('bad_rcd', regexp_extract(col('failure_summary'), '(.)(failed_count=)(\d+)', 3))
  df_tmp = df_tmp.withColumn('good_rcd', regexp_extract(col('failure_summary'), '(.)(pass_count=)(\d+)', 3))
  df_tmp = df_tmp.select(col('check_id').alias('id_chk_fail'),col('profile_run_id').alias('id_rslt'),col('id_rule').alias('id_rule').cast('int'),col('column').alias('col_nam'),col('row_count').alias('tot_rcd').cast('int'),col('good_rcd').cast('int'),col('bad_rcd').cast('int'),col('message').alias('msg'))

  ts = current_ts

  df_tmp = df_tmp.withColumns({
    'dts_dw_crea':lit(ts).cast(TimestampType()),
    'id_dw_crea_user':lit(current_user).cast(StringType()),
    'dts_dw_updt':lit(ts).cast(TimestampType()),
    'id_dw_updt_user':lit(current_user).cast(StringType())
    })
  
  return df_tmp  

def get_good_records(source_df:DataFrame, df_failed_records:DataFrame,dqf_col_seq_nam:str)->DataFrame:
  """
  This function returns good records dataframe after removing bad records.

  Input:
    - source_df: Source dataframe or dataframe on which you are applying DQF. 
    - df_failed_records: Bad record dataframe.
    - dqf_col_seq_nam: row_id column name. 
   
  Returns:
    - DataFrame: It returns a dataframe after removing bad records.
  """  

  failed_id_list = [row[dqf_col_seq_nam] for row in df_failed_records.select(dqf_col_seq_nam).collect()]
  df_good_records = source_df.filter(~col(dqf_col_seq_nam).isin(failed_id_list)).drop(dqf_col_seq_nam)

  return df_good_records

def get_information_schema_df(catalog_name:str,table_name:str)->DataFrame:
  """
  This function returns information schema details for a particular table.

  Input:
    - catalog_name: Catalog name. 
    - table_name: Table name for which you need to get information schema details.
   
  Returns:
    - DataFrame: It returns a information schema dataframe.
  """  

  table_details = table_name.split('.')
  query = f"select * from {catalog_name}.information_schema.columns where table_catalog = '{catalog_name}' and table_schema = '{table_details[0]}' and table_name = '{table_details[1]}';"
  return spark.sql(query)

def update_null_check_info(df_rule_config_join:DataFrame,df_inf_sch:DataFrame,null_id_rule:int,null_rule_nam:str)->DataFrame:
  """
  This function getting nullability detail from information schema.

  Input:
    - df_rule_config_join: Dataframe after joining of two dataframes (dq_col_config and dq_rule)
    - df_inf_sch: Information schema dataframe.
    - null_id_rule: Null check id which are present in dq_rule table.
    - null_rule_nam: Null check rule name which are present in dq_rule table.
   
  Returns:
    - DataFrame: It returns a dataframe after getting nullability details using dq_rule metadata.
  """  

  inf_sch_null_list = [row['column_name'] for row in df_inf_sch.filter(col('is_nullable')=='NO').select(col('column_name')).collect()]

  if len(inf_sch_null_list) == 0:
    return df_rule_config_join

  df_col_config_null = df_rule_config_join.filter(col('id_rule')==null_id_rule)

  if df_col_config_null.count() > 0:
    col_conf_null_rcd = df_col_config_null.first().asDict()
    col_config_null_list = col_conf_null_rcd['col_nam'].split(',')

  else:
    col_conf_null_rcd = {'id_rule':null_id_rule,
                         'rule_nam':null_rule_nam,
                         'rule_args':None,
                         'col_nam':None,
                         'kwargs_lst':None}
    col_config_null_list = []

  col_conf_null_rcd['col_nam'] = ','.join(list(set(inf_sch_null_list + col_config_null_list)))
  df_final_null_check = spark.createDataFrame([list(col_conf_null_rcd.values())],df_rule_config_join.schema)
  df_rule_config_join = df_final_null_check.union(df_rule_config_join.filter(col('id_rule')!=null_id_rule))
  
  return df_rule_config_join

def update_string_length_check(df_rule_config_join:DataFrame, df_col_config:DataFrame,df_rule:DataFrame, df_inf_sch:DataFrame, id_obj:str,id_rule:int,length_side:str)->DataFrame:
  """
  This function getting varchar length details from information schema.

  Input:
    - df_rule_config_join: Dataframe after joining of two dataframes (dq_col_config and dq_rule)
    - df_col_config: dq_col_config metadata delta table dataframe.
    - df_rule: dq_rule metadata delta table dataframe
    - df_inf_sch: Information schema dataframe.
    - id_obj: Table name on which you are applying DQF and this also present on dq_col_config table.
    - id_rule: String length check id which are present in dq_rule table.
    - length_side: 'max' or 'min'.
   
  Returns:
    - DataFrame: It returns a dataframe after getting string length details using df_inf_sch,dq_rule and df_col_config metadata.
  """  
  if df_inf_sch.count()==0:
    return df_rule_config_join
  
  col_conf_string_list = [row['col_nam'] for row in df_col_config.filter(col('id_obj')==id_obj).filter(col('id_rule')==id_rule).select('col_nam').collect()]
  df_inf_sch_dtype = df_inf_sch.filter(~col('column_name').isin(col_conf_string_list)).filter((col('data_type')=='STRING') & (col('full_data_type')!='string'))

  df_string_for_mapping = df_inf_sch_dtype.select(col('table_name').alias('id_obj'),col('column_name').alias('col_nam'),col('data_type'),col('full_data_type'))
  df_string_for_mapping = df_string_for_mapping.withColumn('string_length', regexp_extract(col('full_data_type'), r'(\d+)', 1))
  df_string_for_mapping = df_string_for_mapping.withColumn('kwargs_lst',create_map(lit('string_length'),col('string_length'),lit('method'),lit(length_side))).drop('full_data_type','string_length','data_type')
  df_string_for_mapping = df_string_for_mapping.withColumn('id_rule',lit(id_rule))

  df_final_dtype_check = get_rule_config_join_df(df_string_for_mapping,df_rule,config_id_obj=id_obj)

  if df_rule_config_join.count()==0:
    return df_final_dtype_check
  else:
    df_rule_config_join = df_final_dtype_check.union(df_rule_config_join)
    return df_rule_config_join
  
def update_custom_config(config:dict,function_name,cols:list, dtype:str,  date_format = 'dd-MM-yyyy', timestamp_format = None)->dict:
  """
  This function update custom function details in config.

  Input:
    - config: Current DQF config.
    - function_name: Custom function you will apply on dataframe in DQF.
    - cols: All the columns on which you will apply custom function.
    - dtype: Type of datatype you are checking.
    - date_format: Date format you will need to check on date type column.
    - timestamp_format: Timestamp format you will need to check on timestamp type column.
   
  Returns:
    - dict: It returns a dictionary after update the custom function details in config.
  """  
  addition = {
            "type": "check_custom_function",
            "display_name": f"{function_name.__name__}",
            # "display_name": f"{function_name.__name__} - {dtype} check",
            "kwargs": 
              {
                "compute_method": function_name,
                "columns": cols,
                "iter_cols": True,
                "extra_args": {
                  "dtype": dtype,
                  "date_format":date_format,
                  "timestamp_format" : timestamp_format
                  }
              }
          }
  config['checks'].append(addition)

  return config

def update_type_check_info(df_rule_config_join:DataFrame, df_col_config:DataFrame,df_rule:DataFrame, df_inf_sch:DataFrame, id_obj:str,id_rule:int,type_name:str,typecast_dict:dict)->DataFrame:
  """
  This function update the current df_rule_config_join dataframe using df_col_config, df_rule and df_inf_sch metadata informations.

  Input:
    - df_rule_config_join: Dataframe after joining of two dataframes (dq_col_config and dq_rule)
    - df_col_config: dq_col_config metadata delta table dataframe.
    - df_rule: dq_rule metadata delta table dataframe
    - df_inf_sch: Information schema dataframe.
    - id_obj: Table name on which you are applying DQF and this also present on dq_col_config table.
    - id_rule: Id of rule which are present in dq_rule table.
    - type_name: Type of datatype you want to check.
    - typecast_dict: You need to mention column names on which you will apply DQF along its data type. This information data will be coming from information schema.
   
  Returns:
    - DataFrame: It returns updated df_rule_config_join dataframe.
  """  

  if df_inf_sch.count()==0:
    return df_rule_config_join
  
  col_conf_dtype_list = [row['col_nam'] for row in df_col_config.filter(col('id_obj')==id_obj).filter(col('id_rule')==id_rule).select('col_nam').collect()]
  df_inf_sch_dtype = df_inf_sch.filter(~col('column_name').isin(col_conf_dtype_list)).filter(col('data_type').isin(type_name.upper()))
  df_inf_sch_dtype = df_inf_sch_dtype.filter(col('column_name').isin(list(typecast_dict.keys())))

  if df_inf_sch_dtype.count()==0:
    return df_rule_config_join
  
  df_dtype_for_mapping = df_inf_sch_dtype.select(col('table_name').alias('id_obj'),col('column_name').alias('col_nam'),col('data_type')).withColumn('kwargs_lst',lit(None)).withColumn('id_rule',lit(id_rule)).drop('data_type')

  df_final_dtype_check = get_rule_config_join_df(df_dtype_for_mapping,df_rule,config_id_obj=id_obj)

  if df_rule_config_join.count()==0:
    return df_final_dtype_check
  else:
    df_rule_config_join = df_final_dtype_check.union(df_rule_config_join)
    return df_rule_config_join

def custom_check_datatype(df:DataFrame,column_name:str, dtype:str, date_format = 'dd-MM-yyyy', timestamp_format = None)->tuple:
  """
  This function checks datatype compatibility in a dataframe.

  Input:
    - df: Dataframe on which you are applying datatype check.
    - column_name: dq_col_config metadata delta table dataframe.
    - dtype: Type of datatype you are checking.
    - date_format: Date format you will need to check on date type column.
    - timestamp_format: Timestamp format you will need to check on timestamp type column.

  Returns:
    - tuple: 
      - status: Return boolean if type chekc pass then True else False.
      - result_df: return failed rows of dataframe.
      - msg: Returns this function message.
  """  
  if dtype == 'int':
    from pyspark.sql.types import IntegerType
    dtype_class = IntegerType.__name__
    casting = col(column_name).cast(IntegerType())
  elif dtype == 'long':
    from pyspark.sql.types import LongType
    dtype_class = LongType.__name__
    casting = col(column_name).cast(LongType())
  elif dtype == 'decimal':
    from pyspark.sql.types import DecimalType
    dtype_class = DecimalType.__name__
    casting = col(column_name).cast(DecimalType())
  elif dtype == 'float':
    from pyspark.sql.types import FloatType
    dtype_class = FloatType.__name__
    casting = col(column_name).cast(FloatType())
  elif dtype == 'short':
    from pyspark.sql.types import ShortType
    dtype_class = ShortType.__name__
    casting = col(column_name).cast(ShortType())
  elif dtype == 'double':
    from pyspark.sql.types import DoubleType
    dtype_class = DoubleType.__name__
    casting = col(column_name).cast(DoubleType())
  elif dtype == 'boolean':
    from pyspark.sql.types import BooleanType
    dtype_class = BooleanType.__name__
    casting = col(column_name).cast(BooleanType())
  elif dtype == 'timestamp':
    from pyspark.sql.functions import to_timestamp
    dtype_class = 'TimestampType'
    casting = to_timestamp(column_name, format=timestamp_format)
  elif dtype == 'date':
    from pyspark.sql.functions import to_date
    dtype_class = 'DateType'
    casting = to_date(column_name, format=date_format)

  check_casting  = when(casting.isNotNull(),1).otherwise(when(casting.isNull() & col(column_name).isNull(),1).otherwise(0))
  df = df.withColumn('is_castable',check_casting)

  result_df = df.filter(df['is_castable'] == 0)
  result_df = result_df.drop('is_castable')

  fail_count = result_df.count()

  if fail_count > 0:
      msg = f'Non {dtype_class}  exists {fail_count} times in {column_name}'
      return False, result_df, msg
  else:
      msg = f'{dtype_class} Values in {column_name}'
      return True, result_df, msg

def get_parameter_dict(dqf_col_seq_nam:str, id_obj:str,date_format='dd-MM-yyyy',timestamp_format = None,null_rule_nam:str = 'check_null',str_consis_rule_nam:str = 'check_string_consistency',str_length_side:str = 'max', custom_dtype_rule_nam:str = 'custom_check_datatype'):
  """
  This function return addnl_parama dictionary.

  Input:
    - dqf_col_seq_nam - String input - Row id column name.
    - id_obj - string input - Target table name. This entry must be present in dq_col_config.
    - date_format: String input - Date format you will need to check on date type column.
    - timestamp_format: String input - Timestamp format you will need to check on timestamp type column.
    - null_rule_nam - string input - Null check rule name.
    - str_consis_rule_nam - string input - String lenth consistency rule name.
    - str_length_side - string input - String lenth consistency rule's another paramater. Kindly refer DQF document.
    - custom_dtype_rule_nam - string input - Custom data type check rule name.
    - custom_datatype_check_func - string input - Custom data type check function.

  Returns:
    - dictionary: It returns a param dictionary.
  """  
  
  dict_output = {
    'dqf_col_seq_nam':dqf_col_seq_nam,
    'id_obj':id_obj,
    'date_format':date_format,
    'timestamp_format':timestamp_format,
    'null_rule_nam':null_rule_nam,
    'str_consis_rule_nam':str_consis_rule_nam,
    'str_length_side':str_length_side,
    'custom_dtype_rule_nam':custom_dtype_rule_nam
  }

  return dict_output

def get_dynamic_config(df_unique_records:DataFrame,df_col_config:DataFrame,df_rule:DataFrame,df_inf_sch:DataFrame,check_rule_id:dict,typecast_dict:dict,addnl_param_dict:dict,custom_datatype_check_func = custom_check_datatype )->dict:
  """
  This function return config dictionary after using metadata delta tables.

  Input:
    - df_unique_records_final: DataFrame input - This is the table on which you will apply DQF.
    - df_col_config: DataFrame input - This is the configuration metadata table where you will get on which column which function you need to apply.
    - df_rule: DataFrame input - This is the metadata table where all functions rules are defined.
    - df_inf_sch: DataFrame input - This is the information schema data of your targeted table.
    - check_rule_id - Dict input - This dictionary have DQF function name information i.e. rule name and its rule id.
    - typecast_dict - Dictionary input - You need to mention column names on which you will apply DQF along its data type. This information data will be coming from information schema.
    - addnl_param_dict: Dictionary input - It contains all the parameters which will apply DQF 
    - custom_datatype_check_func - string input - Custom data type check function.

  Returns:
    - dictionary: It returns a config dictionary.
  """  

  #getting parameters from additional param dict
  df_unique_records.count()
  date_format = addnl_param_dict['date_format']
  timestamp_format = addnl_param_dict['timestamp_format']
  custom_dtype_rule_nam = addnl_param_dict['custom_dtype_rule_nam']
  null_rule_nam = addnl_param_dict['null_rule_nam']
  str_consis_rule_nam = addnl_param_dict['str_consis_rule_nam']
  str_length_side = addnl_param_dict['str_length_side']
  
  df_col_config = df_col_config.filter(col('col_nam').isin(list(typecast_dict.keys())))
  df_rule_config_join = get_rule_config_join_df(df_col_config,df_rule,config_id_obj=addnl_param_dict['id_obj'])
  df_rule_config_join = update_null_check_info(df_rule_config_join,df_inf_sch,null_id_rule=check_rule_id[null_rule_nam],null_rule_nam=null_rule_nam)
  df_rule_config_join = update_string_length_check(df_rule_config_join,df_col_config,df_rule, df_inf_sch, id_obj =addnl_param_dict['id_obj'],id_rule = check_rule_id[str_consis_rule_nam],length_side = str_length_side)
  config = get_final_config(df_rule_config_join)

  for j in list(set(typecast_dict.values())):
    if j in ('DOUBLE','FLOAT','INT','DECIMAL','SHORT','LONG','BOOLEAN','DATE','TIMESTAMP'):
      id_rule = check_rule_id[custom_dtype_rule_nam]
      df_rule_config_join = update_type_check_info(df_rule_config_join, df_col_config,df_rule, df_inf_sch, id_obj=addnl_param_dict['id_obj'],id_rule=id_rule,type_name=j,typecast_dict=typecast_dict)
      col_list = list(df_rule_config_join.filter(col('id_rule')==id_rule).select('col_nam').first().asDict().values())[0].split(',')
      config = update_custom_config(config,custom_datatype_check_func,cols=col_list,dtype=j.lower(),date_format=date_format, timestamp_format = timestamp_format)
  
  return config
