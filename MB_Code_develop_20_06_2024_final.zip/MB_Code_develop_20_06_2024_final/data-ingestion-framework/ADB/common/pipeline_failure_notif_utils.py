from datetime import datetime
from ADB.common.common_utilities import spark
import json
from ADB.common.notification_utils import generate_required_notifications,send_email,generate_pipeline_failure_notification,generate_pipeline_failure_notification_api_eligibility,generate_pipeline_failure_notification_zip_eligibility

def format_pipeline_trigger_time(pipeline_trigger_time):
    pipeline_trigger_time = pipeline_trigger_time[:pipeline_trigger_time.index('.')]

    pipeline_trigger_time = datetime.strptime(pipeline_trigger_time, "%Y-%m-%dT%H:%M:%S")
    
    formatted_time = pipeline_trigger_time.strftime("%H:%M:%S")
    
    return formatted_time

def parse_error(error_json):
    error_dict = json.loads(error_json)
    activity_name = error_dict.get('activity_name')
    activity_run_id = error_dict.get('activity_runId')
    domain_areas = error_dict.get('domain_areas')
    batch_id = error_dict.get('batch_id')
    
    error_item = f"<b>Domain Area:</b> {domain_areas}<br>"
    error_item += "<ul>"
    error_item += f"<li><b>Batch ID:</b> {batch_id}</li>"
    error_item += f"<li><b>Activity Name:</b> {activity_name}</li>"
    error_item += f"<li><b>Activity Run ID:</b> {activity_run_id}</li>"
    error_item += "</ul><br>"
    
    return error_item

def process_errors(errors_json):
    errors = json.loads(errors_json)
    error_list_items = []
    for error in errors:
        error_list_items.append(parse_error(error))
    return "<br>".join(error_list_items)

def handle_pipeline_failure(eligibility_error, error_list, pipeline_runid, pipeline_name, pipeline_trigger_time):
    if eligibility_error == 'Succeeded':
        notification_status, _ = generate_pipeline_failure_notification(error_list, pipeline_runid, pipeline_name, pipeline_trigger_time)
    elif eligibility_error == 'Failed':
        if 'api' in pipeline_name:
            notification_status, _ = generate_pipeline_failure_notification_api_eligibility(pipeline_runid, pipeline_name, pipeline_trigger_time,'dbx_eligibility_nb')
        else:
            notification_status, _ = generate_pipeline_failure_notification_zip_eligibility(pipeline_runid, pipeline_name, pipeline_trigger_time,'dbx_eligibility_nb')
    return notification_status
