from ADB.common.common_utilities import spark
from delta.tables import DeltaTable
from croniter import croniter,CroniterBadCronError
from datetime import datetime, timedelta
import pytz
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, BooleanType

TIME_ZONE_NAME='America/New_York'

def read_delta_table(table_name,catlg_nam):
  try:
    return spark.read.table(f'`{catlg_nam}`.'+table_name)
  except Exception as e:
    print ('Error:',str(e))

def get_current_datetime():
    est_timezone = pytz.timezone(TIME_ZONE_NAME)
    est_time = datetime.now(est_timezone)
    return est_time

def get_current_date():
    est_timezone = pytz.timezone(TIME_ZONE_NAME)  # Eastern Standard Time (EST)
    est_time = datetime.now(est_timezone)
    return est_time.date()

def get_active_identifiers(metadata_df, id_col="id_src_file"):
    active_identifiers = metadata_df.select(id_col).distinct().collect()
    return [row[id_col] for row in active_identifiers]

def filter_watermark(watermark_df, current_date):
    return watermark_df.where(col("run_dte") == current_date)

def join_watermark_and_metadata(metadata_df, filtered_watermark_df):
    return metadata_df.join(filtered_watermark_df, metadata_df["id_src_file"] == filtered_watermark_df["id_proc"], how="left_anti")

def convert_utc_to_est(trigger_time_utc):
    trigger_time_utc = datetime.strptime(trigger_time_utc, "%Y-%m-%dT%H:%M:%SZ")
    utc_timezone = pytz.timezone('UTC')
    est_timezone = pytz.timezone(TIME_ZONE_NAME)
    trigger_time_est = trigger_time_utc.replace(tzinfo=utc_timezone).astimezone(est_timezone)
    return trigger_time_est

def check_cron_schedule(cron_expression, trigger_time):
    trigger_hour = trigger_time.hour
    trigger_minute = trigger_time.minute

    start_cron_parts = cron_expression["start_cron"].split()[0:2]
    end_cron_parts = cron_expression["end_cron"].split()[0:2]

    start_cron_hour = int(start_cron_parts[1])
    start_cron_minute = int(start_cron_parts[0])

    end_cron_hour = int(end_cron_parts[1])
    end_cron_minute = int(end_cron_parts[0])

    if (trigger_hour == start_cron_hour and trigger_minute == start_cron_minute) or \
       (trigger_hour == end_cron_hour and trigger_minute == end_cron_minute):
        return True
    else:
        return False

def is_trigger_eligible(cron_expression, trigger_time):
    if check_cron_schedule(cron_expression, trigger_time):
        trigger_time += timedelta(seconds=1)
        cron = croniter(cron_expression["start_cron"], trigger_time)
        prev_schedule_datetime = cron.get_prev(datetime)
        return prev_schedule_datetime.date() == trigger_time.date()
    else:
        return False

def filter_metadata_by_domain(metadata_df, domain):
    filtered_df = metadata_df.filter((col("domn_area") == domain) & (col("file_typ") == "delimited"))
    return filtered_df

def filter_eligible_files(metadata_df):
    filtered_df = metadata_df.filter(col("is_eligible") == "true").select(col("id_src_file"))
    return filtered_df

def apply_eligibility_check(row, trigger_time_est):
    return is_trigger_eligible(row['addnl_info'], trigger_time_est)


def process_dataframe_schema(spark, metadata_df, trigger_time_est):
    
    pandas_df = metadata_df.toPandas()
    
    pandas_df['is_eligible'] = pandas_df.apply(lambda row: apply_eligibility_check(row, trigger_time_est), axis=1)

    schema_with_eligibility = StructType(metadata_df.schema.fields + [StructField("is_eligible", BooleanType(), True)])

    metadata_df = spark.createDataFrame(pandas_df,schema_with_eligibility)
    
    return metadata_df 