from pyspark.sql import functions as F

def explode_without_null(dataframe,column_to_be_explode):
  dataframe = dataframe.withColumn(column_to_be_explode, F.explode(column_to_be_explode))
  return dataframe


def explode_with_null(dataframe,column_to_be_explode):
  dataframe = dataframe.withColumn(column_to_be_explode, F.explode_outer(column_to_be_explode))
  return dataframe


def column_mapping(dataframe,column_mapping):
  selected_columns = [
      F.col(column_expr).alias(f"{alias_suffix}")
      for alias_suffix, column_expr in column_mapping.items()
  ]
  df_selected = dataframe.select(*selected_columns)
  return df_selected