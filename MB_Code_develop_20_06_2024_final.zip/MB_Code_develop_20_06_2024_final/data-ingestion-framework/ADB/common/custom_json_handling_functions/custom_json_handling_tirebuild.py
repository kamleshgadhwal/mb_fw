from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType, LongType, BooleanType
from pyspark.sql import types as T
import pyspark.sql.functions as F
from ADB.common.custom_json_handling_functions.tirebuild_utils import explode_with_null, explode_without_null,column_mapping

# COMMAND ----------

def column_length_validation(df_flatten_json): 
    column_length_dict = {
    "ID_USA_VIN": 17,
    "IND_RA_MERC_ORIGNL": 10,
    "NUM_FA_SUPLR_SKU": 13,
    "NUM_FA_TIRE_WDTH": 10,
    "NAM_ERR_LST": 200,
    "NAM_FA_VEND": 55,
    "IND_FA_MERC_ORIGNL": 10,
    "DES_WRN_MSG": 1000,
    "NUM_FA_RIM_DIAMTR": 10,
    "NUM_FA_SIDE_TIRE_SIZE": 55,
    "NUM_MODL_SER": 20,
    "NAM_FA_DSGNTN": 60,
    "NUM_RA_LOAD_IDX": 5,
    "NUM_RA_SUPLR_PART": 10,
    "NUM_FA_ASPT_RTIO": 10,
    "NUM_RA_RIM_DIAMTR": 10,
    "NUM_FA_LOAD_IDX": 5,
    "NUM_FA_SUPLR_PART": 10,
    "DES_ERR_MSG": 1000,
    "NUM_RA_SIDE_TIRE_SIZE": 55,
    "NUM_RA_DIM_SIZE": 11,
    "NUM_RA_SPD_IDX": 5,  
    "NUM_FA_DIM_SIZE": 11,
    "CDE_BAUM": 6,
    "NAM_RA_SEAS": 55,
    "NAM_RA_VEND": 55,
    "NUM_FA_SPD_IDX": 5,
    "NAM_FA_SEAS": 55,
    "NUM_RA_TIRE_WDTH": 10,
    "NUM_RA_GER_PART": 20,
    "NUM_FA_GER_PART": 20,
    "NUM_RA_SUPLR_SKU": 13,
    "NAM_RA_DSGNTN": 60,
    "NUM_RA_ASPT_RTIO": 10
}
    for column, max_length in column_length_dict.items():
        df_flatten_json = df_flatten_json.withColumn(column, F.when(F.length(F.col(column)) > max_length, F.substring(F.col(column), 0, max_length)).otherwise(F.col(column)))
    return df_flatten_json

def get_flatten_json(df_s_i):
    """
  This function will flatten JSON dataframe.

  Input:
    - input_dataframe: PySpark DataFrame where you need to perform this function.

  Returns:
    - df_flatten_json: It returns a flatten JSON from the input dataframe.
  """

    json_schema = StructType([
        StructField("bm6", StringType(), True),
        StructField("exFactory", StructType([
            StructField("error", StructType([
                StructField("errorId", LongType(), True),
                StructField("message", StringType(), True),
                StructField("errorList", StringType(), True)  # Assuming errorList is StringType, update as necessary
            ]), True),
            StructField("tirePairs", ArrayType(StructType([
                StructField("tireFA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True),
                StructField("tireRA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True)
            ]), True)),
            StructField("warnings", ArrayType(StructType([
                StructField("warningId", LongType(), True),
                StructField("message", StringType(), True)
            ])), True)
        ]), True),
        StructField("finOrVin", StringType(), True),
        StructField("modelSeries", StringType(), True),
        StructField("originalVisPlant", StringType(), True),
        StructField("plant", StringType(), True),
        StructField("rrk", StructType([
            StructField("error", StructType([
                StructField("errorId", LongType(), True),
                StructField("message", StringType(), True),
                StructField("errorList", StringType(), True)  # Assuming errorList is StringType, update as necessary
            ]), True),
            StructField("tirePairs", ArrayType(StructType([
                StructField("tireFA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True),
                StructField("tireRA", StructType([
                    StructField("asnr", StringType(), True),
                    StructField("designation", StringType(), True),
                    StructField("dimension", StringType(), True),
                    StructField("ean", StringType(), True),
                    StructField("hasFoamInlay", BooleanType(), True),
                    StructField("isRunflat", BooleanType(), True),
                    StructField("loadIndex", LongType(), True),
                    StructField("moTag", StringType(), True),
                    StructField("profile", StringType(), True),
                    StructField("sda", StringType(), True),
                    StructField("sdb", StringType(), True),
                    StructField("season", StringType(), True),
                    StructField("speedIndex", StringType(), True),
                    StructField("supplierPartNumber", StringType(), True),
                    StructField("vendor", StringType(), True)
                ]), True)
            ]), True)),
            StructField("warnings", ArrayType(StructType([
                StructField("warningId", LongType(), True),
                StructField("message", StringType(), True)
            ])), True)
        ]), True),
        StructField("visFin", StringType(), True),
        StructField("visVin", StringType(), True)
    ])
    array_json_schema = ArrayType(json_schema)

    df_flatten_json = df_s_i.withColumn("json_string", F.from_json(df_s_i["json_string"], array_json_schema))

    df_flatten_json = explode_without_null(df_flatten_json, "json_string")

    column_mapping_dict = {
        "ID_USA_VIN": "json_string.finOrVin",
        "NUM_MODL_SER": "json_string.modelSeries",
        "CDE_BAUM": "json_string.bm6",
        "ID_ERR": "json_string.exFactory.error.errorId",
        "DES_ERR_MSG": "json_string.exFactory.error.message",
        "NAM_ERR_LST": "json_string.exFactory.error.errorList",
        "tirePairs": "json_string.exFactory.tirePairs",
        "warnings": "json_string.exFactory.warnings"
    }
    df_flatten_json = column_mapping(df_flatten_json, column_mapping_dict)

    df_flatten_json = explode_with_null(df_flatten_json, "tirePairs")

    df_flatten_json = explode_with_null(df_flatten_json, "warnings")

    veh_dtl_column_mapping = {
        "ID_USA_VIN": "ID_USA_VIN",
        "NUM_MODL_SER": "NUM_MODL_SER",
        "CDE_BAUM": "CDE_BAUM",
        "ID_ERR": "ID_ERR",
        "DES_ERR_MSG": "DES_ERR_MSG",
        "NAM_ERR_LST": "NAM_ERR_LST",
        "ID_WRN": "warnings.warningId",
        "DES_WRN_MSG": "warnings.message",
        "NUM_FA_GER_PART": "tirePairs.tireFA.asnr",
        "NAM_FA_DSGNTN": "tirePairs.tireFA.designation",
        "NUM_FA_DIM_SIZE": "tirePairs.tireFA.dimension",
        "NUM_FA_LOAD_IDX": "tirePairs.tireFA.loadIndex",
        "NUM_FA_SPD_IDX": "tirePairs.tireFA.speedIndex",
        "NUM_FA_SUPLR_PART": "tirePairs.tireFA.supplierPartNumber",
        "NUM_FA_SUPLR_SKU": "tirePairs.tireFA.ean",
        "NAM_FA_SEAS": "tirePairs.tireFA.season",
        "IND_FA_MERC_ORIGNL": "tirePairs.tireFA.moTag",
        "IND_FA_RUN_FLAT": "tirePairs.tireFA.isRunflat",
        "IND_FA_SOUND_INSULTN": "tirePairs.tireFA.hasFoamInlay",
        "NAM_FA_VEND": "tirePairs.tireFA.vendor",
        "NUM_FA_SIDE_TIRE_SIZE": "tirePairs.tireFA.profile",
        "NUM_RA_GER_PART": "tirePairs.tireRA.asnr",
        "NAM_RA_DSGNTN": "tirePairs.tireRA.designation",
        "NUM_RA_DIM_SIZE": "tirePairs.tireRA.dimension",
        "NUM_RA_LOAD_IDX": "tirePairs.tireRA.loadIndex",
        "NUM_RA_SPD_IDX": "tirePairs.tireRA.speedIndex",
        "NUM_RA_SUPLR_PART": "tirePairs.tireRA.supplierPartNumber",
        "NUM_RA_SUPLR_SKU": "tirePairs.tireRA.ean",
        "NAM_RA_SEAS": "tirePairs.tireRA.season",
        "IND_RA_MERC_ORIGNL": "tirePairs.tireRA.moTag",
        "IND_RA_RUN_FLAT": "tirePairs.tireRA.isRunflat",
        "IND_RA_SOUND_INSULTN": "tirePairs.tireRA.hasFoamInlay",
        "NAM_RA_VEND": "tirePairs.tireRA.vendor",
        "NUM_RA_SIDE_TIRE_SIZE": "tirePairs.tireRA.profile",
    }

    df_flatten_json = column_mapping(df_flatten_json, veh_dtl_column_mapping)

    df_flatten_json = df_flatten_json.filter(F.col('ID_USA_VIN').isNotNull())

    df_flatten_json = df_flatten_json.dropDuplicates(['ID_USA_VIN'])

    df_flatten_json = df_flatten_json.withColumn("NUM_FA_TIRE_WDTH", F.split(F.col("NUM_FA_DIM_SIZE"), "/")[0])
    df_flatten_json = df_flatten_json.withColumn("NUM_FA_ASPT_RTIO",
                                                 F.split(F.split(F.col("NUM_FA_DIM_SIZE"), "/")[1], ' ')[0])
    df_flatten_json = df_flatten_json.withColumn("NUM_FA_RIM_DIAMTR",
                                                 F.split(F.split(F.col("NUM_FA_DIM_SIZE"), "/")[1], 'R')[1])

    df_flatten_json = df_flatten_json.withColumn("NUM_RA_TIRE_WDTH", F.split(F.col("NUM_RA_DIM_SIZE"), "/")[0])
    df_flatten_json = df_flatten_json.withColumn("NUM_RA_ASPT_RTIO",
                                                 F.split(F.split(F.col("NUM_RA_DIM_SIZE"), "/")[1], ' ')[0])
    df_flatten_json = df_flatten_json.withColumn("NUM_RA_RIM_DIAMTR",
                                                 F.split(F.split(F.col("NUM_RA_DIM_SIZE"), "/")[1], 'R')[1])
    df_flatten_json=column_length_validation(df_flatten_json)
    return df_flatten_json