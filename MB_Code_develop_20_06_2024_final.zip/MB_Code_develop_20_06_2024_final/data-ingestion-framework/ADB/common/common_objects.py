from pyspark.sql import SparkSession

def get_spark():
    """
    This function creates and returns the spark object.

    Input:
    - 
     Returns:
    - created spark object.
    """
    spark = SparkSession.getActiveSession()
    try:
        if spark == None:
            
            spark_obj = SparkSession.builder.master("local[1]").getOrCreate()
            print("creating SparkSession object")
        else:
            spark_obj = spark
            print("using available SparkSession object")
    except Exception:
        print("creating SparkSession object")
        
        spark_obj = SparkSession.builder.master("local[1]").getOrCreate()

    return spark_obj

def get_dbutils():
    """
    This function returns the dbutils object.

    Input:
    - 
     Returns:
    - created dbutils object.
    """
    dbutils_obj = None
    
    try:
        dbutils_obj = dbutils
    except Exception:
        from pyspark.dbutils import DBUtils  # noqa
        dbutils_obj = DBUtils(get_spark()) if "dbutils" not in locals() else locals().get("dbutils")
        return dbutils_obj
 