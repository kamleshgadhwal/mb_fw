# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

######################################### Import Libraries ######################################
from pyspark.sql.functions import col,lit, max, explode
from datetime import datetime, date, timedelta
import re

from ADB.common.common_utilities import custom_merge_data_into_delta
from ADB.common.user_details import get_audit_user
from ADB.common.metadata_operations import get_dbutils_widgets,get_master_details_with_filter
from ADB.common.watermark_utils import Watermark, insert_error_into_watermark
from ADB.common.config import OPER_PHASE_BRONZE_TO_SILVER,OPER_STAT_DICT,INFORMATION_SCHEMA_TABLE, MAPPING_TABLE_NAME,SILVER_AUDIT_COLUMNS,BRONZE_AUDIT_COLUMNS,catlg_nam,wm_tabl_nam,LAYER_TABLE_NAME,OPER_PHASE_LANDING_TO_BRONZE,COLUMN_ENRICH_TABLE_NAME,DEPENDENCY_TABLE_NAME
from ADB.common.metadata_operations import get_bad_dup_records,get_good_dup_records,column_casting,insert_audit_columns,rename_columns_using_mapping_table,latest_bronze_data_using_watermark, get_silver_schema_records, get_col_enrich_list, get_enrich_col, final_col_enrich,custom_json_handling,final_upload_csv_to_volume,move_temp_file,insert_watermark_with_error,framwork_cstom_error
from ADB.common.schema_validation import check_schema_validation
from ADB.common.gold_layer_utils import execute_gold_layer,run_notebook
from ADB.common.notification_utils import generate_required_notifications_bad_records

# COMMAND ----------

############################## Read parameters and set variables #################################
watermark_dict  = get_dbutils_widgets(dbutils)
id_src_file = watermark_dict.get('id_src_file')
lvl_lyr = watermark_dict.get('lvl_lyr')
filename = watermark_dict.get('filename')
filepath = watermark_dict.get('filepath')
id_batch = watermark_dict.get('id_batch')
domn_area = watermark_dict.get('domn_area')

proc_started_ts = datetime.now()
user_name = get_audit_user(dbutils)
run_date=datetime.strptime(re.search(r'\d{8}', filename).group(), '%Y%m%d').date() 
v_oper_phase = OPER_PHASE_BRONZE_TO_SILVER
v_oper_stat = OPER_STAT_DICT.get('init')
watermark_dict.update({'id_batch':id_batch,'proc_started_ts':proc_started_ts,'run_date':run_date, 'oper_phase':v_oper_phase,'user_name':user_name, 'oper_stat':v_oper_stat,'inp_nam':filename,'inp_typ':filename.split('.')[-1]})

# COMMAND ----------

############################### Initial Entry to Watermark Table to In_Progress Status ########################################
o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()

# COMMAND ----------

#################################### Read Layer Master Table #########################################
lm_condition = {'id_src_file':id_src_file,'lvl_lyr':lvl_lyr}
lm_filter_row, lm_flag ,read_error_lm = get_master_details_with_filter(catlg_nam, LAYER_TABLE_NAME,lm_condition)

if lm_flag == False:
  error_message = 'No data found in Layer Master : ' + str(lm_condition)
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)
  


# COMMAND ----------

########################## Read Latest Bronze Data using watermark last entry #########################
wm_condition = {'oper_phase':v_oper_phase, 'opr_stat':1, 'inp_nam':lm_filter_row.get('src_loc')}
df_bronze,bronze_data_flag, bronze_data_error = latest_bronze_data_using_watermark(catlg_nam, wm_tabl_nam, lm_filter_row.get('src_loc'), wm_condition)
if bronze_data_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),bronze_data_error)


# COMMAND ----------

###################### Rename Bronze Table Columns using Mapping Details Table ########################
df_bronze_rename,column_rename_falg,column_rename_error = rename_columns_using_mapping_table(df_bronze, catlg_nam, MAPPING_TABLE_NAME,lm_filter_row.get('mapping_id'))
if column_rename_falg==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),column_rename_error)

# COMMAND ----------

########################## Adding Column Enrich using fw_col_enrich table #########################
df_bronze_rename, col_enrich_error = final_col_enrich(df_bronze_rename,catlg_nam,COLUMN_ENRICH_TABLE_NAME, lm_filter_row)
if col_enrich_error:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),col_enrich_error)

# COMMAND ----------

##########################################CUSTOM JSON HANDLING #############################################################
if lm_filter_row.get('addnl_info', {}).get('custom_json_functionname') is not None and lm_filter_row.get('addnl_info')['custom_json_handling'].upper()=='TRUE':
  df_bronze_rename,custon_json_handled_falg, custom_json_error=custom_json_handling(lm_filter_row.get('addnl_info', {}).get('custom_json_functionname'),df_bronze_rename)
  if custon_json_handled_falg==False:
    insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),custom_json_error)
  

# COMMAND ----------

############## Drop Extra columns from Bronze Table using Information Schema Table ####################
df_bronze_drop,typecast_dict , silver_schema_records_flag,silver_schema_records_error = get_silver_schema_records(df_bronze_rename, catlg_nam,lm_filter_row.get('tgt_nam'), INFORMATION_SCHEMA_TABLE, SILVER_AUDIT_COLUMNS,BRONZE_AUDIT_COLUMNS)
if silver_schema_records_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),silver_schema_records_error)


# COMMAND ----------

############################### Remove Duplicate Records using Key columns ############################
df_good_records_dup , good_dup_records_flag, good_dup_records_errr= get_good_dup_records(df_bronze_drop, lm_filter_row.get('addnl_info'))  
if good_dup_records_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),good_dup_records_errr)

# COMMAND ----------

# ########################################## Fetch Duplicate Records using Key columns #########################################
df_bad_records_dup = get_bad_dup_records(df_bronze_drop, df_good_records_dup)


# COMMAND ----------

#################################### Perform Schema Validation ########################################
if lm_filter_row.get('qlty_chk')==True:
  df_good_records_schema, df_bad_records_schema, schema_error = check_schema_validation(df_good_records_dup,typecast_dict,lm_filter_row.get('addnl_info', {}).get('timestamp_format'),lm_filter_row.get('addnl_info', {}).get('date_format'))
  if schema_error:
    insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),schema_error)
else:
  df_good_records_schema=df_good_records_dup
  df_bad_records_schema=None

# COMMAND ----------

############################ Perform Typecasting on Good Bronze DataFrame #############################
if lm_filter_row.get('qlty_chk')==True:
  df_final_typecasted,column_casting_flag,column_cating_error = column_casting(df_good_records_schema, typecast_dict,lm_filter_row.get('addnl_info', {}).get('timestamp_format'),lm_filter_row.get('addnl_info', {}).get('date_format'))
  if column_casting_flag==False:
    insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),column_cating_error)
else:  
  df_final_typecasted=df_good_records_schema

# COMMAND ----------

################# Upsert records into Target Silver Table using Key Columns ###########################
merge_error, merge_stats,df_final = custom_merge_data_into_delta(catlg_nam,df_final_typecasted, lm_filter_row, BRONZE_AUDIT_COLUMNS)

if merge_stats.get('merge_status') == False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),merge_error)

# COMMAND ----------

################# Insert bad records into mentioned ADLS path in Layer Master #########################
if df_bad_records_schema is not None:
  df_bad_records = df_bad_records_dup.union(df_bad_records_schema)
  df_bad_records = df_bad_records.withColumns({'rundate':lit(watermark_dict.get('run_date')), 'created_timestamp':lit(watermark_dict.get('proc_started_ts'))})
  if(watermark_dict.get('filename').split('.')[-1])=='json':
    watermark_dict.update({'filepath':filepath+datetime.now().strftime("%m-%d-%Y/%H_%M_%S")})
  insert_bad_records_status,temp_bad_records_path  = final_upload_csv_to_volume(df_bad_records,watermark_dict,folder_name='bad_records',volume_position=5,date_position=6,time_position=7)
  move_file_status,bad_records_path = move_temp_file(temp_bad_records_path,filename)

  input_count = df_bronze.count()
  rejected_count = df_bad_records.count()

  if rejected_count>0:
    notification_status,error_message = generate_required_notifications_bad_records(domn_area, filename, input_count, rejected_count,bad_records_path)
    if notification_status == False:
      insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

################# Update watermark table after insertion of data into Silver Table #####################
watermark_dict['inp_typ'] = lm_filter_row.get('src_typ')
watermark_dict['inp_nam'] = lm_filter_row.get('src_loc')
watermark_dict['tgt_nam'] = lm_filter_row.get('tgt_nam')
watermark_dict['oper_stat'] = OPER_STAT_DICT.get('finished')
watermark_dict['in_cnt'] = df_bronze.count()
watermark_dict['out_cnt'] = df_final.count()
watermark_dict['ins_cnt'] = int(merge_stats.get('numTargetRowsInserted'))
watermark_dict['upd_cnt'] = int(merge_stats.get('numTargetRowsUpdated'))

o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()

# COMMAND ----------

################# Gold Layer Procesing  #####################
t_d_metadata= spark.read.format("delta").table(catlg_nam+'.'+DEPENDENCY_TABLE_NAME)
silver_layer_tbl = lm_filter_row.get('tgt_nam')
execute_gold_layer(t_d_metadata,silver_layer_tbl,dbutils)
