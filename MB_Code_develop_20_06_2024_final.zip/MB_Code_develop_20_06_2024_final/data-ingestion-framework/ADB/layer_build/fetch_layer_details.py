# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from pyspark.sql.functions import col
from ADB.common.common_utilities import read_delta_table
from ADB.common.metadata_operations import filter_dataframe,framwork_cstom_error
from ADB.common.file_consitency_utility import identify_pattern_from_filename,concatenate_columns_convert_to_list
from ADB.common.config import FILEMASTER_TABLE_NAME,LAYER_TABLE_NAME, catlg_nam,wm_tabl_nam

dbutils.widgets.text("filename","")
dbutils.widgets.text("filepath","")
filename = dbutils.widgets.get("filename")
filepath = dbutils.widgets.get("filepath")

# COMMAND ----------

# DBTITLE 1,Static table values
#static configuration
file_master = FILEMASTER_TABLE_NAME
layer_master = LAYER_TABLE_NAME
to_be_selected_cols = ["id_src_file","lvl_lyr","prcs_nbk"]

# COMMAND ----------

# DBTITLE 1,Resolve file name format
# Identify file pattern pattern
input_filename = filename
input_filename_pattern = identify_pattern_from_filename(input_filename)

# COMMAND ----------

# DBTITLE 1,Create file_metadata lookup json
filter_filename_pattern_dict = {"operator" : "==", "ref_value" : input_filename_pattern}
filter_cond_dict = {}
filter_cond_dict['nam_src_file'] = filter_filename_pattern_dict

# COMMAND ----------

# DBTITLE 1,Reading metadata tables
df_f_m = read_delta_table(FILEMASTER_TABLE_NAME,catlg_nam)
df_l_m = read_delta_table(LAYER_TABLE_NAME,catlg_nam)

# COMMAND ----------

# DBTITLE 1,Filter file metadata
df_f_m_filter = filter_dataframe(df_f_m,filter_cond_dict)

# COMMAND ----------

# DBTITLE 1,Create layer_metadata lookup json
filter_id_src_file_dict = {"operator" : "==", "ref_value" : df_f_m_filter.collect()[0][0]}
filter_cond_dict = {}
filter_cond_dict['id_src_file'] = filter_id_src_file_dict

# COMMAND ----------

# DBTITLE 1,filter layer_metadata
df_l_m_filter = filter_dataframe(df_l_m,filter_cond_dict)
df_l_m_filter=df_l_m_filter.orderBy(col('lvl_lyr'))

# COMMAND ----------

# DBTITLE 1,Select specific columns
df_l_m_filter_final = df_l_m_filter.select(*to_be_selected_cols)



# COMMAND ----------

# DBTITLE 1,Create a list concatenating selected columns
list_concat_cols,concat_col_flag, concat_col_error= concatenate_columns_convert_to_list(df_l_m_filter_final,"~")
if concat_col_flag==False:
  error_message = 'Concatenated list of columns is empty'
  raise framwork_cstom_error(error_message)

# COMMAND ----------

# DBTITLE 1,Exit notebook
dbutils.notebook.exit(list_concat_cols)
