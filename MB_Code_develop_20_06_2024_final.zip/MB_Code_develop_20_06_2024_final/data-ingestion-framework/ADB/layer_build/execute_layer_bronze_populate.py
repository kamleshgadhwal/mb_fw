# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

######################################### Import Libraries ######################################
from datetime import datetime, date, timedelta
import re
from pyspark.sql.functions import explode,lit
from ADB.common.metadata_operations import get_dbutils_widgets,get_master_details_with_filter,get_upload_extra_missing_cols,framwork_cstom_error,insert_watermark_with_error
from ADB.common.config import OPER_PHASE_LANDING_TO_BRONZE,OPER_STAT_DICT,catlg_nam,wm_tabl_nam,FILEMASTER_TABLE_NAME,INFORMATION_SCHEMA_TABLE,LAYER_TABLE_NAME,MAPPING_TABLE_NAME,SILVER_AUDIT_COLUMNS,COLUMN_ENRICH_TABLE_NAME
from ADB.common.watermark_utils import Watermark,insert_error_into_watermark
from ADB.common.file_consitency_utility import is_file_readable,df_read_file,insert_data_to_delta_table
from ADB.common.common_utilities import read_delta_table
from ADB.common.user_details import get_audit_user
from ADB.common.pre_process_utils import string_value_modifier
from ADB.common.config import LANDING_PATH_DICT
from ADB.common.notification_utils import generate_required_notifications_schema_evolution

# COMMAND ----------

############################## Read parameters and set variables #################################
watermark_dict  = get_dbutils_widgets(dbutils)
id_src_file = watermark_dict.get('id_src_file')
lvl_lyr = watermark_dict.get('lvl_lyr')
filename = watermark_dict.get('filename')
filepath = watermark_dict.get('filepath')
id_batch = watermark_dict.get('id_batch')
domn_area = watermark_dict.get('domn_area')

user_name = get_audit_user(dbutils)
run_date = datetime.strptime(re.search(r'\d{8}', filename).group(), '%Y%m%d').date()         
proc_started_ts = datetime.now()
v_oper_phase = OPER_PHASE_LANDING_TO_BRONZE
v_oper_stat = OPER_STAT_DICT.get('init')
modified_filepath = string_value_modifier(filepath,LANDING_PATH_DICT)
filepath_mnt=modified_filepath+filename
watermark_dict.update({'id_batch':id_batch,'proc_started_ts':proc_started_ts,'run_date':run_date, 'oper_phase':v_oper_phase,'user_name':user_name, 'oper_stat':v_oper_stat,'inp_nam':filename,'inp_typ':filename.split('.')[-1]})

# COMMAND ----------

##################################### Initaial watermark entry with operation in-progress  #####################################
o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()

# COMMAND ----------

#################################### Read File Master Table ######################################
fm_filter_condition = {'id_src_file':id_src_file}
fm_filter_row, fm_flag , read_error_lm = get_master_details_with_filter(catlg_nam, FILEMASTER_TABLE_NAME ,fm_filter_condition)

if fm_flag == False:
  error_message = 'No data found in File Master : ' + str(fm_filter_condition) + read_error_lm
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

file_type = fm_filter_row.get('file_typ')

# COMMAND ----------

################################## Check File is readable or not #################################
is_readable, error_details = is_file_readable(filepath_mnt,header=True , num_lines_to_read=3, file_type=file_type)

if is_readable == False:
  error_message = 'File is not readable : ' + str(filepath_mnt) + error_details
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

################################# Create Dataframe frome File ####################################
df_landing, df_create_status, read_error = df_read_file(file_type, filepath_mnt, watermark_dict.get('inp_typ'))

if df_create_status == False:
  error_message = 'Dataframe is not created for file  : ' + str(filepath_mnt) + read_error
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

############ Identify Bad Records (Landing table having Extra columns or Missing Columns) #########
if file_type.upper() != 'JSON':
  upload_status , flagged_record_flag, flagged_record_error = get_upload_extra_missing_cols(df_landing,catlg_nam,wm_tabl_nam,INFORMATION_SCHEMA_TABLE,LAYER_TABLE_NAME,MAPPING_TABLE_NAME,COLUMN_ENRICH_TABLE_NAME,SILVER_AUDIT_COLUMNS,watermark_dict)

  if flagged_record_flag==False:
    raise framwork_cstom_error(flagged_record_error)

# COMMAND ----------

################################## Read Layer master ##############################################
lm_condition = {'id_src_file':id_src_file,'lvl_lyr':lvl_lyr}
lm_filter_row, lm_flag , read_error_lm= get_master_details_with_filter(catlg_nam, LAYER_TABLE_NAME,lm_condition)

if lm_flag == False:
  error_message = 'No data found in Layer Master : ' + str(lm_condition) + read_error_lm
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

############################# Notification trigger for Schema Evolution ###############################
df_landing_columns = df_landing.columns
notification_status,error_message = generate_required_notifications_schema_evolution(lm_filter_row['tgt_nam'],df_landing_columns,domn_area, filename)
if notification_status == False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

######################### Insert Audit column into Landing Table for Bronze #######################
rundate = datetime.strptime(re.search(r'\d{8}', filename).group(), '%Y%m%d').date()
           
created_timestamp= datetime.now()
df_audit=df_landing.withColumns({'rundate':lit(rundate), 'created_timestamp':lit(created_timestamp)})

# COMMAND ----------

################################ Insert records into Bronze table ##################################
insert_status, insert_error = insert_data_to_delta_table(df_audit,lm_filter_row.get('tgt_nam'), catlg_nam)

if insert_status == False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

# COMMAND ----------

##################### Update watermark table after insert data into bronze table ###################
watermark_dict['inp_typ'] = lm_filter_row.get('src_typ')
watermark_dict['inp_nam'] = lm_filter_row.get('src_loc')
watermark_dict['tgt_nam'] = lm_filter_row.get('tgt_nam')
watermark_dict['oper_stat'] = OPER_STAT_DICT.get('finished')
watermark_dict['in_cnt'] = df_landing.count()
watermark_dict['out_cnt'] = df_audit.count()

o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()
