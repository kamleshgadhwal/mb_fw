# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from datetime import datetime, date
from pyspark.sql.functions import col

from ADB.common.user_details import get_audit_user
from ADB.common.pre_process_utils import get_zip_file_metadata,string_value_modifier,get_latest_wm_zip_details,extract_specific_file
from ADB.common.watermark_utils import Watermark, insert_error_into_watermark
from ADB.common.config import OPER_PHASE_UNZIP,OPER_STAT_DICT,LANDING_PATH_DICT,catlg_nam,wm_tabl_nam,LAYER_TABLE_NAME
from ADB.common.metadata_operations import get_dbutils_widgets,get_master_details_with_filter,remove_zipfile,framwork_cstom_error,insert_watermark_with_error

# COMMAND ----------

######################################### Import Libraries #########################################
from datetime import datetime, date
from pyspark.sql.functions import col
 
############################## Read parameters and set variables ###################################
layer = 'landing'
watermark_dict = get_dbutils_widgets(dbutils,layer)
id_src_file = watermark_dict.get('id_src_file')
lvl_lyr = watermark_dict.get('lvl_lyr')
filename = watermark_dict.get('filename')
filepath = watermark_dict.get('filepath')
id_batch = watermark_dict.get('id_batch')
 
user_name = get_audit_user(dbutils)
proc_started_ts = datetime.now()
run_date = date.today()
v_oper_phase = OPER_PHASE_UNZIP
v_oper_stat = OPER_STAT_DICT.get('init')
watermark_dict.update({'id_src_file':id_src_file,'proc_started_ts':proc_started_ts,'run_date':run_date, 'oper_phase':v_oper_phase,'user_name':user_name, 'oper_stat':v_oper_stat,'inp_nam':filename,'inp_typ':filename.split('.')[-1]})

# COMMAND ----------

##################################### Insert watermark table #########################################
o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()

# COMMAND ----------

################################## Map landing path ###################################################
landing_path = string_value_modifier(filepath,LANDING_PATH_DICT)
prefix_landing_path = '/Volumes/' + catlg_nam + landing_path
zip_meta_dict = {}
zip_meta_dict['src_loc'] = prefix_landing_path
zip_meta_dict['tgt_nam'] = prefix_landing_path + 'landing' + '/' + datetime.now().strftime("%m-%d-%Y/%H_%M_%S") + '/'

# COMMAND ----------

################################## Get Zip Metadata Details ###########################################
full_zip_file_path =  prefix_landing_path + filename
df_metadata_zip,zip_dict,zip_metadata_flag,zip_meta_data_error = get_zip_file_metadata(full_zip_file_path)
if zip_metadata_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),zip_meta_data_error)

# COMMAND ----------

######################## Getting last succesfull watermark entry for the day ##########################
df_to_be_unzip,unzip_flag, unzip_error = get_latest_wm_zip_details(catlg_nam, wm_tabl_nam, df_metadata_zip,watermark_dict)
if unzip_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),unzip_error)
 


# COMMAND ----------

######## Extract specific files

total_file_extracted, files_unzipped, list_extracted_file,extract_flag,extract_error = extract_specific_file(zip_meta_dict,filename, df_to_be_unzip )
if extract_flag==False:
  insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),extract_error)

# COMMAND ----------

###############Apply the Encryption with Landing Layer ###################
from ADB.common.common_utilities import read_delta_table
from ADB.common.config import catlg_nam


encrypt_tabl_nam = '`xtous_us_12_test_framework`.`encryption_meta`'
df_encrypt_meta=read_delta_table(encrypt_tabl_nam,catlg_nam)
df_encrypt_meta.display()

# COMMAND ----------

from pyspark.sql.functions import udf,col,from_json
from pyspark.sql.types import StringType
import obfuskator_rust
import os
from ADB.common.common_utilities import read_delta_table
from ADB.common.config import LAYER_TABLE_NAME,catlg_nam,RSA_KEY_PATH,COLUMN_TAGS_TABLE_NAME
from ADB.common.file_consitency_utility import df_read_file
from ADB.common.metadata_operations import framwork_cstom_error

# COMMAND ----------


RSA_KEY_PATH = '/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/'

def get_rsa_key_file(domain = '',extension = 'pem'):
  """
    Retrieves the path of the RSA key file for a given domain.

    Input:
        domain (str): The domain for which the RSA key file is needed.
                      Defaults to an empty string.
        extension (str): The extension of the RSA key file.
                         Defaults to 'pem'.

    Returns:
        str: The path of the RSA key file for the specified domain.
             Returns None if no RSA key file is found.
  """
  file_path = RSA_KEY_PATH
  if domain != '':
    file_path = RSA_KEY_PATH+'/'+domain+'/'
  files = os.listdir(file_path)
  files_with_extension = [file for file in files if file.endswith(extension)]
  if len(files_with_extension)==0:
    return None
  return file_path+files_with_extension[0]

# COMMAND ----------

# from ADB.common.pii_utils import get_rsa_key_file
# # key_path=get_rsa_key_file()
# # key_path

# COMMAND ----------

def encrypt_rsa_deterministic(input):
    """
    Encrypts the input data using RSA encryption in a deterministic manner.

    Input:
        input (bytes): The input data to be encrypted.

    Returns:
        bytes: The encrypted data.
    """
    key_path = get_rsa_key_file()
    pseudonymize_private_key = obfuskator_rust.rsa.PrivateKey.load_from_file(key_path,"pkcs1","pem")
    public_key = pseudonymize_private_key.public_key
    if (not input):
     return input
    else:
     return public_key.encrypt_deterministic(input)

# COMMAND ----------

def create_encrypted_dataframe(df_source,pii_column_list):
  """
    Encrypts personally identifiable information (PII) columns in a DataFrame using RSA deterministic encryption.

    Input:
        df_source (DataFrame): Source DataFrame containing PII columns.
        pii_column_list (list): List of column names containing PII to be encrypted.

    Returns:
        DataFrame: New DataFrame with PII columns encrypted.

    """
  
  try:
      rsa_encrypt_deterministic = udf(encrypt_rsa_deterministic, StringType())
      for column_name in pii_column_list:
          df_source = df_source.withColumn(column_name, rsa_encrypt_deterministic(df_source[column_name]))
      return df_source
  except Exception as e:
      print("Error occurred during DataFrame encryption:", e)
      return None

# COMMAND ----------

def encrypt_file_data(filepath,file_type,columns_list):
  """
    Encrypts personally identifiable information (PII) columns in a file.

    Input:
        filepath (str): Path to the file to be encrypted.
        columns_list (list): List of column names containing PII to be encrypted.

    Returns:
        tuple: A tuple containing the following elements:
            - DataFrame or None: Encrypted DataFrame if successful, None if unsuccessful.
            - bool: True if encryption is successful, False otherwise.
            - str: Success message if successful, error message if unsuccessful.

    """
  try:
    df_file, df_create_status, read_error = df_read_file(file_type, filepath)
    if not df_create_status:
        return None, False, read_error
    df_encrypted = create_encrypted_dataframe(df_file, columns_list)
    if df_encrypted:
        return df_encrypted, True, 'Success'
    else:
        raise framwork_cstom_error('Unable to encrypt the data')
  except Exception as e:
    return None, False, f'Error occurred during file encryption: {str(e)}'

# COMMAND ----------

# df_encry,_,_=encrypt_file_data('/Volumes/eastus2_extollo_ms_us_edwdev_adbv/xtous_us_12_test_framework/test-landing-zone/landing/05-13-2024/02_35_07/orders_20240509.csv','delimited',['fname'])

# COMMAND ----------

################# Update watermark table after insertion of data into Silver Table #####################
watermark_dict['inp_typ'] = 'zip'
watermark_dict['inp_nam'] = prefix_landing_path
watermark_dict['tgt_nam'] = files_unzipped
watermark_dict['addnl_info'] = zip_dict
watermark_dict['out_cnt'] = total_file_extracted
watermark_dict['in_cnt'] = len(zip_dict)
 
if total_file_extracted >= 1:
  watermark_dict["oper_stat"] = OPER_STAT_DICT.get('finished')
else:
  watermark_dict["oper_stat"] = OPER_STAT_DICT.get('other')

o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()

# COMMAND ----------

# ############################# Exit Notebook with list of extarcted files ###############################
if len(list_extracted_file)==0:
  error_message = 'list of files to extracted is empty'
  raise framwork_cstom_error(error_message)
dbutils.notebook.exit(';'.join(map(str, list_extracted_file)))
