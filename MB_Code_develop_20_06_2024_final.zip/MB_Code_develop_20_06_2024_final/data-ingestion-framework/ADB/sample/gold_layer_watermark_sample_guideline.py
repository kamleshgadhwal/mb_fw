# Databricks notebook source
# MAGIC %md
# MAGIC This notebook guides you how watermark entry will be inserted/updated into watermark table.

# COMMAND ----------

# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

# DBTITLE 1,Importing Utilities Functions
from ADB.common.gold_layer_utils import resolve_dependency_watermark,execute_gold_layer,run_notebook, final_gold_lyr_watermark_dict
import pyspark.sql.functions as F
from datetime import datetime
from ADB.common.config import catlg_nam,DEPENDENCY_TABLE_NAME,wm_tabl_nam,OPER_STAT_DICT
from ADB.common.watermark_utils import Watermark, insert_error_into_watermark
from ADB.common.user_details import get_audit_user

# COMMAND ----------

# DBTITLE 1,Getting inputs
#In below function, we are getting the current user name.
user_name = get_audit_user(dbutils)

#This is the table on which Gold Layer processing will be start.
# successor_name = 'xtous_us_12_test_framework.test_gold_orders_table'
successor_name = 'xtous_us_12_test_framework.test_gold_sales_table'

DEPENDENCY_TABLE_NAME ='`xto-us-12_data-ingestion-control-tables`.`fw_tbl_dep`'
wm_tabl_nam = '`xto-us-12_data-ingestion-control-tables`.`fw_watermark`'

# COMMAND ----------

# DBTITLE 1,Getting watermark dictionary using dependency and other metadata tables
watermark_dict = final_gold_lyr_watermark_dict(successor_name, user_name, DEPENDENCY_TABLE_NAME,wm_tabl_nam)
msg_flag = False

# If all the dependencies will be pass then watermark's operation status code will be 5 (does not have impact on it) else code will be 0 which indicate the dependecies not statisfied.
# And you can exit from the notebook with 0 operation status code.
if watermark_dict['oper_stat'] != OPER_STAT_DICT.get('init'):
  if watermark_dict.get('addnl_info'):
    if watermark_dict.get('addnl_info').get('msg'):
      exit_message = watermark_dict.get('addnl_info').get('msg')
      msg_flag = True

  if msg_flag == False:
    exit_message = 'Dependency partically satisfied'

  #Insert this current watermark dictionary entry into watermark table.
  watermark_obj = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
  watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = watermark_obj.watermark_init_upsert()

  #After watermark entry, notebook will be exit.
  dbutils.notebook.exit(exit_message) 

# COMMAND ----------

# DBTITLE 1,Insert watermark entry in the watermark table using watermark dictionary
watermark_obj = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = watermark_obj.watermark_init_upsert()
df_watermark_read.display()

# COMMAND ----------

# DBTITLE 1,Update your watermark entry after getting some error in your notebook using below code
try:
  # This is a dummy code. This code will be replaced by your original gold layer code.
  a = 1
  b = 0
  print(a/b)
except Exception as e:
  error_message = str(e)
  error_code = OPER_STAT_DICT.get('error')
  watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = insert_error_into_watermark(
    catlg_nam, wm_tabl_nam, watermark_dict, error_code,error_message
  )

# COMMAND ----------

# DBTITLE 1,Update your watermark entry after successfull completion of your notebook using below code
watermark_dict['oper_stat'] = OPER_STAT_DICT.get('finished')
watermark_obj = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = watermark_obj.watermark_init_upsert()
df_watermark_read.display()

# COMMAND ----------

# DBTITLE 1,Note
# You cannot run both the piece of code which are present in cell number 8 and 9. 
# You must ensure either cell 8 will ran or cell 9.
# Cell number 5,6,7 must be call before cell 8 or 9.

# COMMAND ----------

# DBTITLE 1,Watermark Operation Status Code Journey
# When your notebook starts then watermark's operation status code will be 5.
# Then it will check dependencies of Gold Layer Table inside the function final_gold_lyr_watermark_dict. If all the dependencies will be pass then watermark's operation status code will be 5 (does not have impact on it) else code will be 0 which indicate the dependecies not statisfied.
# And you can exit from the notebook with 0 status code.
# Also, if you have encounter any error while executing notebook cell then operation code will be change to 9 using cell number 8.
# And you can exit from the notebook with 9 status code.
# If your notebook successfully completed all the cells without any error then operation code will be change to 1 using cell number 9.
# And you can exit from the notebook with 1 status code.
