# Databricks notebook source
# MAGIC %md
# MAGIC <B>We have maintained the pseudocode below for encrypting data while loading it into either of the three layers - Landing/Bronze/Silver</B>
# MAGIC
# MAGIC <B>This pseucoce is actually the reference peace with some detailed informational comments to enable data onboarding team with the possible ideas around handling PII with Framework 2.0</B>
# MAGIC
# MAGIC <B>It will use a utility file which contains some basic methods around PII handling. Again this is just an ideation of how to probably acieve the sensitive data encryption using Obfuskator library from MBUSA side.</B>

# COMMAND ----------

# DBTITLE 1,Ingestion to Landing
#Read zip file
#Check metadata and identify new or modified file within the zip
#Dump the new or modified files in the landing
#For reference of above steps : ingestion/dbx_zip_eligibility_check notebook

#For the list of new modified files check what all required column level encryption

#importing functions from pii_utils
from ADB.common.pii_utils import gets_encrypt_file_columns_list,encrypt_file_data,move_temp_part_file

files_list = ['dummy_path/filename1.csv','dummy_path/filename2.csv']
for filepath in files_list : 
  columns_list = gets_encrypt_file_columns_list(filepath)
  encrypted_file_df,status,error_msg = encrypt_file_data(filepath,columns_list)
  #Customize error handling

  #creating temp path for saving the dataframe
  filename = filepath.split('/')[-1]
  temp_file_path = filename.split('.csv')[0]+'_temp'
  #writing the dataframe in temp location
  encrypted_file_df.coalesce(1).write.option("header",True).mode("overwrite").csv(temp_file_path)
  #finally overwriting the file with updated encrypted data
  status,final_path = move_temp_part_file(temp_file_path,filename)


# COMMAND ----------

# DBTITLE 1,Landing to Brone
# Data file is read from the landing zone - executable notebook
# Check the encryption flag in the layer master table, to check if encryption required at this layer

from ADB.common.pii_utils import check_encryption_flag,get_pii_columns_list,create_enrcypted_dataframe

encryption_flag = check_encryption_flag(target_table_name)

if encryption_flag:
    # Get the list of columns for which column-level encryption needs to be done
    pii_column_list = get_pii_columns_list(target_table_name)
    if len(pii_column_list)>0:
        #Create updated encrypted data
        df_encrypted = create_enrcypted_dataframe(df_source,pii_column_list)
    else:
        print('No column for encryption')
        
# Finally, write the data to the delta table
#Current Layer build notebook for landing to bronze without encryption : layer_build/execute_layer_bronze_populate

# COMMAND ----------

# DBTITLE 1,Bronze to Silver
# First, we will get the list of PII columns in the silver target table

from ADB.common.pii_utils import check_encryption_flag,get_pii_columns_list,create_enrcypted_dataframe,create_decrypted_dataframe

pii_column_list = get_pii_columns_list(target_table_name)

# Then we will check if the encryption flag is true in the layer master table
encryption_flag = check_encryption_flag(target_table_name)

# Read the source bronze table into a dataframe
if not encryption_flag and len(pii_column_list)>0:
    # Apply schema renaming function to map it from bronze to target silver table
    # Decrypt the data to facilitate data quality checks etc.
    df_bronze = create_decrypted_dataframe(df_bronze,pii_column_list)
    # Apply data quality checks

# Final step is to encrypt the PII columns before loading in silver delta tables
df_bronze = create_enrcypted_dataframe(df_bronze,pii_column_list)

# Finally, write the data to the silver delta table
#Current Layer build notebook for bronze to silver without encryptionk : layer_build/execute_layer_silver_populate
