# Databricks notebook source
# MAGIC %md
# MAGIC Using DQF, We are checking column is nullable or not, raw data is compatible with target table schema or not and string length check for any string type column.
# MAGIC
# MAGIC We are mocking all the data in the below cells but while integration of this DQF, you have to fetch data from delta tables.
# MAGIC
# MAGIC We are using information schema for getting dynamic information about target table schema then we will use that schema for building config for DQF. 

# COMMAND ----------

secret = dbutils.secrets.get(scope="daps-kv", key="pid7bb5-azdotoken")
package = "data-quality-framework-dev"

# COMMAND ----------
# MAGIC %md
# MAGIC this installation of library should happen before executeing the notebook
# MAGIC pip install --extra-index-url https://{secret}@pkgs.dev.azure.com/daimler/_packaging/DataQualityFramework/pypi/simple/ {package}

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Import utility functions
from ADB.common.user_details import get_audit_user
from ADB.common.config import catlg_nam

from pyspark.sql.types import StructField, StructType, MapType, LongType, IntegerType,TimestampType, StringType
import datetime

# COMMAND ----------

# DBTITLE 1,Get pre requisites
#Target table name.
id_obj = 'test_silver_orders_table'

# Catalog Name
catalog_name = catlg_nam

# Fetching user name
user_name = get_audit_user(dbutils)

# COMMAND ----------

# DBTITLE 1,Importing Source Data (Mocked)
#This is the dataframe on which you will apply DQF.

import datetime

df_unique_records_data = [
  ('Ajay', 'Singh', '12', '900', 'Offline', '27-12-2023', '2', 'Ajay Singh'), 
  ('Kamlesh', 'Kumar', '31', '500', 'Online', 'corrupt DATE', '2', 'Kamlesh Kumar'), 
  ('Kamlesh', 'Kumar', '34', '700', 'Online', '27-12-2023', '10', 'Kamlesh Kumar'), 
  ('Kapil', 'Sharma', '23', '600', 'Online', '27-12-2023', '4', 'Kapil Sharma'), 
  ('Manish', 'Kamboj', '56', '1000', 'Offline', '26-12-2023', '1', 'Manish Kamboj'), 
  ('Nirnab', 'Chowdhury', '25', '300', 'Online', '28-12-2023', '1', 'Nirnab Chowdhury'), 
  ('Raj', 'Mishra', '34', '800', 'Offline', '27-12-2023', '4', 'Raj Mishra'), 
  ('Souvik', 'Nag', '21', '400', 'Online', '27-12-2023', '3', 'Souvik Nag'), 
  ('Usama', 'Shahid', '12', '900', 'Offline', '27-12-2023', '6', 'Usama Shahid'), 
  ('Usama', 'Shahid', 'ABC', '200', 'Online', '28-12-2023', '1', 'Usama Shahid')
]

df_unique_records_schema = StructType(
  [
    StructField('fname', StringType(), False), 
    StructField('lname', StringType(), False), 
    StructField('age', StringType(), False), 
    StructField('orderAmount', StringType(), True), 
    StructField('orderChannel', StringType(), True), 
    StructField('orderDate', StringType(), True), 
    StructField('orderQuantity', StringType(), True), 
    StructField('full_name', StringType(), False)
  ]
)

df_unique_records = spark.createDataFrame(df_unique_records_data, df_unique_records_schema)
df_unique_records.display()

# COMMAND ----------

# DBTITLE 1,Importing Information schema data (Mocked)
# You can get information schema data using below mention function from dqf_utils module. We are mocking information schema data.
# df_inf_sch_schema = get_information_schema_df(catalog_name=catalog_name,table_name=your_target_table_name)

import datetime

df_inf_sch_schema = StructType(
  [
    StructField('table_catalog', StringType(), False), 
    StructField('table_schema', StringType(), False), 
    StructField('table_name', StringType(), False), 
    StructField('column_name', StringType(), False), 
    StructField('ordinal_position', IntegerType(), False), 
    StructField('column_default', StringType(), True), 
    StructField('is_nullable', StringType(), False), 
    StructField('full_data_type', StringType(), False), 
    StructField('data_type', StringType(), False), 
    StructField('character_maximum_length', LongType(), True), 
    StructField('character_octet_length', LongType(), True), 
    StructField('numeric_precision', IntegerType(), True), 
    StructField('numeric_precision_radix', IntegerType(), True), 
    StructField('numeric_scale', IntegerType(), True), 
    StructField('datetime_precision', IntegerType(), True), 
    StructField('interval_type', StringType(), True), 
    StructField('interval_precision', IntegerType(), True), 
    StructField('maximum_cardinality', LongType(), True), 
    StructField('is_identity', StringType(), False), 
    StructField('identity_generation', StringType(), True), 
    StructField('identity_start', StringType(), True), 
    StructField('identity_increment', StringType(), True), 
    StructField('identity_maximum', StringType(), True), 
    StructField('identity_minimum', StringType(), True), 
    StructField('identity_cycle', StringType(), True), 
    StructField('is_generated', StringType(), False), 
    StructField('generation_expression', StringType(), True), 
    StructField('is_system_time_period_start', StringType(), False), 
    StructField('is_system_time_period_end', StringType(), False), 
    StructField('system_time_period_timestamp_generation', StringType(), True), 
    StructField('is_updatable', StringType(), False), 
    StructField('partition_index', IntegerType(), True), 
    StructField('comment', StringType(), True)
  ]
)

df_inf_sch_data = [
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'full_name', 2, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'fname', 0, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderQuantity', 7, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'updated_timestamp', 10, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderAmount', 4, None, 'YES', 'decimal(10,0)', 'DECIMAL', None, None, 0, 10, 0, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderChannel', 5, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'age', 3, None, 'YES', 'int', 'INT', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'created_timestamp', 9, None, 'YES', 'timestamp', 'TIMESTAMP', None, None, None, None, None, 3, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None),
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'lname', 1, None, 'YES', 'string', 'STRING', 0, 0, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'rundate', 8, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None), 
  ('eastus2_extollo_ms_us_edwdev_adbv', 'xtous_us_12_test_framework', 'test_silver_orders_table', 'orderDate', 6, None, 'YES', 'date', 'DATE', None, None, None, None, None, None, '', None, None, 'NO', None, None, None, None, None, None, 'NO', None, 'NO', 'NO', None, 'YES', None, None)
]

df_inf_sch = spark.createDataFrame(df_inf_sch_data, df_inf_sch_schema)
df_inf_sch.display()

# These are the columns which needs to be evaluated in DQF. 
# These information coming from information schema table (catalog_name.information_schema.columns table) after removing audit columns. 
typecast_dict = {'full_name': 'STRING','fname': 'STRING','orderQuantity': 'INT','orderAmount': 'DECIMAL','orderChannel': 'STRING','age': 'INT','lname': 'STRING','orderDate': 'DATE'}

# COMMAND ----------

# DBTITLE 1,Importing dq_rule Table (Mocked)
# You can fetch this rule records from eastus2_extollo_ms_us_edwdev_adbv.xto-us-12_data-ingestion-control-tables.dq_rule table. 
# catalog_name = 'eastus2_extollo_ms_us_edwdev_adbv'
# tbl_dq_rule = 'xto-us-12_data-ingestion-control-tables.dq_rule table'
# df_rule = read_delta_table(tbl_dq_rule,catalog_name)

import datetime

df_rule_schema = StructType(
  [
    StructField('id_rule', LongType(), True), 
    StructField('rule_nam', StringType(), True), 
    StructField('rule_args', StringType(), True), 
    StructField('rule_des', StringType(), True), 
    StructField('dts_dw_crea', TimestampType(), False), 
    StructField('id_dw_crea_user', StringType(), False), 
    StructField('dts_dw_updt', TimestampType(), False), 
    StructField('id_dw_updt_user', StringType(), False)
  ]
)

df_rule_data = [
  (1013, 'custom_check_datatype', None, 'checking datatype', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI', datetime.datetime(2024, 4, 5, 9, 42, 38, 793000), 'USSHAHI'), 
  (1002, 'check_string_consistency', 'string_length,method', 'checking length of a string', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI'), 
  (1003, 'check_null', None, 'checking column have null values or not', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 14, 58, 861000), 'USSHAHI')
]

df_rule = spark.createDataFrame(df_rule_data, df_rule_schema)
df_rule.display()

#These are the rule ids dict which are coming from dq_rule table. 
check_rule_id = {'check_null':1003,'check_string_consistency':1002,'custom_check_datatype':1013} 

# COMMAND ----------

# DBTITLE 1,Importing dq_col_config data (Mocked)
# You can fetch this rule records from eastus2_extollo_ms_us_edwdev_adbv.xto-us-12_data-ingestion-control-tables.dq_col_config table. 
# catalog_name = 'eastus2_extollo_ms_us_edwdev_adbv'
# tbl_dq_col_config = 'xto-us-12_data-ingestion-control-tables.dq_rule dq_col_config'
# df_rule = read_delta_table(tbl_dq_col_config,catalog_name) 

import datetime

df_col_config_schema = StructType(
  [
    StructField('id_config', LongType(), True), 
    StructField('id_obj', StringType(), False), 
    StructField('obj_des', StringType(), False), 
    StructField('col_nam', StringType(), True), 
    StructField('kwargs_lst', MapType(StringType(), StringType(), True), True), 
    StructField('id_rule', IntegerType(), False), 
    StructField('dts_dw_crea', TimestampType(), False), 
    StructField('id_dw_crea_user', StringType(), False), 
    StructField('dts_dw_updt', TimestampType(), False), 
    StructField('id_dw_updt_user', StringType(), False)
    ]
)

df_col_config_data = [
  (8, 'test_silver_orders_table', 'this is orders sample table', 'fname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 7, 53, 725000), 'USSHAHI'), 
  (6, 'test_silver_orders_table', 'this is orders sample table', 'lname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
  (5, 'test_silver_orders_table', 'this is orders sample table', 'fname', None, 1003, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI'), 
  (4, 'test_silver_orders_table', 'this is orders sample table', 'lname', {'string_length': '5', 'method': 'max'}, 1002, datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI', datetime.datetime(2024, 3, 26, 16, 8, 13, 399000), 'USSHAHI')
]

df_col_config = spark.createDataFrame(df_col_config_data, df_col_config_schema)
df_col_config.display()

# COMMAND ----------

# DBTITLE 1,Adding Row Id
# df_unique_records - This is the last dataframe after performaing all the transformation like removing duplicate records, removing extra columns, column mapping etc. 

# Row id column name which will be added in the source dataframe.
# We need this column to identify the rows easily in bad records dataframe becuase some row comes multiple time in the bad record dataframe later.
dqf_col_seq_nam = 'dqf_custom_row_id'

#This function will add dqf_col_seq_nam column into df_unique_records_final dataframe.
from ADB.common.dqf_utils import get_row_id
df_unique_records_final = get_row_id(df_unique_records,dqf_col_seq_nam=dqf_col_seq_nam)
df_unique_records_final.display()

# COMMAND ----------

# DBTITLE 1,Generating Dynamic Config
# get_dynamic_config - Using this function, you will get config dictionary which will be used in DQF class.

#######################################Input Parameters Definitions##############################################

# df_unique_records_final: DataFrame input - This is the table on which you will apply DQF.
# df_col_config: DataFrame input - This is the configuration metadata table where you will get on which column which function you need to apply.
# df_rule: DataFrame input - This is the metadata table where all functions rules are defined.
# df_inf_sch: DataFrame input - This is the information schema data of your targeted table.
# date_format: String input - Date format you will need to check on date type column.
# timestamp_format: String input - Timestamp format you will need to check on timestamp type column.
# check_rule_id - Dict input - This dictionary have DQF function name information i.e. rule name and its rule id.
# dqf_col_seq_nam - String input - Row id column name.
# typecast_dict - Dictionary input - You need to mention column names on which you will apply DQF along its data type. This information data will be coming from information schema.
# id_obj - string input - Target table name. This entry must be present in dq_col_config.
# null_rule_nam - string input - Null check rule name.
# str_consis_rule_nam - string input - String lenth consistency rule name.
# str_length_side - string input - String lenth consistency rule's another paramater. Kindly refer DQF document.
# custom_dtype_rule_nam - string input - Custom data type check rule name.
# custom_datatype_check_func - string input - Custom data type check function.

from ADB.common.dqf_utils import get_dynamic_config, custom_check_datatype, get_parameter_dict

addnl_param_dict = get_parameter_dict(
                            dqf_col_seq_nam,
                            id_obj,
                            date_format='dd-MM-yyyy', 
                            timestamp_format = None,
                            null_rule_nam = 'check_null',
                            str_consis_rule_nam = 'check_string_consistency',
                            str_length_side = 'max', 
                            custom_dtype_rule_nam = 'custom_check_datatype'                            
                            )

config = get_dynamic_config(df_unique_records_final,
                            df_col_config,
                            df_rule,
                            df_inf_sch,
                            check_rule_id,
                            typecast_dict, 
                            addnl_param_dict,
                            custom_datatype_check_func = custom_check_datatype
                            )

# COMMAND ----------

# DBTITLE 1,Apply DQF
from datetime import datetime
from dqf.main import CheckProject

#Schema where some of DQF results will be store.
result_schema_name = 'xtous_us_12_test_framework' 

#This is the path where bad records will be store in delta format.  This path information will coming from layer master or bad record path dynamic logic.
bad_record_path = f'/Volumes/{catalog_name}/{result_schema_name}/test-landing-zone/dqf/{str(datetime.now().date())}' 

checkProj = CheckProject(
        config=config,
        dataframe=df_unique_records_final,
        on_dbfs=True,
        write_results=True,
        unity_catalog=True, 
        result_path=f'{catalog_name}.{result_schema_name}',
        failed_data_path=bad_record_path,
        result_format="delta",
        failed_data_format="delta"
)

checkProj.run()
result = checkProj.check_results

# COMMAND ----------

# DBTITLE 1,Fetching Good and Bad Records
#All the corrupt records found in this dataframe after performing DQF.

from ADB.common.dqf_utils import get_failed_records_df, get_good_records
df_bad_records = get_failed_records_df(dfq_results=result) 
df_bad_records.display()

#All the good row after eleminating bad records.
df_good_records = get_good_records(df_unique_records_final,df_bad_records,dqf_col_seq_nam) 
df_good_records.display()

# COMMAND ----------

# DBTITLE 1,Fetching DQF custom report
from datetime import datetime
from ADB.common.dqf_utils import get_aggregate_dfq_report, get_check_fail_df

current_ts = datetime.now()

#DQF aggregated result for this execution.
df_agg = get_aggregate_dfq_report(checkProj,id_obj,dqf_col_seq_nam,df_bad_records,current_ts,current_user=user_name,bad_rcd_path=bad_record_path)
df_agg.display() 

#Detailed DQF failed record information per column per function.
df_chk_fail = get_check_fail_df(checkProj,df_rule,current_ts,current_user=user_name) 
df_chk_fail.display()

#Both the dataframe will be store in thier respective dataframes.

# COMMAND ----------

# DBTITLE 1,Fetching DQF performance and other report
#Detailed DQF results per column per function.
df_check_results = checkProj.df_check_results
df_check_results.display()

#DQF performance report for this execution.
df_profile_results = checkProj.df_profile_results 
df_profile_results.display()

#You can find these result into result_path which we have mentioned in the DQF (CheckProject) class.
