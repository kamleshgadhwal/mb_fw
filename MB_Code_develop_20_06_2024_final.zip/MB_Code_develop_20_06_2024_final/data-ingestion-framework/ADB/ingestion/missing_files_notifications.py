# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from ADB.common.missing_file_notify_utils import read_delta_table,get_current_date,get_current_datetime,get_active_identifiers,filter_watermark,join_watermark_and_metadata,convert_utc_to_est,check_cron_schedule,is_trigger_eligible,filter_metadata_by_domain,filter_eligible_files,apply_eligibility_check,process_dataframe_schema
from ADB.common.watermark_utils import insert_error_into_watermark,Watermark
from ADB.common.notification_utils import generate_missing_files_notification,generate_required_notifications,send_email
from ADB.common.config import FILEMASTER_TABLE_NAME,catlg_nam,wm_tabl_nam,OPER_STAT_DICT
from pyspark.sql.functions import col,when,expr,lit
from croniter import croniter,CroniterBadCronError
from pyspark.sql.types import BooleanType,IntegerType
from datetime import datetime,timedelta
from pyspark.sql.functions import pandas_udf, col
import pandas as pd
import pytz
from pyspark.sql.types import StructType, StructField, StringType, MapType
from datetime import datetime, date, timedelta

# COMMAND ----------

dbutils.widgets.text("domain","")
domain = dbutils.widgets.get("domain")
dbutils.widgets.text("trigger_time","")
trigger_time = dbutils.widgets.get("trigger_time")

# COMMAND ----------

metadata_df = read_delta_table(FILEMASTER_TABLE_NAME,catlg_nam)

# COMMAND ----------

metadata_df = filter_metadata_by_domain(metadata_df, domain)

# COMMAND ----------

trigger_time_est = convert_utc_to_est(trigger_time)

# COMMAND ----------

metadata_df = process_dataframe_schema(spark, metadata_df, trigger_time_est)

# COMMAND ----------

current_date = get_current_date()
metadata_df = filter_eligible_files(metadata_df)

# COMMAND ----------

watermark_df = read_delta_table(wm_tabl_nam,catlg_nam)
filtered_watermark_df = filter_watermark(watermark_df, current_date)
metadata_df = join_watermark_and_metadata(metadata_df, filtered_watermark_df)

# COMMAND ----------

missing_files =get_active_identifiers(metadata_df)

# COMMAND ----------

missing_files =get_active_identifiers(metadata_df)
notification_status,error_message = generate_missing_files_notification(trigger_time,missing_files,domain)
