# COMMAND ----------
returnValue={'status': 'Succeeded','filename':'testfileone_20240124.json'}
dbutils.notebook.exit(returnValue)