# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

# Databricks notebook source
import os
from ADB.common.common_objects import get_spark,get_dbutils
from ADB.tire_build_utils.api_config_transform import get_api_config,get_auth_data,get_vin_list,generate_header,time,get_load_query,save_api_response,create_adw_connection,execute_queries_for_extract,get_api_response_batch,get_run_date
from ADB.common.config import landing_storage_path 

# COMMAND ----------



# COMMAND ----------


# COMMAND ----------
dbutils = get_dbutils()
api_config_dict=get_api_config(dbutils)

# COMMAND ----------

# DBTITLE 1,Generate  Access Token Request Headers And
data={'client_id':api_config_dict.get('client_id'),'client_secret':api_config_dict.get('client_secret'),'grant_type':api_config_dict.get('grant_type')}
auth_data=get_auth_data(api_config_dict.get('auth_url'),data)
access_token=auth_data.get("access_token")
headers=generate_header(access_token)
expire_time=auth_data.get("expires_in")
current_time = time.time()
token_expire_time=expire_time+current_time

# COMMAND ----------


run_date = get_run_date()

# COMMAND ----------

dbutils.widgets.text("input_text", "100000", "Batch Size")
batch_size = int(dbutils.widgets.get("input_text"))

# COMMAND ----------

dbutils.widgets.text("input_time", "60", "time_interval")
time_interval = int(dbutils.widgets.get("input_time"))

# COMMAND ----------

incremental_query=get_load_query("incremental")
incremental_query=incremental_query.format(run_date)
jdbc_url, connection_properties=create_adw_connection(dbutils)
incremental_data_df=execute_queries_for_extract(jdbc_url,connection_properties,incremental_query)

# COMMAND ----------

vins_data_list=get_vin_list(incremental_data_df,"incremental")

# COMMAND ----------

if len(vins_data_list) == 0:
  exit_msg = "No records found for {0}".format(run_date)
  returnValue={'Exit Status': exit_msg}
  dbutils.notebook.exit(returnValue)

# COMMAND ----------

api_response_generator=get_api_response_batch(api_config_dict,data,headers,token_expire_time,time_interval,vins_data_list,batch_size)

# COMMAND ----------

for api_data in api_response_generator:
  api_response=api_data[0]
  file_name = save_api_response(api_response,landing_storage_path,run_date,"incremental",dbutils)

# COMMAND ----------

returnValue={'status': 'Succeeded','filename':file_name}
dbutils.notebook.exit(returnValue)
