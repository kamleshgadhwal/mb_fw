# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from ADB.common.config import catlg_nam, wm_tabl_nam
from ADB.common.compare_zip_metadata import compare_last_updated_ts_with_watermark

# COMMAND ----------

last_updated_ts_zip = dbutils.widgets.get("last_modified_zip_ts")
zip_file_id = dbutils.widgets.get("zip_file_id")
zip_file_name = dbutils.widgets.get("zip_file_name")

# COMMAND ----------

compare_status = compare_last_updated_ts_with_watermark(last_updated_ts_zip, zip_file_id,zip_file_name,catlg_nam, wm_tabl_nam)
dbutils.notebook.exit(compare_status)
