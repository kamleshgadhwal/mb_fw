# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"
# MAGIC

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from ADB.common.pipeline_failure_notif_utils import format_pipeline_trigger_time,process_errors,handle_pipeline_failure

# COMMAND ----------

dbutils.widgets.text("eligibility_error","")
eligibility_error = dbutils.widgets.get("eligibility_error")

# COMMAND ----------

dbutils.widgets.text("foreach_error","")
foreach_error = dbutils.widgets.get("foreach_error")

# COMMAND ----------

dbutils.widgets.text("pipeline_runid","")
pl_runid = dbutils.widgets.get("pipeline_runid")

# COMMAND ----------

dbutils.widgets.text("pipeline_name","")
pl_name = dbutils.widgets.get("pipeline_name")

# COMMAND ----------

dbutils.widgets.text("pipeline_trigger_time","")
pl_trigger_time  = dbutils.widgets.get("pipeline_trigger_time")

# COMMAND ----------

pl_trigger_time = format_pipeline_trigger_time(pl_trigger_time)

# COMMAND ----------

error_list = process_errors(foreach_error)
print(error_list)

# COMMAND ----------

notification_status = handle_pipeline_failure(eligibility_error, error_list, pl_runid, pl_name, pl_trigger_time)

print(notification_status)

