# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from datetime import datetime, date
import re
from ADB.common.watermark_utils import Watermark
from ADB.common.config import catlg_nam,wm_tabl_nam,OPER_STAT_DICT,RETRY_COUNT
from ADB.common.metadata_operations import get_dbutils_widgets,framwork_cstom_error,insert_watermark_with_error
from ADB.common.user_details import get_audit_user
from ADB.common.notification_utils import get_api_failure_retry_count,generate_api_failure_notification
from ADB.common.watermark_utils import insert_error_into_watermark

# COMMAND ----------

watermark_dict  = get_dbutils_widgets(dbutils,'pre-processing')

id_batch = watermark_dict.get('id_batch')
oper_phase = watermark_dict.get('oper_phase')
oper_stat = watermark_dict.get('oper_stat')
id_src_file = watermark_dict.get('id_src_file')
domn_area = watermark_dict.get('domn_area')
nam_src_file = watermark_dict.get('nam_src_file')

user_name = get_audit_user(dbutils)
proc_started_ts = datetime.now()
if nam_src_file.split('.')[-1].upper() == 'JSON':
  run_date = datetime.strptime(re.search('\d{8}', nam_src_file).group(), "%Y%m%d").date()
if nam_src_file.split('.')[-1].upper() == 'ZIP':
  run_date = datetime.strptime(re.search(r'\d{4}-\d{2}-\d{2}', nam_src_file).group(), "%Y-%m-%d").date()
addnl_info={'zip_last_updated_ts':str(proc_started_ts).split('.')[0]}

watermark_dict.update({'proc_started_ts':proc_started_ts,'run_date':run_date, 'user_name':user_name,'addnl_info':addnl_info,'inp_nam':nam_src_file,'inp_typ':nam_src_file.split('.')[-1]})

# COMMAND ----------

if oper_stat == '0':
  error_status = 0
  addnl_info['retry_count'],error_message = get_api_failure_retry_count(id_src_file,oper_phase)
  if addnl_info['retry_count'] is None:
    error_status = 1
  else:  
    notification_status,error_message = generate_api_failure_notification(addnl_info['retry_count'],id_src_file,domn_area)
    print(error_message)
    if notification_status == False:
      error_status = 1
  if error_status == 1:
    if 'retry_count' not in watermark_dict['addnl_info']:
      addnl_info['retry_count'] = RETRY_COUNT
      watermark_dict.update({'addnl_info':addnl_info})

    insert_watermark_with_error(catlg_nam, wm_tabl_nam, watermark_dict, OPER_STAT_DICT.get('error'),error_message)

watermark_dict.update({'addnl_info':addnl_info})

# COMMAND ----------

##################################### Insert watermark table #########################################
o = Watermark(watermark_dict=watermark_dict, catlg_nam=catlg_nam, watermark_table=wm_tabl_nam)
watermark_insert_flag,watermark_insert_error, df_watermark_read, df_watermark_insert = o.watermark_init_upsert()
df_watermark_read.display()
