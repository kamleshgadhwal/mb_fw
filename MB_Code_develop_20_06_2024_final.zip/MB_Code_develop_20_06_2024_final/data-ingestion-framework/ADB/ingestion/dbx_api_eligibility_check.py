# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from pyspark.sql.functions import col, udf  
from pyspark.sql.types import BooleanType

from ADB.common.zip_api_utility_functions import read_delta_table, get_current_date, process_api_file, check_cron_schedule, active_api_details
from ADB.common.config import FILEMASTER_TABLE_NAME,catlg_nam,wm_tabl_nam
from ADB.common.metadata_operations import framwork_cstom_error


# COMMAND ----------

df_filemaster_api = read_delta_table(FILEMASTER_TABLE_NAME,catlg_nam)
df_filemaster_api.display()

# COMMAND ----------

current_date = get_current_date()


# COMMAND ----------

df_filtered_apis = process_api_file(df_filemaster_api, current_date,wm_tabl_nam,catlg_nam)
df_filtered_apis.display()


# COMMAND ----------
df_filtered_apis=df_filtered_apis.filter(col("id_src_file")=='ftb_oneapi_response_api')
list_op = active_api_details(df_filtered_apis)
if len(list_op)==0:
  error_message = 'Extracted list of active api is empty'
  raise framwork_cstom_error(error_message)
returnValue = ';'.join(map(str, list_op))


# COMMAND ----------

dbutils.notebook.exit(returnValue)
