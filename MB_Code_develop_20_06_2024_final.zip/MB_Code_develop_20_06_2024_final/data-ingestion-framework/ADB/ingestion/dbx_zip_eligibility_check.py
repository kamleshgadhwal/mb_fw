# Databricks notebook source
# MAGIC %run "/Repos/DAPS-Data-Ingestion-Framework/data-ingestion-framework/ADB/common/custom_module_location"

# COMMAND ----------

import sys
sys.path.append(module_path)

# COMMAND ----------

from pyspark.sql.functions import col, udf  
from pyspark.sql.types import BooleanType

from ADB.common.zip_api_utility_functions import read_delta_table,read_filtered_table,get_active_zip_details,update_dates_in_dict_list
from ADB.common.config import FILEMASTER_TABLE_NAME,catlg_nam,FILE_TYPE_ZIP
from ADB.common.metadata_operations import framwork_cstom_error

# COMMAND ----------

df_filemaster_api = read_delta_table(FILEMASTER_TABLE_NAME,catlg_nam)
df_filemaster_api.display()

# COMMAND ----------

df_filtered_zip_details = read_filtered_table(df_filemaster_api,FILE_TYPE_ZIP)
df_filtered_zip_details.display()

# COMMAND ----------

active_zip_files_list = get_active_zip_details(df_filtered_zip_details)
if len(active_zip_files_list) == 0:
  error_message = 'Extracted list of active zip file is empty'
  raise framwork_cstom_error(error_message)
active_zip_dict = update_dates_in_dict_list(active_zip_files_list)
returnValue = ';'.join(map(str, active_zip_dict))


# COMMAND ----------

dbutils.notebook.exit(returnValue)
