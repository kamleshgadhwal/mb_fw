# Databricks notebook source
import os


# COMMAND ----------

catalog = os.environ.get("CATALOG_NAME")
catalog


# COMMAND ----------

spark.sql(f"use catalog {catalog}")


# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('schema evolution', 'Generic_Domain', 'info', '1', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Data quality issues', 'Generic_Domain', 'info', '2', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Data quality issues', 'Generic_Domain', 'info', '3', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Data quality issues', 'Generic_Domain', 'info', '4', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('api failure', 'Generic_Domain', 'info', '5', '"dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com","atcs.ag.garg@mbusa.com","nagarro.s.singh@mbusa.com"', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Missing file scenerio', 'Generic_Domain', 'info', '6', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Pipeline failure notification', 'Generic_Domain', 'info', '7', '"dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com","atcs.ag.garg@mbusa.com","nagarro.s.singh@mbusa.com"', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK'); 

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Pipeline failure notification due to API eligibility notebook failure', 'Generic_Domain', 'info', '8', '"dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com","atcs.ag.garg@mbusa.com","nagarro.s.singh@mbusa.com"', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_notif_dtls
# MAGIC (notif_typ, domain, msg_typ, msg_tmplt_id, recpnt_email_addr_list, dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('Pipeline failure notification due to zip eligibility notebook failure', 'Generic_Domain', 'info', '9', 'dw_171_mbusa-daps-atcs-alerts@mercedes-benz.com', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('1', '{"subject":"Schema Inconsistency-{env} | {domain} | {filename} | {current_date}".format(env="Prod",domain="Generic_Domain",filename=filename,current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> Schema change observed since last run.Please refer below details - <br><br> Additional columns received: <b>{additional_columns}</b> <br><br> Missing columns : <b>{missing_columns} </b> <br><br> Thanks & Regards,<br>Framework Team".format(additional_columns=extra_cols,missing_columns=missing_cols)}','schema_evaluation_template','env,domain,filename,current_date,additional_columns,missing_columns', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('2', '{"subject":"Data Quality Issues -{env} | {domain} | {filename} | {current_date}".format(env="Prod",domain="Generic_Domain",filename=filename,current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> Incoming file is having data quality issues.Please refer below details - <br><br>Total input records : <b>{tot_input_records}</b> <br> Total rejected records : <b>{tot_rejected_records} </b> <br><br> Thanks & Regards,<br>Framework Team".format(tot_input_records=input_count,tot_rejected_records=rejected_count)}','data_quality_issue_template','env,domain,filename,current_date,tot_input_records,tot_rejected_records', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('3', '{"subject":"Data Quality Issues -{env} | {domain} | {filename} | {current_date}".format(env="Prod",domain="Generic_Domain",filename=filename,current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> Incoming file is having data quality issues.Please refer below details and the attached report for quality issues - <br><br> Total input records : <b>{tot_input_records}</b> <br> Total rejected records : <b>{tot_rejected_records}</b> <br><br>{attachment_text} <br><br> Thanks & Regards,<br>Framework Team".format(tot_input_records=input_count,tot_rejected_records=rejected_count,attachment_text= attachment_body}','data_quality_issue_template','env,domain,filename,current_date,tot_input_records,tot_rejected_records', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('4', '{"subject":"Data Quality Issues -{env} | {domain} | {filename} | {current_date}".format(env="Prod",domain="Generic_Domain",filename=filename,current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> Incoming file is having data quality issues.Please refer below details - <br><br> Total input records : <b>{tot_input_records}</b> <br> Total rejected records : <b>{tot_rejected_records}</b> <br> Refer bad record path for details : <b>{bad_record_path}</b> <br><br> Thanks & Regards,<br>Framework Team".format(tot_input_records=input_count,tot_rejected_records=rejected_count,bad_record_path=bad_record_path)}','data_quality_issue_template_bad_records','env,domain,filename,current_date,tot_input_records,tot_rejected_records', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('5', '{"subject":"API Failure-{env} | {domain} | {filename} | {current_date}".format(env="Prod",domain="tirebuild",filename=filename,current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> API pull failed and did not succeed even after <b>{retry_count}<b> retries. <br><br> Thanks & Regards,<br>Framework Team".format(retry_count=retry_count)}','api_failure_template','env,domain,filename,current_date,retry_count', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('6', '{"subject":"Missing File Issues -{env} | {domain} | {current_date}".format(env="Prod",domain="Generic_Domain",current_date=current_date), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> Below are the files that were expected to arrive by <b>{trigger_time}</b> execution, but havenot arrived so far - <br><br> <b>{List_of_files}</b> <br><br> Please note that file ingestion process is an hourly process and will pull these files if available in the next execution. <br><br> Thanks & Regards,<br>Framework Team".format(trigger_time=trigger_time,List_of_files=missing_files)}','Missing_files_issues_records','env,domain,current_date,trigger_time', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user) VALUES ('7', '{"subject":"Pipeline failure notification -{env} | {current_date} | {pipeline_trigger_time}".format(env="Prod",current_date=current_date,pipeline_trigger_time=pipeline_trigger_time), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> The pipeline <b>{pipeline_name}</b> with runid : <b>{pipeline_runid}</b> failed.The following errors occurred for the below mentioned domain areas :<br><br>{error_list}<br><br> Thanks & Regards,<br>Framework Team".format(pipeline_runid=pipeline_runid,pipeline_name=pipeline_name,error_list=error_list)}','Pipeline failure notifications','env,current_date,pipeline_runid,pipeline_name,pipeline_trigger_time', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('8', '{"subject":"Pipeline failure notification -{env} | {current_date} | {pipeline_trigger_time}".format(env="Prod",current_date=current_date,pipeline_trigger_time=pipeline_trigger_time), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> The pipeline <b>{pipeline_name}</b> with runid : <b> {pipeline_runid}</b> failed in activity {activity_name} while fetching configurations for eligible APIs to pull data for. <br><br> Thanks & Regards,<br>Framework Team".format(pipeline_runid=pipeline_runid,pipeline_name=pipeline_name,activity_name=activity_name)}','Pipeline failure notifications due to eligibility notebook failure','env,current_date,pipeline_runid,pipeline_name,pipeline_trigger_time,activity_name', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_email_tmplts
# MAGIC (id, email_tmplt, desc, params,dts_dw_crea, id_dw_crea_user, dts_dw_updt,id_dw_updt_user)
# MAGIC VALUES
# MAGIC ('9', '{"subject":"Pipeline failure notification -{env} | {current_date} | {pipeline_trigger_time}".format(env="Prod",current_date=current_date,pipeline_trigger_time=pipeline_trigger_time), "email_body":"<center>Automated Mail</center> <br> Hello Team,<br><br> The pipeline <b>{pipeline_name}</b> with runid : <b> {pipeline_runid}</b> failed in activity {activity_name} while fetching configurations for eligible zip to pull data for. <br><br> Thanks & Regards,<br>Framework Team".format(pipeline_runid=pipeline_runid,pipeline_name=pipeline_name,activity_name=activity_name)}','Pipeline failure notifications due to eligibility notebook failure','env,current_date,pipeline_runid,pipeline_name,pipeline_trigger_time,activity_name', CURRENT_TIMESTAMP,'FRAMEWORK',CURRENT_TIMESTAMP,'FRAMEWORK');

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog 'eastus2_extollo_ms_us_edwdev_adbv';

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW INSERT Select * FROM MyTable WHERE ID = 10;
