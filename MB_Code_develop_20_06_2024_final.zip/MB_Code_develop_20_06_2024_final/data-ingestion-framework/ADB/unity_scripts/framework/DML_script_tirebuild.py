# Databricks notebook source
import os

# COMMAND ----------

catalog = os.environ.get("CATALOG_NAME")
catalog

# COMMAND ----------

spark.sql(f"use catalog {catalog}")

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_file_mstr
# MAGIC VALUES
# MAGIC   ('ftb_oneapi_response_api', 'oneapi_yyyyMMdd.json', '/mnt/adls-vehicle-swt/TIRE BUILD/', 'API', '30 10  * * *', 'json', False, 'OneAPI', map('nb', '/Framework/ingestion/tirebuild_api_nb'), current_timestamp(), 'TIREBULD', current_timestamp(), 'TIREBULD');

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_layer_mstr
# MAGIC VALUES
# MAGIC (
# MAGIC     'ftb_oneapi_response_api',
# MAGIC     1,
# MAGIC     null,
# MAGIC     'bronze',
# MAGIC     'linear',
# MAGIC     '/mnt/adls-vehicle-swt/TIRE BUILD/',
# MAGIC     'json',
# MAGIC     '`xto-us-12_veh-brz`.tire_bld_src',
# MAGIC     'delta',
# MAGIC     false,
# MAGIC     '/Framework/layer_build/execute_layer_bronze_populate',
# MAGIC     null,
# MAGIC     current_timestamp(),
# MAGIC     'TIREBULD',
# MAGIC     current_timestamp(),
# MAGIC     'TIREBULD'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `xto-us-12_proc_ctrl`.fw_layer_mstr
# MAGIC VALUES
# MAGIC (
# MAGIC     'ftb_oneapi_response_api',
# MAGIC     2,
# MAGIC     null,
# MAGIC     'silver',
# MAGIC     'linear',
# MAGIC     '`xto-us-12_veh-brz`.tire_bld_src',
# MAGIC     'delta',
# MAGIC     '`xto-us-12_veh-slv`.tire_bld_veh_dtl',
# MAGIC     'delta',
# MAGIC     false,
# MAGIC     '/Framework/layer_build/execute_layer_silver_populate',
# MAGIC     map('merge_joining_cols', 'ID_USA_VIN','custom_json_handling','true','custom_json_functionname','custom_json_handling_tirebuild.get_flatten_json'),
# MAGIC     current_timestamp(),
# MAGIC     'TIREBULD',
# MAGIC     current_timestamp(),
# MAGIC     'TIREBULD'
# MAGIC );
