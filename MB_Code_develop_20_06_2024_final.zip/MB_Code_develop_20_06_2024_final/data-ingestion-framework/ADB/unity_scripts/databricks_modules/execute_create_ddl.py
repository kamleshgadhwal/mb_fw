# Databricks notebook source
# MAGIC %md
# MAGIC <b>Desc : <br></b>
# MAGIC This notebook executes create DDL query for the tables provided as input<br>
# MAGIC Input : <br>
# MAGIC input_json_string(string) : Json String containing list of table names as key and values as create ddl script <br>
# MAGIC p_num(string) : Pull request ID <br>
# MAGIC repo(string) : Repo name <br>

# COMMAND ----------

# MAGIC %run ./common_functions

# COMMAND ----------

import json
import os
from datetime import datetime

# COMMAND ----------

dbutils.widgets.text("input_json_string","") #string containing table and create ddl scripts
dbutils.widgets.text("repo","") #repo name
dbutils.widgets.text("p_num","") #pull request id

# COMMAND ----------

input_json_string=dbutils.widgets.get("input_json_string")
repo=dbutils.widgets.get("repo")
p_num=dbutils.widgets.get("p_num").replace('"','')

# COMMAND ----------

json_data = json.loads(input_json_string)

# COMMAND ----------

logging_dict = {
  'repo_nam' : repo,
  'pr_num' : p_num,
  'scipt_typ' : 'create table'}

for key, value in json_data.items():
  #print(key)
  executable_ddl = value.replace("{PLACEHOLDER_CATALOG_NAME}",os.environ["CATALOG_NAME"])
  #print(executable_ddl)

  logging_dict.update({'tbl_nam' : key,
    'exec_ts' : datetime.now(),
    'exec_dt' : datetime.now().date()})
  try:
    spark.sql(executable_ddl)
    #logging
    logging_dict.update({'addnl_info' : {'desc' : 'create table statement', 
                                         'sql' : executable_ddl},
                         'exec_stat' : 'successfull'})
    insert_ddl_dml_log(logging_dict)
  except Exception as e:
    error = 'Error while executing create scripts : ' + str(e)
    print(error)
    #logging
    logging_dict.update({'addnl_info' : {'desc' : 'create table statement', 
                                         'sql' : executable_ddl,
                                         'err_dtls': error},
                         'exec_stat' : 'fail'})
    print(logging_dict)
    insert_ddl_dml_log(logging_dict)


# COMMAND ----------


