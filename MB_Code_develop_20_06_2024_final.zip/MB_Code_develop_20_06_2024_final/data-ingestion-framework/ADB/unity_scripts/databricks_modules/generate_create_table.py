# Databricks notebook source
# MAGIC %md
# MAGIC <b>Desc : <br></b>
# MAGIC This notebook generates a json string containing keys as table name and value as create DDL query.<br>
# MAGIC Input : <br>
# MAGIC input_tables_name(string): String containing list of table names seperated by ~

# COMMAND ----------

# MAGIC %run ./common_functions

# COMMAND ----------

import os
import json


# COMMAND ----------

#string with table names sep by ~
dbutils.widgets.text("input_table_names","") 
input_table_names=dbutils.widgets.get("input_table_names")
print(input_table_names)

# COMMAND ----------

#craetes table names list
input_table_list = create_tab_list(input_table_names)
print(input_table_list)

# COMMAND ----------

#fetches the create ddl script for each table name and returns a json string
finalized_scripts = fetch_scripts(input_table_list)
print(finalized_scripts)

# COMMAND ----------

dbutils.notebook.exit(finalized_scripts)
