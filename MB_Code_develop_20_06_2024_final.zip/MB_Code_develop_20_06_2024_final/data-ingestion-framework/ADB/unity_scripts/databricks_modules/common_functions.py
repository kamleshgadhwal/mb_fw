# Databricks notebook source
from datetime import datetime
from pyspark.sql import DataFrame
from pyspark.sql.types import StructField,StructType
import os
import json

# COMMAND ----------

CATALOG_NAME = 'eastus2_extollo_ms_us_edwdev_adbv'
DDL_DML_LOGGING_TABLE_NAME = '`xto-us-12_proc_ctrl`.fw_ddl_dml_exec_log'

# COMMAND ----------

##ddl
def create_tab_list(input_string):
  """
  Split the string by "~" and map each element to create a table list

  Input:
    -input_string: a string containing table names(with schema) separated by '~'
  Returns:
    -a list containing <<schema name>>.<<table_name>> prefixed by hardcoded placeholder "CATALOG-NAME"
  """
  tab_list = input_string.split("~")
  catalog_name = os.environ["CATALOG_NAME"]
  return [catalog_name + "." + element for element in tab_list]
  
def fetch_scripts(input_table_list):
  """
    Fetches DDL scripts for input tables, replaces certain placeholders,
    and returns the result as a JSON string.
    
    Parameters:
        input_table_list (list): A list of input table names.
    
    Returns:
        str: A JSON string containing table names and their corresponding DDLs.
  """
  
  plh_catalog_name = "{PLACEHOLDER_CATALOG_NAME}"
  curr_catalog = os.environ["CATALOG_NAME"]
  replace_dict = {"\n":" ","  ":" ",curr_catalog:plh_catalog_name}
  table_dict = {}

  for i in range(len(input_table_list)):
    #fixing table name
    existing_table_name = input_table_list[i]
    catalog_index = existing_table_name.find('.')
    table_name = existing_table_name[catalog_index + 1:]

    #fetching table ddl
    existing_ddl = spark.sql(f"show create table {existing_table_name}").first()[0]

    #do necessary editting on ddl
    for key, value in replace_dict.items():
      existing_ddl = existing_ddl.replace(key, value)
      
    #inserting entry of dictionary    
    table_dict[table_name] = existing_ddl
    json_str = json.dumps(table_dict, indent=4)

  return  json_str

# COMMAND ----------

def custom_sort(key):
  """
    Custom sorting function.
    
    Parameters:
        key (str): The string to be sorted.
    
    Returns:
        tuple: A tuple containing a sorting value and the original key.
  """
  if key.startswith('framework'):
      return (0, key)
  else:
      return (1, key)

def read_delta_table(table_name:str,catlg_nam:str)->DataFrame:
  """
    This function reads the delta table .
  
    Input:
    - table_name -> name of the table to be read
    - catlg_nam -> catalog name of the table to read
     Returns:
    - readed delta table object.
    """
  try:
    return spark.read.table(f'`{catlg_nam}`.'+table_name)
  except Exception as e:
    print ('Error:',str(e))

def insert_ddl_dml_log(log_dict):
  """
    Inserts data into a Delta table used for logging DDL (Data Definition Language) and DML (Data Manipulation Language) operations.
    
    Parameters:
        log_dict (dict): A dictionary containing the data to be logged.
    
    Returns:
        bool: True if the insertion is successful, False otherwise.
    """
  df_logging = read_delta_table(DDL_DML_LOGGING_TABLE_NAME,CATALOG_NAME)
  real_table_schema = df_logging.schema
  real_schema_dtypes= {i.name:i.dataType for i in real_table_schema}
  real_schema_nullable= {i.name:i.nullable for i in real_table_schema}
  filter_schema = [StructField(i,real_schema_dtypes[i],real_schema_nullable[i]) for i in log_dict.keys() if i in real_schema_dtypes.keys()]
  logging_data = [tuple(list(log_dict.values()))]  
  logging_schema = filter_schema
  print(logging_data)
  print(logging_schema)
  df = spark.createDataFrame(logging_data,StructType(logging_schema))
  df.display()
  table_name = CATALOG_NAME+'.'+DDL_DML_LOGGING_TABLE_NAME
  df.write.mode("append").format("delta").saveAsTable(table_name)
  return True
