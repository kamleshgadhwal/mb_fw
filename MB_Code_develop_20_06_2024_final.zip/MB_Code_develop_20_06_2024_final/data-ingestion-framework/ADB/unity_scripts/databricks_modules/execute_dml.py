# Databricks notebook source
# MAGIC %md
# MAGIC <b>Desc : <br></b>
# MAGIC This notebook executes triggers the notebooks for DML query execution <br>
# MAGIC Input : <br>
# MAGIC notebook_list(string) : list containing tablenames,notebook_path, comments <br>
# MAGIC p_num(string) : Pull request ID <br>
# MAGIC repo(string) : Repo name <br>

# COMMAND ----------

# MAGIC %run ./common_functions

# COMMAND ----------

dbutils.widgets.text("notebook_list","") #notebook list containing tablenames,notebook_path, comments
dbutils.widgets.text("repo","") #repo name
dbutils.widgets.text("p_num","") #pull request id

# COMMAND ----------

import json 
notebook_dict = json.loads(dbutils.widgets.get("notebook_list"))

repo = dbutils.widgets.get("repo")
p_num = dbutils.widgets.get("p_num").replace('"','')
NOTEBOOK_TIMEOUT = 600
notebook_sorted_keys = sorted(notebook_dict.keys(), key=custom_sort)
notebook_sorted_data = {k: notebook_dict[k] for k in notebook_sorted_keys}
for key in notebook_sorted_keys:
  print(key)
  for row in notebook_dict[key]:
    print(row[1])
    arguments = {'repo':repo,'p_num':p_num,'desc':row[2],'notebook_path':row[1],'table_name':row[0]}
    dbutils.notebook.run(row[1],NOTEBOOK_TIMEOUT,arguments)

# COMMAND ----------


