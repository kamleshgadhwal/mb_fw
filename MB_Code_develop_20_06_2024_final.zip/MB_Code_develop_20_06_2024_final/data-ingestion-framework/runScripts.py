import csv
import subprocess
import sys
import os
import json
import requests

def fetch_paths_from_csv(csv_file):
    paths = []
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        for i, row in enumerate(reader):
            if i == 0:
                continue
            if row:  # Check if the row is not empty
                paths.append(row[0])
    return paths


def get_PR_number():
    bash_script = f'''
    git clone https://$GIT_PASSWORD@git.i.mercedes-benz.com/daps/data-ingestion-framework.git > /dev/null 2>&1
    cd data-ingestion-framework
    git fetch origin main > /dev/null 2>&1
    prNumber=$(git log --merges --first-parent origin/main --format=%s | jq -R 'match("Merge pull request #[0-9]+ from [^/]+/[^ ]+") | .string | split(" ") | .[3] | split("/") | .[-1]' | head -n 1)
    echo $prNumber
    '''
    result = subprocess.run(['bash', '-c', bash_script], capture_output=True, text=True, check=True)
    pr_number = result.stdout.strip()  # Extract PR number from stdout
    return pr_number


# def fix_json_syntax(filename):
#     # Read the contents of the file
#     with open(filename, 'r') as file:
#         json_data = file.read()

#     # Fix JSON syntax
#     fixed_json = json_data.replace("'", '"')

#     # Write the corrected JSON back to the file
#     with open(filename, 'w') as file:
#         file.write(fixed_json)
#         print("fixed json")


# def generate_create_table_scripts():
#     notebook_path = "/Workspace/Framework/unity_scripts/databricks_modules/generate_create_table"
#     directory = "ADB/unity_scripts/what_to_create"
#     concatenated_values= ""

#     for filename in os.listdir(directory):
#      if filename.endswith(".csv"):
#          csv_file = os.path.join(directory, filename)
#       # Read the CSV file and concatenate its values to the string
#          with open(csv_file, "r") as file:
#             reader = csv.reader(file)
#             for row in reader:
#                 if row: 
#                     concatenated_values += row[0] + "~"
    
#     concatenated_values = concatenated_values.rstrip("~")
#     print("concatenated values ", concatenated_values)
#     sys.stdout.flush()
#     bash_script = f'''
#         pip3 install --upgrade requests
#         echo "Script running for notebook {notebook_path}"
#         jobId=$(databricks jobs create --json '{{
#             "name": "generate_create_table_script",
#             "tasks": [
#                 {{
#                 "task_key": "create_table_script",
#                 "run_if": "ALL_SUCCESS",
#                 "notebook_task": {{
#                     "notebook_path": "{notebook_path}",
#                     "source": "WORKSPACE"
#                 }},
#                 "existing_cluster_id": "0920-184831-e6sykkq2"
#                 }}
#             ],
#             "parameters": [
#                 {{
#                 "name": "input_table_names",
#                 "default": "{concatenated_values}"
#                 }}
#             ]
#         }}' | jq -r '.job_id')
#         echo problem $jobId
#         runId=$(databricks jobs run-now $jobId | jq -r '.run_id') 
#         while true; do
#             status=$(databricks jobs get-run $runId | jq -r '.state.result_state')
#             echo $status
#             if [[ "$status" == "SUCCESS" || "$status" == "FAILED" ]]; then
#                 break  # Exit the loop if status is SUCCESS or FAILED
#             fi
#             sleep 10  # Sleep for 10 seconds before checking status again
#         done
#         echo $status 
#         echo $runId
#         if [[ $status == "SUCCESS" ]]
#         then
#             task_id=$(databricks jobs get-run $runId | jq -r '.tasks[].run_id')
#             output=$(databricks jobs get-run-output $task_id | jq -r '.notebook_output.result')
#             echo $output
#             echo $output > output.json

#         elif [[ $status == "FAILED" ]]
#         then 
#             echo "Script failed for {notebook_path}"
#             task_id=$(databricks jobs get-run $runId | jq -r '.tasks[].run_id')
#             echo "taskid: " $task_id
#             exit 1
#         fi
#     '''

#     # Execute the bash script
#     result=subprocess.run(['bash', '-c', bash_script], check=True)


def generate_create_table_scripts():
    notebook_path = "/Workspace/Framework/unity_scripts/databricks_modules/generate_create_table"
    directory = "ADB/unity_scripts/what_to_create"
    concatenated_values= ""

    for filename in os.listdir(directory):
     if filename.endswith(".csv"):
         csv_file = os.path.join(directory, filename)
      # Read the CSV file and concatenate its values to the string
         with open(csv_file, "r") as file:
            reader = csv.reader(file)
            for row in reader:
                if row: 
                    concatenated_values += row[0] + "~"
    
    concatenated_values = concatenated_values.rstrip("~")
    print("concatenated values ", concatenated_values)
    
    cluster_id = "0920-184831-e6sykkq2"
    api_endpoint_jobCreate = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/submit"

    headers = {
        "Authorization": f"Bearer {os.environ['DATABRICKS_TOKEN']}",
        "Content-Type": "application/json",
    }

    parameters = {
        "input_table_names": concatenated_values
    }

    payload_jobCreate = {
        "run_name": "Generate create table",
        "existing_cluster_id": cluster_id,
        "notebook_task": {
            "notebook_path": notebook_path,
            "base_parameters": parameters
        },
    }

    response_jobCreate = requests.post(api_endpoint_jobCreate, headers=headers, json=payload_jobCreate)

    if response_jobCreate.status_code == 200:
        run_id = response_jobCreate.json()["run_id"]
        print(f"Notebook run submitted successfully. Run ID: {run_id}")
    else:
        print(f"Error submitting notebook run. Status code: {response_jobCreate.status_code}, Response_jobCreate: {response_jobCreate}")
    
    sys.stdout.flush()
    # api_endpoint_status = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/get"
    
    # payload_status = {
    #     "run_id": run_id
    # }

    # response_status = requests.get(api_endpoint_status, headers=headers, json=payload_status)
    
    # print(response_status.json()["state"]["life_cycle_state"])
    bash_script = f'''
        pip3 install --upgrade requests
        echo "Script running for notebook {notebook_path}" 
        while true; do
            status=$(databricks jobs get-run {run_id} | jq -r '.state.result_state')
            echo $status
            if [[ "$status" == "SUCCESS" || "$status" == "FAILED" ]]; then
                break  # Exit the loop if status is SUCCESS or FAILED
            fi
            sleep 10  # Sleep for 10 seconds before checking status again
        done
        echo $status 
        echo $runId
        if [[ $status == "SUCCESS" ]]
        then
            task_id=$(databricks jobs get-run {run_id} | jq -r '.tasks[].run_id')
            output=$(databricks jobs get-run-output $task_id | jq -r '.notebook_output.result')
            echo $output
            echo $output > output.json

        elif [[ $status == "FAILED" ]]
        then 
            echo "Script failed for {notebook_path}"
            task_id=$(databricks jobs get-run {run_id} | jq -r '.tasks[].run_id')
            echo "taskid: " $task_id
            exit 1
        fi
    '''

    # Execute the bash script
    result=subprocess.run(['bash', '-c', bash_script], check=True)



def execute_create_table_scripts():
    notebook_path = "/Workspace/Framework/unity_scripts/databricks_modules/execute_create_ddl"
    pr = get_PR_number()
    repoName = "data-ingestion-framework"
    
    with open('output.json', 'r') as file:
        data = json.load(file)

    # Convert sets to lists in the data dictionary
    for key, value in data.items():
        if isinstance(value, set):
            data[key] = list(value)

    json_str = json.dumps(data, indent=4)
    
    cluster_id = "0920-184831-e6sykkq2"
    api_endpoint_jobCreate = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/submit"

    headers = {
        "Authorization": f"Bearer {os.environ['DATABRICKS_TOKEN']}",
        "Content-Type": "application/json",
    }

    parameters = {
        "input_json_string": json_str,
        "repo": repoName,
        "p_num": pr
    }

    payload_jobCreate = {
        "run_name": "Execute create table",
        "existing_cluster_id": cluster_id,
        "notebook_task": {
            "notebook_path": notebook_path,
            "base_parameters": parameters
        },
    }

    response_jobCreate = requests.post(api_endpoint_jobCreate, headers=headers, json=payload_jobCreate)

    if response_jobCreate.status_code == 200:
        run_id = response_jobCreate.json()["run_id"]
        print(f"Notebook run submitted successfully. Run ID: {run_id}")
    else:
        print(f"Error submitting notebook run. Status code: {response_jobCreate.status_code}, Response_jobCreate: {response_jobCreate}")
    sys.stdout.flush()
    # api_endpoint_status = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/get"
    
    # payload_status = {
    #     "run_id": run_id
    # }

    # response_status = requests.get(api_endpoint_status, headers=headers, json=payload_status)
    
    # print(response_status.json()["state"]["life_cycle_state"])
    bash_script = f'''
        pip3 install --upgrade requests
        echo "Script running for notebook {notebook_path}" 
        while true; do
            status=$(databricks jobs get-run {run_id} | jq -r '.state.result_state')
            echo $status
            if [[ "$status" == "SUCCESS" || "$status" == "FAILED" ]]; then
                break  # Exit the loop if status is SUCCESS or FAILED
            fi
            sleep 10  # Sleep for 10 seconds before checking status again
        done
        echo $status 
        echo {run_id}
        if [[ $status == "SUCCESS" ]]
        then
            exit 0

        elif [[ $status == "FAILED" ]]
        then 
            echo "Script failed for {notebook_path}"
            exit 1
        fi
    '''

    # Execute the bash script
    result=subprocess.run(['bash', '-c', bash_script], check=True)

def run_alter_dml():
    notebook_path = "/Workspace/Framework/unity_scripts/databricks_modules/execute_dml"
    directory = "ADB/unity_scripts/what_to_change"
    pr = get_PR_number()
    print("this is pr",pr)
    repoName = "data-ingestion-framework"
    csv_data = {}
    for filename in os.listdir(directory):
        if filename.endswith('.csv'):
            csv_file = os.path.join(directory, filename)
            with open(csv_file, 'r') as file:
                reader = csv.reader(file)
                data = [row for i, row in enumerate(reader) if i != 0]
                csv_data[filename] = data
    
    json_str = json.dumps(csv_data, indent=0)
    # parsed_json = json_str.replace('"', '\\"')
    # final_json = parsed_json.replace('\n', '')
    
    cluster_id = "0920-184831-e6sykkq2"
    api_endpoint_jobCreate = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/submit"

    headers = {
        "Authorization": f"Bearer {os.environ['DATABRICKS_TOKEN']}",
        "Content-Type": "application/json",
    }

    parameters = {
        "notebook_list": json_str,
        "repo": repoName,
        "p_num": pr
    }

    payload_jobCreate = {
        "run_name": "Execute dml alter",
        "existing_cluster_id": cluster_id,
        "notebook_task": {
            "notebook_path": notebook_path,
            "base_parameters": parameters
        },
    }

    response_jobCreate = requests.post(api_endpoint_jobCreate, headers=headers, json=payload_jobCreate)

    if response_jobCreate.status_code == 200:
        run_id = response_jobCreate.json()["run_id"]
        print(f"Notebook run submitted successfully. Run ID: {run_id}")
    else:
        print(f"Error submitting notebook run. Status code: {response_jobCreate.status_code}, Response_jobCreate: {response_jobCreate}")
    sys.stdout.flush()
    # api_endpoint_status = f"{os.environ['DATABRICKS_HOST']}/api/2.1/jobs/runs/get"
    
    # payload_status = {
    #     "run_id": run_id
    # }

    # response_status = requests.get(api_endpoint_status, headers=headers, json=payload_status)
    
    # print(response_status.json()["state"]["life_cycle_state"])
    bash_script = f'''
        pip3 install --upgrade requests
        echo "Script running for notebook {notebook_path}" 
        while true; do
            status=$(databricks jobs get-run {run_id} | jq -r '.state.result_state')
            echo $status
            if [[ "$status" == "SUCCESS" || "$status" == "FAILED" ]]; then
                break  # Exit the loop if status is SUCCESS or FAILED
            fi
            sleep 10  # Sleep for 10 seconds before checking status again
        done
        echo $status 
        echo {run_id}
        if [[ $status == "SUCCESS" ]]
        then
            exit 0

        elif [[ $status == "FAILED" ]]
        then 
            echo "Script failed for {notebook_path}"
            exit 1
        fi
    '''

    # Execute the bash script
    result=subprocess.run(['bash', '-c', bash_script], check=True)    

# def run_alter_dml():
#     notebook_path = "/Workspace/Framework/unity_scripts/databricks_modules/execute_dml"
#     directory = "ADB/unity_scripts/what_to_change"
#     pr = get_PR_number()
#     print("this is pr",pr)
#     repoName = "data-ingestion-framework"
#     csv_data = {}
#     for filename in os.listdir(directory):
#         if filename.endswith('.csv'):
#             csv_file = os.path.join(directory, filename)
#             with open(csv_file, 'r') as file:
#                 reader = csv.reader(file)
#                 data = [row for i, row in enumerate(reader) if i != 0]
#                 csv_data[filename] = data
    
#     json_str = json.dumps(csv_data, indent=0)
#     parsed_json = json_str.replace('"', '\\"')
#     final_json = parsed_json.replace('\n', '')
#     print("parsed json ", final_json)
#     print(type(json_str))
#     print(json_str)
#     sys.stdout.flush() 
#     bash_script = f'''
#         pip3 install --upgrade requests
#         echo "Script running for notebook {notebook_path}"
#         jobId=$(databricks jobs create --json '{{
#             "name": "dml_alter",
#             "tasks": [
#                 {{
#                 "task_key": "create_table_script",
#                 "run_if": "ALL_SUCCESS",
#                 "notebook_task": {{
#                     "notebook_path": "{notebook_path}",
#                     "source": "WORKSPACE"
#                 }},
#                 "existing_cluster_id": "0920-184831-e6sykkq2"
#                 }}
#             ],
#             "parameters": [
#                 {{
#                 "name": "notebook_list",
#                 "default": "{final_json}"
#                 }},
#                 {{
#                 "name": "repo",
#                 "default": "{repoName}"
#                 }},
#                 {{
#                 "name": "p_num",
#                 "default": {pr}
#                 }}
#             ]
#         }}' | jq -r '.job_id')
#         echo problem $jobId
#         runId=$(databricks jobs run-now $jobId | jq -r '.run_id') 
#         while true; do
#             status=$(databricks jobs get-run $runId | jq -r '.state.result_state')
#             echo $status
#             if [[ "$status" == "SUCCESS" || "$status" == "FAILED" ]]; then
#                 break  # Exit the loop if status is SUCCESS or FAILED
#             fi
#             sleep 10  # Sleep for 10 seconds before checking status again
#         done
#         echo $status 
#         echo $runId
#         if [[ $status == "SUCCESS" ]]
#         then
#             task_id=$(databricks jobs get-run $runId | jq -r '.tasks[].run_id')
#             output=$(databricks jobs get-run-output $task_id | jq -r '.notebook_output.result')
#             echo $output
#             echo $output > output.json

#         elif [[ $status == "FAILED" ]]
#         then 
#             echo "Script failed for {notebook_path}"
#             task_id=$(databricks jobs get-run $runId | jq -r '.tasks[].run_id')
#             echo "taskid: " $task_id
#             exit 1
#         fi
#     '''

#     # Execute the bash script
#     result=subprocess.run(['bash', '-c', bash_script], check=True)

# execute_create_table_scripts()
    
# run_alter_dml()
