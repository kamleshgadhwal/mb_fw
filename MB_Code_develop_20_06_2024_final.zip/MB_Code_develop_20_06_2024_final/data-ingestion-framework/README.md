# data-ingestion-framework
A framework to load data into delta lake.
