#!/bin/bash
echo "##vso[task.setvariable variable=adbStage;isOutput=true]false"
echo "##vso[task.setvariable variable=adfStage;isOutput=true]false"
#echo "##vso[task.setvariable variable=sqlStage;isOutput=true]false"
mapfile -t buildFolders < <(git -C . diff HEAD HEAD~ --name-only | awk -F"/" '{print $1}' | uniq)
# buildFolders=($(git -C . diff HEAD HEAD~ --name-only | awk -F"/" {'print $1'} | uniq))

echo "Changes detected in ${buildFolders[*]} directories"

if [[ " ${buildFolders[*]} " =~ [[:space:]]ADB[[:space:]] ]]
then
    echo "Enable ADB Stage"
    echo "##vso[task.setvariable variable=adbStage;isOutput=true]true"
fi

if [[ " ${buildFolders[*]} " =~ [[:space:]]ADF[[:space:]] ]]
then
    echo "Enable ADF Stage"
    echo "##vso[task.setvariable variable=adfStage;isOutput=true]true"
fi

# if [[ " ${buildFolders[*]} " =~ [[:space:]]SQL[[:space:]] ]]
# then
#     echo "Enable SQL Stage"
#     echo "##vso[task.setvariable variable=sqlStage;isOutput=true]true"
# fi
 
 
